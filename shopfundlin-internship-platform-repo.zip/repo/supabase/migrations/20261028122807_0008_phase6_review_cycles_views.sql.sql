/*
# Phase 6 — Repeatable Review Cycles

## Purpose
Adds a view that aggregates the full review cycle per task — every
submission attempt, every review decision, the progression from initial
submission through revisions to final approval. This powers the timeline
visualization in both the admin and intern UIs.

## New views

### review_cycle_summary
Groups submissions by task, showing per-task aggregates:
- total_submissions — how many attempts the intern made
- current_status — the latest submission's status
- final_decision — the latest review's decision (if any)
- first_submitted_at — when the cycle started
- last_activity_at — most recent submission or review
- highest_score — best score achieved across all reviews
- avg_score — average score across all reviews
- has_changes_requested — whether any round resulted in changes_requested
- cycle_complete — true when a submission was approved

Marked security_invoker so RLS applies.

### submission_timeline
Orders ALL submissions + reviews for a given task chronologically,
producing a timeline of events. Each row is either a "submission" event
or a "review" event with all relevant details. Marked security_invoker.

## Security
- Both views are read-only (SELECT only).
- RLS is inherited from the underlying tables via security_invoker.
- Granted to authenticated (admin sees all, interns see their own).

## Notes
1. The review_cycle_summary gives a bird's-eye view of every task's
   review progression — useful for identifying tasks that need many
   rounds or interns who are stuck in a revision loop.
2. The submission_timeline is fetched per-task to render the vertical
   timeline in the UI.
*/

CREATE OR REPLACE VIEW review_cycle_summary AS
SELECT
  t.id AS task_id,
  t.title AS task_title,
  t.project_id,
  p.title AS project_title,
  s.intern_id,
  i.full_name AS intern_name,
  i.intern_id AS intern_id_human,
  i.email AS intern_email,
  COUNT(DISTINCT s.id) AS total_submissions,
  -- Latest submission status
  (SELECT s2.status FROM submissions s2
   WHERE s2.task_id = t.id
   ORDER BY s2.submitted_at DESC LIMIT 1) AS current_status,
  -- Latest review decision
  (SELECT sr.decision FROM submission_reviews sr
   JOIN submissions s3 ON s3.id = sr.submission_id
   WHERE s3.task_id = t.id
   ORDER BY sr.created_at DESC LIMIT 1) AS final_decision,
  -- First submission date
  MIN(s.submitted_at) AS first_submitted_at,
  -- Last activity (submission or review)
  GREATEST(
    MAX(s.submitted_at),
    COALESCE(MAX(sr.created_at), '1970-01-01'::timestamptz)
  ) AS last_activity_at,
  -- Best score across all reviews
  MAX(sr.score) AS highest_score,
  -- Average score across all reviews with a score
  ROUND(AVG(sr.score), 1) AS avg_score,
  -- Whether any round had changes requested
  BOOL_OR(sr.decision = 'changes_requested') AS has_changes_requested,
  -- Whether the cycle is complete (an approved submission exists)
  BOOL_OR(sr.decision = 'approved') AS cycle_complete
FROM tasks t
JOIN projects p ON p.id = t.project_id
JOIN interns i ON i.id = t.intern_id
LEFT JOIN submissions s ON s.task_id = t.id
LEFT JOIN submission_reviews sr ON sr.submission_id = s.id
GROUP BY t.id, t.title, t.project_id, p.title, s.intern_id, i.full_name, i.intern_id, i.email
HAVING COUNT(DISTINCT s.id) > 0;

ALTER VIEW review_cycle_summary SET (security_invoker = true);
GRANT SELECT ON review_cycle_summary TO authenticated;

-- submission_timeline: chronological events per task
CREATE OR REPLACE VIEW submission_timeline AS
SELECT
  s.task_id,
  s.id AS submission_id,
  'submission' AS event_type,
  s.submission_number,
  s.status AS submission_status,
  s.submission_text,
  s.file_urls,
  s.submitted_at AS event_timestamp,
  NULL::text AS review_decision,
  NULL::text AS review_feedback,
  NULL::text AS review_strengths,
  NULL::text AS review_improvement,
  NULL::int AS review_score,
  NULL::timestamptz AS review_created_at
FROM submissions s
UNION ALL
SELECT
  s.task_id,
  s.id AS submission_id,
  'review' AS event_type,
  s.submission_number,
  s.status AS submission_status,
  NULL::text AS submission_text,
  NULL::text[] AS file_urls,
  sr.created_at AS event_timestamp,
  sr.decision AS review_decision,
  sr.feedback AS review_feedback,
  sr.strengths AS review_strengths,
  sr.areas_for_improvement AS review_improvement,
  sr.score AS review_score,
  sr.created_at AS review_created_at
FROM submission_reviews sr
JOIN submissions s ON s.id = sr.submission_id;

ALTER VIEW submission_timeline SET (security_invoker = true);
GRANT SELECT ON submission_timeline TO authenticated;