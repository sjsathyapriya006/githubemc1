import { supabase } from "./supabase";

async function callEdgeFunction(name: string, params: Record<string, unknown>) {
  const { data: session } = await supabase.auth.getSession();
  const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/${name}`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${session.session?.access_token}`,
      apikey: import.meta.env.VITE_SUPABASE_ANON_KEY,
    },
    body: JSON.stringify(params),
  });
  if (!res.ok) {
    const errBody = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(errBody.error ?? `Request failed (${res.status})`);
  }
  return res.json();
}

export async function sendEmail(params: {
  template_id?: string;
  template_type?: string;
  intern_id?: string;
  recipient_email?: string;
  recipient_name?: string;
  variables?: Record<string, string>;
}): Promise<{ success: boolean; log_id: string; status: string; mock: boolean; error?: string }> {
  return callEdgeFunction("send-email", params);
}

export async function createMeeting(params: {
  title: string;
  description?: string;
  meeting_type?: string;
  scheduled_date: string;
  scheduled_time: string;
  duration_minutes?: number;
  batch_id?: string;
  intern_ids?: string[];
}): Promise<{ success: boolean; meeting_id: string; meeting_link: string; calendar_event_id: string | null; mock: boolean }> {
  return callEdgeFunction("create-meeting", params);
}

export async function evaluateSubmission(params: {
  submission_id: string;
}): Promise<{
  evaluation_id: string;
  evaluation: {
    recommended_decision: "approved" | "changes_requested" | "rejected";
    score: number;
    feedback: string;
    strengths: string;
    areas_for_improvement: string;
    criteria_analysis: string;
  };
  mock: boolean;
}> {
  return callEdgeFunction("ai-evaluate-submission", params);
}
