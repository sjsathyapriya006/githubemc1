import { useEffect, useState } from "react";
import { InternLayout } from "../../components/Layouts";
import { supabase } from "../../lib/supabase";
import { useAuth } from "../../lib/auth";
import type { TaskWithRelations, SubmissionWithDetails, AIEvaluationWithDetails } from "../../types";

const statusBadgeCls = (s: string) => {
  switch (s) {
    case "submitted":
      return "bg-amber-50 text-amber-700";
    case "under_review":
      return "bg-blue-50 text-blue-700";
    case "approved":
      return "bg-emerald-50 text-emerald-700";
    case "changes_requested":
      return "bg-orange-50 text-orange-700";
    case "rejected":
      return "bg-red-50 text-red-700";
    case "resubmitted":
      return "bg-amber-100 text-amber-800";
    default:
      return "bg-slate-100 text-slate-600";
  }
};

export default function InternSubmissions() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<TaskWithRelations[]>([]);
  const [submissions, setSubmissions] = useState<SubmissionWithDetails[]>([]);
  const [aiEvals, setAiEvals] = useState<Record<string, AIEvaluationWithDetails>>({});
  const [internId, setInternId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Submit form state
  const [submitTaskId, setSubmitTaskId] = useState<string | null>(null);
  const [submissionText, setSubmissionText] = useState("");
  const [fileUrls, setFileUrls] = useState("");
  const [busy, setBusy] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  useEffect(() => {
    if (!user?.email) return;
    (async () => {
      const { data: intern } = await supabase
        .from("interns")
        .select("id")
        .eq("email", user.email)
        .maybeSingle();

      if (!intern) {
        setLoading(false);
        return;
      }
      setInternId(intern.id);

      const [taskRes, subRes, evalRes] = await Promise.all([
        supabase
          .from("tasks_with_relations")
          .select("*")
          .eq("intern_id", intern.id)
          .order("created_at", { ascending: false }),
        supabase
          .from("submissions_with_details")
          .select("*")
          .eq("intern_id", intern.id)
          .order("created_at", { ascending: false }),
        supabase
          .from("ai_evaluations_with_details")
          .select("*")
          .eq("intern_id", intern.id)
          .order("created_at", { ascending: false }),
      ]);

      if (taskRes.error) setError(taskRes.error.message);
      if (subRes.error) setError(subRes.error.message);

      setTasks((taskRes.data as TaskWithRelations[]) ?? []);
      setSubmissions((subRes.data as SubmissionWithDetails[]) ?? []);

      // Build map of submission_id -> latest AI evaluation
      const evalMap: Record<string, AIEvaluationWithDetails> = {};
      for (const e of (evalRes.data as AIEvaluationWithDetails[]) ?? []) {
        if (!evalMap[e.submission_id]) {
          evalMap[e.submission_id] = e;
        }
      }
      setAiEvals(evalMap);
      setLoading(false);
    })();
  }, [user?.email]);

  // Tasks that can be submitted (Assigned or In Progress)
  const submittableTasks = tasks.filter((t) =>
    ["Assigned", "In Progress"].includes(t.status)
  );

  // Map of task_id -> latest submission
  const submissionByTask = new Map<string, SubmissionWithDetails>();
  for (const s of submissions) {
    if (!submissionByTask.has(s.task_id)) {
      submissionByTask.set(s.task_id, s);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    if (!submitTaskId) {
      setError("Select a task to submit.");
      return;
    }
    if (!submissionText.trim() && !fileUrls.trim()) {
      setError("Provide either a written submission or file URLs.");
      return;
    }
    setBusy(true);
    try {
      const urls = fileUrls
        .split(/[,\n]/)
        .map((s) => s.trim())
        .filter(Boolean);

      const { error: rpcError } = await supabase.rpc("intern_submit_task", {
        p_task_id: submitTaskId,
        p_submission_text: submissionText.trim(),
        p_file_urls: urls,
      });

      if (rpcError) throw rpcError;

      setSuccessMsg("Submission sent! Your mentor will review it and provide feedback.");
      setSubmitTaskId(null);
      setSubmissionText("");
      setFileUrls("");
      setBusy(false);

      // Reload data
      if (internId) {
        const [taskRes, subRes, evalRes] = await Promise.all([
          supabase
            .from("tasks_with_relations")
            .select("*")
            .eq("intern_id", internId)
            .order("created_at", { ascending: false }),
          supabase
            .from("submissions_with_details")
            .select("*")
            .eq("intern_id", internId)
            .order("created_at", { ascending: false }),
          supabase
            .from("ai_evaluations_with_details")
            .select("*")
            .eq("intern_id", internId)
            .order("created_at", { ascending: false }),
        ]);
        setTasks((taskRes.data as TaskWithRelations[]) ?? []);
        setSubmissions((subRes.data as SubmissionWithDetails[]) ?? []);
        const evalMap: Record<string, AIEvaluationWithDetails> = {};
        for (const e of (evalRes.data as AIEvaluationWithDetails[]) ?? []) {
          if (!evalMap[e.submission_id]) {
            evalMap[e.submission_id] = e;
          }
        }
        setAiEvals(evalMap);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Submission failed.");
      setBusy(false);
    }
  }

  return (
    <InternLayout>
      <h1 className="text-2xl font-bold text-slate-900">My Submissions</h1>
      <p className="mt-1 text-sm text-slate-500">
        Submit your work for assigned tasks and track review feedback.
      </p>

      {error && (
        <div className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>
      )}
      {successMsg && (
        <div className="mt-4 rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-700">
          {successMsg}
        </div>
      )}

      {loading ? (
        <div className="mt-8 animate-pulse text-slate-400">Loading…</div>
      ) : !internId ? (
        <div className="card mt-6 p-6">
          <p className="text-sm text-slate-600">
            Your account is ready, but an admin hasn't added you as an intern yet.
          </p>
        </div>
      ) : (
        <>
          {/* Submit form */}
          {submittableTasks.length > 0 && (
            <div className="card mt-6 p-6">
              <h2 className="text-lg font-semibold text-slate-900">Submit work</h2>
              <form onSubmit={handleSubmit} className="mt-4 space-y-4">
                <div>
                  <label className="label">Task *</label>
                  <select
                    className="input"
                    value={submitTaskId ?? ""}
                    onChange={(e) => setSubmitTaskId(e.target.value || null)}
                  >
                    <option value="">— Select a task —</option>
                    {submittableTasks.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.title} ({t.status})
                      </option>
                    ))}
                  </select>
                </div>
                {submitTaskId && (
                  <>
                    <div>
                      <label className="label">Your submission *</label>
                      <textarea
                        rows={6}
                        className="input"
                        value={submissionText}
                        onChange={(e) => setSubmissionText(e.target.value)}
                        placeholder="Describe your work, approach, and any key decisions…"
                      />
                    </div>
                    <div>
                      <label className="label">File / link URLs (comma or line separated)</label>
                      <textarea
                        rows={2}
                        className="input"
                        value={fileUrls}
                        onChange={(e) => setFileUrls(e.target.value)}
                        placeholder="https://github.com/…, https://docs.google.com/…"
                      />
                    </div>
                  </>
                )}
                <div className="flex gap-2">
                  <button type="submit" disabled={busy} className="btn-primary">
                    {busy ? "Submitting…" : "Submit for review"}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Submission history */}
          <div className="mt-8">
            <h2 className="text-lg font-semibold text-slate-900">Submission history</h2>
            {submissions.length === 0 ? (
              <div className="card mt-4 p-8 text-center text-slate-400">
                No submissions yet. Submit work for an assigned task above.
              </div>
            ) : (
              <div className="mt-4 space-y-4">
                {submissions.map((s) => (
                  <div key={s.id} className="card p-5">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <h3 className="text-base font-semibold text-slate-900">
                            {s.task_title}
                          </h3>
                          <span className={`badge ${statusBadgeCls(s.status)}`}>
                            {s.status.replace(/_/g, " ")}
                          </span>
                          <span className="badge bg-slate-100 text-slate-500">
                            Attempt #{s.submission_number}
                          </span>
                        </div>
                        <p className="mt-1 text-sm text-slate-500">
                          {s.project_title} · Submitted{" "}
                          {new Date(s.submitted_at).toLocaleDateString()}
                        </p>
                      </div>
                    </div>

                    {s.submission_text && (
                      <div className="mt-3">
                        <p className="text-xs font-semibold uppercase text-slate-400">
                          Your submission
                        </p>
                        <p className="mt-1 whitespace-pre-wrap text-sm text-slate-600">
                          {s.submission_text}
                        </p>
                      </div>
                    )}

                    {s.file_urls.length > 0 && (
                      <div className="mt-3">
                        <p className="text-xs font-semibold uppercase text-slate-400">Links</p>
                        <ul className="mt-1 space-y-1">
                          {s.file_urls.map((url, i) => (
                            <li key={i}>
                              <a
                                href={url}
                                target="_blank"
                                rel="noreferrer"
                                className="text-sm text-brand-600 hover:underline"
                              >
                                {url}
                              </a>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* AI evaluation (read-only for interns) */}
                    {aiEvals[s.id] && (
                      <div className="mt-3 rounded-lg border border-brand-200 bg-brand-50 p-4">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-xs font-semibold uppercase text-brand-700">
                            AI evaluation
                          </span>
                          <span
                            className={`badge ${statusBadgeCls(
                              aiEvals[s.id].recommended_decision === "approved"
                                ? "approved"
                                : aiEvals[s.id].recommended_decision === "changes_requested"
                                  ? "changes_requested"
                                  : "rejected"
                            )}`}
                          >
                            {aiEvals[s.id].recommended_decision.replace(/_/g, " ")}
                          </span>
                          <span className="badge bg-brand-100 text-brand-700">
                            Score: {aiEvals[s.id].score}/10
                          </span>
                          {aiEvals[s.id].mock && (
                            <span className="badge bg-amber-100 text-amber-700">mock</span>
                          )}
                        </div>
                        {aiEvals[s.id].feedback && (
                          <p className="mt-2 text-sm text-slate-700">{aiEvals[s.id].feedback}</p>
                        )}
                        {aiEvals[s.id].strengths && (
                          <div className="mt-2">
                            <p className="text-xs font-medium text-emerald-600">Strengths</p>
                            <p className="text-sm text-slate-600">{aiEvals[s.id].strengths}</p>
                          </div>
                        )}
                        {aiEvals[s.id].areas_for_improvement && (
                          <div className="mt-2">
                            <p className="text-xs font-medium text-orange-600">
                              Areas for improvement
                            </p>
                            <p className="text-sm text-slate-600">
                              {aiEvals[s.id].areas_for_improvement}
                            </p>
                          </div>
                        )}
                        <p className="mt-2 text-xs text-slate-400">
                          This is an automated AI assessment. Your mentor's final review is the
                          authoritative evaluation.
                        </p>
                      </div>
                    )}

                    {/* Review feedback */}
                    {s.latest_review_decision && (
                      <div className="mt-4 border-t border-slate-200 pt-4">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold uppercase text-slate-400">
                            Mentor review
                          </span>
                          <span
                            className={`badge ${statusBadgeCls(
                              s.latest_review_decision === "approved"
                                ? "approved"
                                : s.latest_review_decision === "changes_requested"
                                  ? "changes_requested"
                                  : "rejected"
                            )}`}
                          >
                            {s.latest_review_decision.replace(/_/g, " ")}
                          </span>
                          {s.latest_review_score != null && (
                            <span className="badge bg-brand-50 text-brand-700">
                              Score: {s.latest_review_score}/10
                            </span>
                          )}
                        </div>
                        {s.latest_review_feedback && (
                          <p className="mt-2 text-sm text-slate-600">
                            {s.latest_review_feedback}
                          </p>
                        )}
                        {s.latest_review_strengths && (
                          <div className="mt-2">
                            <p className="text-xs font-medium text-emerald-600">Strengths</p>
                            <p className="text-sm text-slate-600">
                              {s.latest_review_strengths}
                            </p>
                          </div>
                        )}
                        {s.latest_review_improvement && (
                          <div className="mt-2">
                            <p className="text-xs font-medium text-orange-600">
                              Areas for improvement
                            </p>
                            <p className="text-sm text-slate-600">
                              {s.latest_review_improvement}
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </InternLayout>
  );
}
