import { useEffect, useMemo, useState } from "react";
import { AdminLayout } from "../../components/Layouts";
import { supabase } from "../../lib/supabase";
import { evaluateSubmission } from "../../lib/edge-functions";
import type { SubmissionWithDetails, AIEvaluationWithDetails } from "../../types";

const statusBadgeCls = (s: string) => {
  switch (s) {
    case "submitted":
      return "bg-amber-50 text-amber-700";
    case "under_review":
      return "bg-blue-50 text-blue-700";
    case "approved":
      return "bg-emerald-50 text-emerald-700";
    case "changes_requested":
      return "bg-orange-50 text-orange-700";
    case "rejected":
      return "bg-red-50 text-red-700";
    case "resubmitted":
      return "bg-amber-100 text-amber-800";
    default:
      return "bg-slate-100 text-slate-600";
  }
};

const emptyReview = {
  decision: "approved" as "approved" | "changes_requested" | "rejected",
  feedback: "",
  strengths: "",
  areas_for_improvement: "",
  score: "" as string,
  rating_code_quality: "" as string,
  rating_functionality: "" as string,
  rating_documentation: "" as string,
  rating_creativity: "" as string,
  rating_deadline_adherence: "" as string,
  score_override_reason: "" as string,
};

export default function AdminSubmissions() {
  const [submissions, setSubmissions] = useState<SubmissionWithDetails[]>([]);
  const [aiEvaluations, setAiEvaluations] = useState<Record<string, AIEvaluationWithDetails>>({});
  const [filterStatus, setFilterStatus] = useState("");
  const [filterIntern, setFilterIntern] = useState("");
  const [internNames, setInternNames] = useState<{ id: string; name: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reviewingId, setReviewingId] = useState<string | null>(null);
  const [review, setReview] = useState(emptyReview);
  const [busy, setBusy] = useState(false);
  const [aiBusyId, setAiBusyId] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    const [subRes, evalRes] = await Promise.all([
      supabase
        .from("submissions_with_details")
        .select("*")
        .order("submitted_at", { ascending: false }),
      supabase
        .from("ai_evaluations_with_details")
        .select("*")
        .order("created_at", { ascending: false }),
    ]);

    if (subRes.error) {
      setError(subRes.error.message);
    } else {
      const rows = (subRes.data as SubmissionWithDetails[]) ?? [];
      setSubmissions(rows);
      const seen = new Map<string, string>();
      for (const s of rows) {
        if (s.intern_id && s.intern_name && !seen.has(s.intern_id)) {
          seen.set(s.intern_id, s.intern_name);
        }
      }
      setInternNames(Array.from(seen.entries()).map(([id, name]) => ({ id, name })));
    }

    // Build map of submission_id -> latest AI evaluation
    if (!evalRes.error && evalRes.data) {
      const evalMap: Record<string, AIEvaluationWithDetails> = {};
      for (const e of evalRes.data as AIEvaluationWithDetails[]) {
        if (!evalMap[e.submission_id]) {
          evalMap[e.submission_id] = e;
        }
      }
      setAiEvaluations(evalMap);
    }

    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    return submissions.filter(
      (s) =>
        (!filterStatus || s.status === filterStatus) &&
        (!filterIntern || s.intern_id === filterIntern)
    );
  }, [submissions, filterStatus, filterIntern]);

  function startReview(s: SubmissionWithDetails) {
    setReviewingId(s.id);
    setReview(emptyReview);
    setError(null);
    setSuccessMsg(null);
  }

  function startReviewWithAI(s: SubmissionWithDetails) {
    const aiEval = aiEvaluations[s.id];
    setReviewingId(s.id);
    setReview({
      decision: aiEval?.recommended_decision ?? "approved",
      feedback: aiEval?.feedback ?? "",
      strengths: aiEval?.strengths ?? "",
      areas_for_improvement: aiEval?.areas_for_improvement ?? "",
      score: aiEval?.score != null ? String(aiEval.score) : "",
      rating_code_quality: "",
      rating_functionality: "",
      rating_documentation: "",
      rating_creativity: "",
      rating_deadline_adherence: "",
      score_override_reason: "",
    });
    setError(null);
    setSuccessMsg(null);
  }

  async function handleAIEvaluate(s: SubmissionWithDetails) {
    setError(null);
    setSuccessMsg(null);
    setAiBusyId(s.id);
    try {
      const result = await evaluateSubmission({ submission_id: s.id });
      setSuccessMsg(
        result.mock
          ? "AI evaluation generated (mock mode). Click 'Use AI review' to pre-fill the review form."
          : "AI evaluation generated. Click 'Use AI review' to pre-fill the review form."
      );
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "AI evaluation failed.");
    }
    setAiBusyId(null);
  }

  async function handleReviewSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!reviewingId) return;
    setError(null);
    setSuccessMsg(null);
    setBusy(true);
    try {
      const score = review.score ? parseInt(review.score) : null;
      const catRatings = {
        p_rating_code_quality: review.rating_code_quality ? parseInt(review.rating_code_quality) : null,
        p_rating_functionality: review.rating_functionality ? parseInt(review.rating_functionality) : null,
        p_rating_documentation: review.rating_documentation ? parseInt(review.rating_documentation) : null,
        p_rating_creativity: review.rating_creativity ? parseInt(review.rating_creativity) : null,
        p_rating_deadline_adherence: review.rating_deadline_adherence ? parseInt(review.rating_deadline_adherence) : null,
        p_score_override_reason: review.score_override_reason.trim() || null,
      };
      const { error: rpcError } = await supabase.rpc("admin_review_submission", {
        p_submission_id: reviewingId,
        p_decision: review.decision,
        p_feedback: review.feedback.trim(),
        p_strengths: review.strengths.trim(),
        p_areas_for_improvement: review.areas_for_improvement.trim(),
        p_score: score,
        ...catRatings,
      });
      if (rpcError) throw rpcError;

      const decisionLabel =
        review.decision === "approved"
          ? "approved"
          : review.decision === "changes_requested"
            ? "requested changes for"
            : "rejected";

      setSuccessMsg(`Submission ${decisionLabel}. Task status updated automatically.`);
      setReviewingId(null);
      setReview(emptyReview);
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Review failed.");
    }
    setBusy(false);
  }

  async function markUnderReview(id: string) {
    setError(null);
    const { error: err } = await supabase
      .from("submissions")
      .update({ status: "under_review" })
      .eq("id", id);
    if (err) {
      setError(err.message);
      return;
    }
    load();
  }

  return (
    <AdminLayout>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Submissions</h1>
          <p className="mt-1 text-sm text-slate-500">
            Review intern submissions. Use AI to draft an evaluation, then edit and finalize.
          </p>
        </div>
      </div>

      {error && (
        <div className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>
      )}
      {successMsg && (
        <div className="mt-4 rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-700">
          {successMsg}
        </div>
      )}

      {/* Filters */}
      <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
        <div>
          <label className="label">Filter by status</label>
          <select
            className="input"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
          >
            <option value="">All statuses</option>
            <option value="submitted">Submitted</option>
            <option value="under_review">Under review</option>
            <option value="approved">Approved</option>
            <option value="changes_requested">Changes requested</option>
            <option value="rejected">Rejected</option>
            <option value="resubmitted">Resubmitted</option>
          </select>
        </div>
        <div>
          <label className="label">Filter by intern</label>
          <select
            className="input"
            value={filterIntern}
            onChange={(e) => setFilterIntern(e.target.value)}
          >
            <option value="">All interns</option>
            {internNames.map((i) => (
              <option key={i.id} value={i.id}>
                {i.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Submission list */}
      <div className="mt-6 space-y-4">
        {loading ? (
          <div className="card p-8 text-center text-slate-400">Loading submissions…</div>
        ) : filtered.length === 0 ? (
          <div className="card p-8 text-center text-slate-400">
            No submissions yet. When interns submit work for their tasks, it will appear here.
          </div>
        ) : (
          filtered.map((s) => {
            const aiEval = aiEvaluations[s.id];
            return (
              <div key={s.id} className="card p-5">
                {reviewingId === s.id ? (
                  /* ── Review form ── */
                  <form onSubmit={handleReviewSubmit} className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-base font-semibold text-slate-900">
                        Review: {s.task_title}
                      </h3>
                      <button
                        type="button"
                        onClick={() => setReviewingId(null)}
                        className="btn-ghost text-sm"
                      >
                        Cancel
                      </button>
                    </div>
                    <p className="text-sm text-slate-500">
                      {s.intern_name} · Attempt #{s.submission_number}
                    </p>

                    {aiEval && (
                      <div className="rounded-lg border border-brand-200 bg-brand-50 p-3">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold uppercase text-brand-700">
                            AI draft loaded
                          </span>
                          {aiEval.mock && (
                            <span className="badge bg-amber-100 text-amber-700">mock</span>
                          )}
                          <span className="badge bg-brand-100 text-brand-700">
                            {aiEval.recommended_decision.replace(/_/g, " ")} · {aiEval.score}/10
                          </span>
                        </div>
                        <p className="mt-1 text-xs text-brand-600">
                          Fields below are pre-filled from the AI evaluation. Edit as needed.
                        </p>
                      </div>
                    )}

                    <div>
                      <label className="label">Decision *</label>
                      <div className="flex gap-2">
                        {(["approved", "changes_requested", "rejected"] as const).map((d) => (
                          <button
                            key={d}
                            type="button"
                            onClick={() => setReview({ ...review, decision: d })}
                            className={`btn text-xs ${
                              review.decision === d
                                ? d === "approved"
                                  ? "bg-emerald-600 text-white"
                                  : d === "changes_requested"
                                    ? "bg-orange-600 text-white"
                                    : "bg-red-600 text-white"
                                : "btn-secondary"
                            }`}
                          >
                            {d === "approved"
                              ? "Approve"
                              : d === "changes_requested"
                                ? "Request changes"
                                : "Reject"}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="label">Feedback</label>
                      <textarea
                        rows={3}
                        className="input"
                        value={review.feedback}
                        onChange={(e) => setReview({ ...review, feedback: e.target.value })}
                        placeholder="Overall feedback for the intern…"
                      />
                    </div>

                    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                      <div>
                        <label className="label">Strengths</label>
                        <textarea
                          rows={2}
                          className="input"
                          value={review.strengths}
                          onChange={(e) =>
                            setReview({ ...review, strengths: e.target.value })
                          }
                          placeholder="What was done well…"
                        />
                      </div>
                      <div>
                        <label className="label">Areas for improvement</label>
                        <textarea
                          rows={2}
                          className="input"
                          value={review.areas_for_improvement}
                          onChange={(e) =>
                            setReview({ ...review, areas_for_improvement: e.target.value })
                          }
                          placeholder="What needs work…"
                        />
                      </div>
                    </div>

                    <div className="rounded-lg bg-slate-50 p-3">
                      <p className="text-xs font-semibold uppercase text-slate-500">Category ratings (0-10)</p>
                      <p className="mt-0.5 text-xs text-slate-400">
                        The overall score is auto-calculated as the average of these categories.
                        Leave blank to skip a category.
                      </p>
                      <div className="mt-3 grid grid-cols-2 gap-3 md:grid-cols-5">
                        <div>
                          <label className="text-xs font-medium text-slate-600">Code quality</label>
                          <input type="number" min={0} max={10} className="input mt-1 py-1 text-sm" value={review.rating_code_quality}
                            onChange={(e) => setReview({ ...review, rating_code_quality: e.target.value })} placeholder="—" />
                        </div>
                        <div>
                          <label className="text-xs font-medium text-slate-600">Functionality</label>
                          <input type="number" min={0} max={10} className="input mt-1 py-1 text-sm" value={review.rating_functionality}
                            onChange={(e) => setReview({ ...review, rating_functionality: e.target.value })} placeholder="—" />
                        </div>
                        <div>
                          <label className="text-xs font-medium text-slate-600">Documentation</label>
                          <input type="number" min={0} max={10} className="input mt-1 py-1 text-sm" value={review.rating_documentation}
                            onChange={(e) => setReview({ ...review, rating_documentation: e.target.value })} placeholder="—" />
                        </div>
                        <div>
                          <label className="text-xs font-medium text-slate-600">Creativity</label>
                          <input type="number" min={0} max={10} className="input mt-1 py-1 text-sm" value={review.rating_creativity}
                            onChange={(e) => setReview({ ...review, rating_creativity: e.target.value })} placeholder="—" />
                        </div>
                        <div>
                          <label className="text-xs font-medium text-slate-600">Deadline adherence</label>
                          <input type="number" min={0} max={10} className="input mt-1 py-1 text-sm" value={review.rating_deadline_adherence}
                            onChange={(e) => setReview({ ...review, rating_deadline_adherence: e.target.value })} placeholder="—" />
                        </div>
                      </div>
                    </div>

                    <div>
                      <label className="label">Overall score override (1-10, optional)</label>
                      <input
                        type="number"
                        min={1}
                        max={10}
                        className="input max-w-xs"
                        value={review.score}
                        onChange={(e) => setReview({ ...review, score: e.target.value })}
                      />
                      <p className="mt-1 text-xs text-slate-400">
                        Leave blank to use the calculated average. If you override it, provide a reason below.
                      </p>
                    </div>

                    {review.score && (
                      <div>
                        <label className="label">Override reason (required when overriding)</label>
                        <input
                          className="input"
                          value={review.score_override_reason}
                          onChange={(e) => setReview({ ...review, score_override_reason: e.target.value })}
                          placeholder="Why is the score being overridden?"
                        />
                      </div>
                    )}

                    <button type="submit" disabled={busy} className="btn-primary">
                      {busy ? "Submitting review…" : "Submit review"}
                    </button>
                  </form>
                ) : (
                  /* ── Submission card ── */
                  <>
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div className="flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <h3 className="text-base font-semibold text-slate-900">
                            {s.task_title}
                          </h3>
                          <span className={`badge ${statusBadgeCls(s.status)}`}>
                            {s.status.replace(/_/g, " ")}
                          </span>
                          <span className="badge bg-slate-100 text-slate-500">
                            #{s.submission_number}
                          </span>
                        </div>
                        <p className="mt-1 text-sm text-slate-500">
                          {s.intern_name} ({s.intern_id_human}) · {s.project_title} ·{" "}
                          {new Date(s.submitted_at).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {(s.status === "submitted" || s.status === "resubmitted") && (
                          <button
                            onClick={() => markUnderReview(s.id)}
                            className="btn-secondary text-xs"
                          >
                            Mark under review
                          </button>
                        )}
                        {s.status !== "approved" && s.status !== "rejected" && (
                          <>
                            <button
                              onClick={() => handleAIEvaluate(s)}
                              disabled={aiBusyId === s.id}
                              className="btn-secondary text-xs"
                            >
                              {aiBusyId === s.id
                                ? "Evaluating…"
                                : aiEval
                                  ? "Re-run AI"
                                  : "AI Evaluate"}
                            </button>
                            {aiEval && (
                              <button
                                onClick={() => startReviewWithAI(s)}
                                className="btn-primary text-xs"
                              >
                                Use AI review
                              </button>
                            )}
                            <button
                              onClick={() => startReview(s)}
                              className="btn-secondary text-xs"
                            >
                              Review manually
                            </button>
                          </>
                        )}
                        {s.status === "changes_requested" && (
                          <button
                            onClick={() => startReview(s)}
                            className="btn-secondary text-xs"
                          >
                            Review again
                          </button>
                        )}
                        {s.status === "rejected" && (
                          <button
                            onClick={() => startReview(s)}
                            className="btn-secondary text-xs"
                          >
                            Re-review
                          </button>
                        )}
                      </div>
                    </div>

                    {/* AI evaluation summary (when available and not in review mode) */}
                    {aiEval && (
                      <div className="mt-3 rounded-lg border border-brand-200 bg-brand-50 p-4">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-xs font-semibold uppercase text-brand-700">
                            AI evaluation
                          </span>
                          <span
                            className={`badge ${statusBadgeCls(
                              aiEval.recommended_decision === "approved"
                                ? "approved"
                                : aiEval.recommended_decision === "changes_requested"
                                  ? "changes_requested"
                                  : "rejected"
                            )}`}
                          >
                            {aiEval.recommended_decision.replace(/_/g, " ")}
                          </span>
                          <span className="badge bg-brand-100 text-brand-700">
                            Score: {aiEval.score}/10
                          </span>
                          {aiEval.mock && (
                            <span className="badge bg-amber-100 text-amber-700">mock</span>
                          )}
                        </div>
                        {aiEval.feedback && (
                          <p className="mt-2 text-sm text-slate-700">{aiEval.feedback}</p>
                        )}
                        {aiEval.strengths && (
                          <p className="mt-1 text-sm text-emerald-700">
                            <span className="font-medium">Strengths:</span> {aiEval.strengths}
                          </p>
                        )}
                        {aiEval.areas_for_improvement && (
                          <p className="mt-1 text-sm text-orange-700">
                            <span className="font-medium">Improvement:</span>{" "}
                            {aiEval.areas_for_improvement}
                          </p>
                        )}
                        {aiEval.criteria_analysis && (
                          <p className="mt-1 text-xs text-slate-500">
                            <span className="font-medium">Criteria analysis:</span>{" "}
                            {aiEval.criteria_analysis}
                          </p>
                        )}
                      </div>
                    )}

                    {/* Expandable submission details */}
                    <button
                      onClick={() => setExpandedId(expandedId === s.id ? null : s.id)}
                      className="mt-2 text-sm text-brand-600 hover:underline"
                    >
                      {expandedId === s.id ? "Hide details" : "Show details"}
                    </button>

                    {expandedId === s.id && (
                      <div className="mt-3 space-y-3 border-t border-slate-200 pt-3">
                        {s.submission_text && (
                          <div>
                            <p className="text-xs font-semibold uppercase text-slate-400">
                              Submission
                            </p>
                            <p className="mt-1 whitespace-pre-wrap text-sm text-slate-600">
                              {s.submission_text}
                            </p>
                          </div>
                        )}
                        {s.file_urls.length > 0 && (
                          <div>
                            <p className="text-xs font-semibold uppercase text-slate-400">Links</p>
                            <ul className="mt-1 space-y-1">
                              {s.file_urls.map((url, i) => (
                                <li key={i}>
                                  <a
                                    href={url}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="text-sm text-brand-600 hover:underline"
                                  >
                                    {url}
                                  </a>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                        {s.task_review_criteria && (
                          <div>
                            <p className="text-xs font-semibold uppercase text-slate-400">
                              Review criteria
                            </p>
                            <p className="mt-1 text-sm text-slate-500">
                              {s.task_review_criteria}
                            </p>
                          </div>
                        )}

                        {/* Previous review */}
                        {s.latest_review_decision && (
                          <div className="rounded-lg bg-slate-50 p-3">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-semibold uppercase text-slate-400">
                                Latest review
                              </span>
                              <span
                                className={`badge ${statusBadgeCls(
                                  s.latest_review_decision === "approved"
                                    ? "approved"
                                    : s.latest_review_decision === "changes_requested"
                                      ? "changes_requested"
                                      : "rejected"
                                )}`}
                              >
                                {s.latest_review_decision.replace(/_/g, " ")}
                              </span>
                              {s.latest_review_score != null && (
                                <span className="badge bg-brand-50 text-brand-700">
                                  {s.latest_review_score}/10
                                </span>
                              )}
                            </div>
                            {s.latest_review_feedback && (
                              <p className="mt-2 text-sm text-slate-600">
                                {s.latest_review_feedback}
                              </p>
                            )}
                            {s.latest_review_strengths && (
                              <p className="mt-1 text-sm text-emerald-700">
                                Strengths: {s.latest_review_strengths}
                              </p>
                            )}
                            {s.latest_review_improvement && (
                              <p className="mt-1 text-sm text-orange-700">
                                Improvement: {s.latest_review_improvement}
                              </p>
                            )}
                          </div>
                        )}
                      </div>
                    )}
                  </>
                )}
              </div>
            );
          })
        )}
      </div>
    </AdminLayout>
  );
}
