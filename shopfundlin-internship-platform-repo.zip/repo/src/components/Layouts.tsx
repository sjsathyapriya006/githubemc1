import { ReactNode } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../lib/auth";

const adminNav = [
  { to: "/admin", label: "Overview", end: true },
  { to: "/admin/interns", label: "Interns" },
  { to: "/admin/batches", label: "Batches" },
  { to: "/admin/projects", label: "Projects" },
  { to: "/admin/project-assignments", label: "Assignments" },
  { to: "/admin/tasks", label: "Tasks" },
  { to: "/admin/submissions", label: "Submissions" },
  { to: "/admin/review-cycles", label: "Review Cycles" },
  { to: "/admin/reviews", label: "Reviews" },
  { to: "/admin/email-templates", label: "Templates" },
  { to: "/admin/email-log", label: "Email Log" },
  { to: "/admin/analytics", label: "Analytics" },
];

const internNav = [
  { to: "/intern", label: "Dashboard", end: true },
  { to: "/intern/projects", label: "My Projects" },
  { to: "/intern/tasks", label: "My Tasks" },
  { to: "/intern/submissions", label: "My Submissions" },
  { to: "/intern/reviews", label: "My Reviews" },
];

const linkClass = ({ isActive }: { isActive: boolean }) =>
  `rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
    isActive ? "bg-brand-50 text-brand-700" : "text-slate-600 hover:bg-slate-100"
  }`;

function Shell({
  brand,
  nav,
  profileName,
  onSignOut,
  children,
  maxWidth,
}: {
  brand: string;
  nav: { to: string; label: string; end?: boolean }[];
  profileName: string;
  onSignOut: () => void;
  children: ReactNode;
  maxWidth: string;
}) {
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-white">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
          <div className="flex items-center gap-8">
            <Link to={nav[0].to} className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-600 font-bold text-white">
                SF
              </div>
              <span className="font-semibold text-slate-900">{brand}</span>
            </Link>
            <nav className="hidden gap-1 md:flex">
              {nav.map((item) => (
                <NavLink key={item.to} to={item.to} end={item.end} className={linkClass}>
                  {item.label}
                </NavLink>
              ))}
            </nav>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden text-sm text-slate-500 sm:block">{profileName}</span>
            <button onClick={onSignOut} className="btn-ghost text-sm">
              Sign out
            </button>
          </div>
        </div>
        <nav className="flex gap-1 overflow-x-auto px-4 pb-2 md:hidden">
          {nav.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `whitespace-nowrap rounded-lg px-3 py-1.5 text-sm font-medium ${
                  isActive ? "bg-brand-50 text-brand-700" : "text-slate-600"
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
      </header>
      <main className={`mx-auto ${maxWidth} px-4 py-8`}>{children}</main>
    </div>
  );
}

export function AdminLayout({ children }: { children: ReactNode }) {
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();
  return (
    <Shell
      brand="Shop Fundlin"
      nav={adminNav}
      profileName={profile?.full_name ?? "Admin"}
      onSignOut={async () => {
        await signOut();
        navigate("/login");
      }}
      maxWidth="max-w-6xl"
    >
      {children}
    </Shell>
  );
}

export function InternLayout({ children }: { children: ReactNode }) {
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();
  return (
    <Shell
      brand="My Internship"
      nav={internNav}
      profileName={profile?.full_name ?? "Intern"}
      onSignOut={async () => {
        await signOut();
        navigate("/login");
      }}
      maxWidth="max-w-5xl"
    >
      {children}
    </Shell>
  );
}
