/*
# Phase 3 — Email automation and review meetings (schema only)

Creates email_templates, email_log, meetings, meeting_attendees with RLS.
Default templates seeded in a follow-up migration.
*/

CREATE TABLE IF NOT EXISTS email_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  subject text NOT NULL,
  body text NOT NULL,
  template_type text NOT NULL DEFAULT 'welcome' CHECK (
    template_type IN ('welcome','review_invite','task_assignment','deadline_reminder',
      'submission_confirmation','review_feedback','revision_request',
      'next_review','completion')
  ),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE email_templates ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON email_templates TO authenticated;
GRANT SELECT ON email_templates TO service_role;
DROP POLICY IF EXISTS "select_email_templates" ON email_templates;
CREATE POLICY "select_email_templates" ON email_templates FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "admin_insert_email_templates" ON email_templates;
CREATE POLICY "admin_insert_email_templates" ON email_templates FOR INSERT TO authenticated WITH CHECK (is_admin());
DROP POLICY IF EXISTS "admin_update_email_templates" ON email_templates;
CREATE POLICY "admin_update_email_templates" ON email_templates FOR UPDATE TO authenticated USING (is_admin()) WITH CHECK (is_admin());
DROP POLICY IF EXISTS "admin_delete_email_templates" ON email_templates;
CREATE POLICY "admin_delete_email_templates" ON email_templates FOR DELETE TO authenticated USING (is_admin());

CREATE TABLE IF NOT EXISTS email_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id uuid REFERENCES email_templates(id) ON DELETE SET NULL,
  intern_id uuid REFERENCES interns(id) ON DELETE CASCADE,
  recipient_email text NOT NULL,
  recipient_name text,
  subject text NOT NULL,
  body text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','sent','failed','retrying')),
  error_message text,
  sent_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid DEFAULT auth.uid()
);
ALTER TABLE email_log ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON email_log TO authenticated;
GRANT SELECT, INSERT, UPDATE ON email_log TO service_role;
DROP POLICY IF EXISTS "admin_select_email_log" ON email_log;
CREATE POLICY "admin_select_email_log" ON email_log FOR SELECT TO authenticated USING (is_admin());
DROP POLICY IF EXISTS "admin_insert_email_log" ON email_log;
CREATE POLICY "admin_insert_email_log" ON email_log FOR INSERT TO authenticated WITH CHECK (is_admin());
DROP POLICY IF EXISTS "admin_update_email_log" ON email_log;
CREATE POLICY "admin_update_email_log" ON email_log FOR UPDATE TO authenticated USING (is_admin()) WITH CHECK (is_admin());
DROP POLICY IF EXISTS "admin_delete_email_log" ON email_log;
CREATE POLICY "admin_delete_email_log" ON email_log FOR DELETE TO authenticated USING (is_admin());

CREATE TABLE IF NOT EXISTS meetings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_id uuid REFERENCES batches(id) ON DELETE SET NULL,
  title text NOT NULL,
  description text DEFAULT '',
  meeting_type text NOT NULL DEFAULT 'initial_review' CHECK (meeting_type IN ('initial_review','follow_up_review','final_review')),
  scheduled_date date NOT NULL,
  scheduled_time text NOT NULL,
  duration_minutes int NOT NULL DEFAULT 60,
  meeting_link text,
  calendar_event_id text,
  status text NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled','completed','cancelled')),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE meetings ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON meetings TO authenticated;
GRANT SELECT ON meetings TO service_role;
DROP POLICY IF EXISTS "admin_insert_meetings" ON meetings;
CREATE POLICY "admin_insert_meetings" ON meetings FOR INSERT TO authenticated WITH CHECK (is_admin());
DROP POLICY IF EXISTS "admin_update_meetings" ON meetings;
CREATE POLICY "admin_update_meetings" ON meetings FOR UPDATE TO authenticated USING (is_admin()) WITH CHECK (is_admin());
DROP POLICY IF EXISTS "admin_delete_meetings" ON meetings;
CREATE POLICY "admin_delete_meetings" ON meetings FOR DELETE TO authenticated USING (is_admin());

CREATE TABLE IF NOT EXISTS meeting_attendees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  intern_id uuid NOT NULL REFERENCES interns(id) ON DELETE CASCADE,
  invitation_status text NOT NULL DEFAULT 'pending' CHECK (invitation_status IN ('pending','sent','failed')),
  attended boolean,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(meeting_id, intern_id)
);
ALTER TABLE meeting_attendees ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON meeting_attendees TO authenticated;
GRANT SELECT ON meeting_attendees TO service_role;

DROP POLICY IF EXISTS "select_meetings" ON meetings;
CREATE POLICY "select_meetings" ON meetings FOR SELECT TO authenticated USING (
  is_admin()
  OR id IN (
    SELECT ma.meeting_id FROM meeting_attendees ma
    JOIN interns i ON i.id = ma.intern_id
    WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
  )
);
DROP POLICY IF EXISTS "select_meeting_attendees" ON meeting_attendees;
CREATE POLICY "select_meeting_attendees" ON meeting_attendees FOR SELECT TO authenticated USING (
  is_admin()
  OR intern_id IN (SELECT i.id FROM interns i WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid()))
);
DROP POLICY IF EXISTS "admin_insert_meeting_attendees" ON meeting_attendees;
CREATE POLICY "admin_insert_meeting_attendees" ON meeting_attendees FOR INSERT TO authenticated WITH CHECK (is_admin());
DROP POLICY IF EXISTS "admin_update_meeting_attendees" ON meeting_attendees;
CREATE POLICY "admin_update_meeting_attendees" ON meeting_attendees FOR UPDATE TO authenticated USING (is_admin()) WITH CHECK (is_admin());
DROP POLICY IF EXISTS "admin_delete_meeting_attendees" ON meeting_attendees;
CREATE POLICY "admin_delete_meeting_attendees" ON meeting_attendees FOR DELETE TO authenticated USING (is_admin());
