/*
# Phase 8b — Category Ratings + Extended Submission Fields

## Purpose
1. Adds category-wise rating columns to `submission_reviews` for:
   code_quality, functionality, documentation, creativity, deadline_adherence.
   Each is an integer 0-10 (nullable). The overall `score` becomes a calculated
   average of these categories, with an admin override option.

2. Adds a `score_override_reason` column for when the admin manually overrides
   the calculated average score.

3. Adds a `reviewer_name` column to cache the reviewer's display name.

4. Adds extended submission fields to `submissions`:
   implementation_summary, completion_notes, repo_url, demo_url, assignment_id.

5. Adds an `assignment_id` FK to submissions so submissions can be linked
   directly to a project_assignment (optional — existing submissions remain
   linked via task_id).

6. Updates the `admin_review_submission` RPC to accept category ratings,
   calculate the average score, and support override.

## Modified tables

### submission_reviews (added columns)
- rating_code_quality (int, 0-10, nullable)
- rating_functionality (int, 0-10, nullable)
- rating_documentation (int, 0-10, nullable)
- rating_creativity (int, 0-10, nullable)
- rating_deadline_adherence (int, 0-10, nullable)
- score_override_reason (text, nullable)
- reviewer_name (text, nullable)

### submissions (added columns)
- implementation_summary (text, default '')
- completion_notes (text, default '')
- repo_url (text, nullable)
- demo_url (text, nullable)
- assignment_id (uuid, nullable, FK → project_assignments.id)

## Score calculation method
The overall score is calculated as the average of the five category ratings
(rating_code_quality + rating_functionality + rating_documentation +
rating_creativity + rating_deadline_adherence) / 5, rounded to the nearest
integer. If the admin provides a manual score, it overrides the calculated
average and the admin must provide a reason in score_override_reason.

## Security
- Existing RLS policies remain unchanged.
- New columns are accessible to the same roles.
- The updated RPC checks is_admin() before allowing reviews.
*/

-- Add category rating columns to submission_reviews
ALTER TABLE submission_reviews
  ADD COLUMN IF NOT EXISTS rating_code_quality integer CHECK (rating_code_quality BETWEEN 0 AND 10),
  ADD COLUMN IF NOT EXISTS rating_functionality integer CHECK (rating_functionality BETWEEN 0 AND 10),
  ADD COLUMN IF NOT EXISTS rating_documentation integer CHECK (rating_documentation BETWEEN 0 AND 10),
  ADD COLUMN IF NOT EXISTS rating_creativity integer CHECK (rating_creativity BETWEEN 0 AND 10),
  ADD COLUMN IF NOT EXISTS rating_deadline_adherence integer CHECK (rating_deadline_adherence BETWEEN 0 AND 10),
  ADD COLUMN IF NOT EXISTS score_override_reason text,
  ADD COLUMN IF NOT EXISTS reviewer_name text;

-- Add extended submission fields
ALTER TABLE submissions
  ADD COLUMN IF NOT EXISTS implementation_summary text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS completion_notes text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS repo_url text,
  ADD COLUMN IF NOT EXISTS demo_url text,
  ADD COLUMN IF NOT EXISTS assignment_id uuid REFERENCES project_assignments(id) ON DELETE SET NULL;

-- Update the admin_review_submission RPC to accept category ratings
CREATE OR REPLACE FUNCTION admin_review_submission(
  p_submission_id uuid,
  p_decision text,
  p_feedback text DEFAULT '',
  p_strengths text DEFAULT '',
  p_areas_for_improvement text DEFAULT '',
  p_score integer DEFAULT NULL,
  p_rating_code_quality integer DEFAULT NULL,
  p_rating_functionality integer DEFAULT NULL,
  p_rating_documentation integer DEFAULT NULL,
  p_rating_creativity integer DEFAULT NULL,
  p_rating_deadline_adherence integer DEFAULT NULL,
  p_score_override_reason text DEFAULT NULL
) RETURNS uuid AS $$
DECLARE
  v_review_id uuid;
  v_task_id uuid;
  v_intern_id uuid;
  v_assignment_id uuid;
  v_task_status text;
  v_calculated_score integer;
  v_reviewer_name text;
  v_cat_count integer := 0;
  v_cat_sum integer := 0;
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Only admins can review submissions';
  END IF;

  -- Get submission details
  SELECT s.task_id, s.intern_id, s.assignment_id
  INTO v_task_id, v_intern_id, v_assignment_id
  FROM submissions s WHERE s.id = p_submission_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Submission not found';
  END IF;

  -- Calculate score from category ratings
  v_cat_count := 0;
  v_cat_sum := 0;
  IF p_rating_code_quality IS NOT NULL THEN v_cat_count := v_cat_count + 1; v_cat_sum := v_cat_sum + p_rating_code_quality; END IF;
  IF p_rating_functionality IS NOT NULL THEN v_cat_count := v_cat_count + 1; v_cat_sum := v_cat_sum + p_rating_functionality; END IF;
  IF p_rating_documentation IS NOT NULL THEN v_cat_count := v_cat_count + 1; v_cat_sum := v_cat_sum + p_rating_documentation; END IF;
  IF p_rating_creativity IS NOT NULL THEN v_cat_count := v_cat_count + 1; v_cat_sum := v_cat_sum + p_rating_creativity; END IF;
  IF p_rating_deadline_adherence IS NOT NULL THEN v_cat_count := v_cat_count + 1; v_cat_sum := v_cat_sum + p_rating_deadline_adherence; END IF;

  IF v_cat_count > 0 THEN
    v_calculated_score := ROUND(v_cat_sum::numeric / v_cat_count);
  END IF;

  -- Get reviewer name
  SELECT p.full_name INTO v_reviewer_name
  FROM profiles p WHERE p.id = auth.uid();

  -- Insert review
  INSERT INTO submission_reviews (
    submission_id, reviewer_id, decision, feedback, strengths,
    areas_for_improvement, score, score_override_reason, reviewer_name,
    rating_code_quality, rating_functionality, rating_documentation,
    rating_creativity, rating_deadline_adherence
  ) VALUES (
    p_submission_id, auth.uid(), p_decision, p_feedback, p_strengths,
    p_areas_for_improvement,
    COALESCE(p_score, v_calculated_score),
    CASE WHEN p_score IS NOT NULL AND v_cat_count > 0 AND p_score != v_calculated_score
         THEN p_score_override_reason ELSE NULL END,
    v_reviewer_name,
    p_rating_code_quality, p_rating_functionality, p_rating_documentation,
    p_rating_creativity, p_rating_deadline_adherence
  ) RETURNING id INTO v_review_id;

  -- Update submission status
  UPDATE submissions
  SET status = p_decision,
      reviewed_at = now()
  WHERE id = p_submission_id;

  -- Determine task status
  IF p_decision = 'approved' THEN
    v_task_status := 'Completed';
  ELSIF p_decision = 'changes_requested' THEN
    v_task_status := 'Submitted';
  ELSIF p_decision = 'rejected' THEN
    v_task_status := 'Rejected';
  END IF;

  -- Update task status
  IF v_task_id IS NOT NULL THEN
    UPDATE tasks SET status = v_task_status WHERE id = v_task_id;
  END IF;

  -- Update assignment status if linked
  IF v_assignment_id IS NOT NULL THEN
    IF p_decision = 'approved' THEN
      UPDATE project_assignments SET status = 'Approved' WHERE id = v_assignment_id;
    ELSIF p_decision = 'changes_requested' THEN
      UPDATE project_assignments SET status = 'Revision Requested' WHERE id = v_assignment_id;
    END IF;
  END IF;

  RETURN v_review_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

REVOKE EXECUTE ON FUNCTION admin_review_submission(
  uuid, text, text, text, text, integer, integer, integer, integer, integer, integer, text
) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION admin_review_submission(
  uuid, text, text, text, text, integer, integer, integer, integer, integer, integer, text
) TO authenticated;

-- Also revoke old signature
REVOKE EXECUTE ON FUNCTION admin_review_submission(
  uuid, text, text, text, text, integer
) FROM PUBLIC, anon;