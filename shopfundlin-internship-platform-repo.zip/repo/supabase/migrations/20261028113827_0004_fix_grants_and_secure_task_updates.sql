/*
# Fix: tighten grants on projects, tasks, and view; secure intern task updates

## Problem
1. `anon` role retained full CRUD grants on `projects`, `tasks`, and the
   `tasks_with_relations` view from platform defaults. The app requires sign-in,
   so anon should have no access.
2. `tasks` had an all-column UPDATE grant to `authenticated`. Because both the
   admin and intern UPDATE policies are permissive, an intern could modify
   title, instructions, deliverables, etc. on their own tasks — not just the
   status field. Only the status column should be intern-editable.

## Changes
1. REVOKE all privileges FROM anon on projects, tasks, tasks_with_relations.
2. REVOKE all-column UPDATE on tasks FROM authenticated.
3. GRANT UPDATE (status) ON tasks TO authenticated — interns can only change
   the status column.
4. Create `admin_update_task(...)` SECURITY DEFINER function so admins can edit
   all task fields via RPC (bypasses the column-restricted grant).
5. Update the admin Tasks page to call this RPC for edits.
*/

-- 1. Revoke anon on projects, tasks, view
REVOKE SELECT, INSERT, UPDATE, DELETE ON projects FROM anon;
REVOKE SELECT, INSERT, UPDATE, DELETE ON tasks FROM anon;
REVOKE SELECT, INSERT, UPDATE, DELETE ON tasks_with_relations FROM anon;

-- 2. Restrict intern UPDATE to status column only
REVOKE UPDATE ON tasks FROM authenticated;
GRANT UPDATE (status) ON tasks TO authenticated;

-- 3. SECURITY DEFINER function for admin full task edits
CREATE OR REPLACE FUNCTION admin_update_task(
  p_id uuid,
  p_title text,
  p_instructions text,
  p_deliverables text,
  p_difficulty text,
  p_deadline date,
  p_review_criteria text,
  p_status text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Only admins can update task fields';
  END IF;
  UPDATE tasks SET
    title = p_title,
    instructions = p_instructions,
    deliverables = p_deliverables,
    difficulty = p_difficulty,
    deadline = p_deadline,
    review_criteria = p_review_criteria,
    status = p_status
  WHERE id = p_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION admin_update_task(uuid, text, text, text, text, date, text, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION admin_update_task(uuid, text, text, text, text, date, text, text) TO authenticated;

-- 4. Also create a function for admin status-only updates (simpler path)
CREATE OR REPLACE FUNCTION admin_update_task_status(
  p_id uuid,
  p_status text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Only admins can update task status';
  END IF;
  UPDATE tasks SET status = p_status WHERE id = p_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION admin_update_task_status(uuid, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION admin_update_task_status(uuid, text) TO authenticated;
