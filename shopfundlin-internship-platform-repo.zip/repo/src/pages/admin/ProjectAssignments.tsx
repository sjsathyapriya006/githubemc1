import { useEffect, useMemo, useState } from "react";
import { AdminLayout } from "../../components/Layouts";
import { supabase } from "../../lib/supabase";
import type {
  ProjectAssignmentWithRelations,
  ProjectAssignmentAudit,
  Intern,
  Project,
} from "../../types";

const statusBadge = (s: string) => {
  const map: Record<string, string> = {
    Assigned: "bg-slate-100 text-slate-600",
    "In Progress": "bg-blue-50 text-blue-700",
    Submitted: "bg-amber-50 text-amber-700",
    "Revision Requested": "bg-orange-50 text-orange-700",
    Resubmitted: "bg-amber-100 text-amber-800",
    Approved: "bg-emerald-50 text-emerald-700",
    Completed: "bg-emerald-100 text-emerald-800",
  };
  return <span className={`badge ${map[s] ?? "bg-slate-100 text-slate-600"}`}>{s}</span>;
};

const difficultyBadge = (d: string | null) => {
  if (!d) return null;
  const cls = d === "easy" ? "bg-emerald-50 text-emerald-700" : d === "medium" ? "bg-amber-50 text-amber-700" : "bg-red-50 text-red-700";
  return <span className={`badge ${cls}`}>{d}</span>;
};

const emptyForm = {
  intern_ids: [] as string[],
  project_id: "",
  use_existing_project: true,
  new_project_title: "",
  new_project_description: "",
  new_project_requirements: "",
  new_project_tools: "",
  new_project_deliverables: "",
  objectives: "",
  milestones: "",
  completion_instructions: "",
  start_date: "",
  deadline: "",
  difficulty: "medium" as string,
};

function splitList(value: string): string[] {
  return value.split(/[,\n]/).map((s) => s.trim()).filter(Boolean);
}

export default function AdminProjectAssignments() {
  const [assignments, setAssignments] = useState<ProjectAssignmentWithRelations[]>([]);
  const [interns, setInterns] = useState<Intern[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [busy, setBusy] = useState(false);
  const [filterStatus, setFilterStatus] = useState("");
  const [filterBatch, setFilterBatch] = useState("");
  const [batches, setBatches] = useState<{ id: string; name: string }[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [auditByAssignment, setAuditByAssignment] = useState<Record<string, ProjectAssignmentAudit[]>>({});
  const [showExtendModal, setShowExtendModal] = useState<ProjectAssignmentWithRelations | null>(null);
  const [newDeadline, setNewDeadline] = useState("");
  const [extendReason, setExtendReason] = useState("");

  async function load() {
    setLoading(true);
    const [assignRes, internRes, projectRes, batchRes] = await Promise.all([
      supabase
        .from("project_assignments")
        .select("*, projects!inner(title, description, requirements, tools, deliverables), interns!inner(full_name, email, intern_id, batch_id, batches(name))")
        .order("created_at", { ascending: false }),
      supabase.from("interns").select("*").order("full_name"),
      supabase.from("projects").select("*").order("title"),
      supabase.from("batches").select("id, name").order("name"),
    ]);

    if (assignRes.error) {
      setError(assignRes.error.message);
    } else {
      const rows = (assignRes.data as unknown as Array<Record<string, unknown>>) ?? [];
      const mapped: ProjectAssignmentWithRelations[] = rows.map((r) => {
        const proj = r.projects as Record<string, unknown>;
        const intr = r.interns as Record<string, unknown>;
        const batch = intr.batches as Record<string, unknown> | null;
        return {
          id: r.id as string,
          project_id: r.project_id as string,
          intern_id: r.intern_id as string,
          assigned_by: r.assigned_by as string | null,
          objectives: r.objectives as string,
          milestones: r.milestones as string[],
          completion_instructions: r.completion_instructions as string,
          start_date: r.start_date as string | null,
          deadline: r.deadline as string | null,
          difficulty: r.difficulty as string | null,
          max_rating: r.max_rating as number,
          status: r.status as ProjectAssignmentWithRelations["status"],
          progress_description: r.progress_description as string,
          progress_updated_at: r.progress_updated_at as string | null,
          created_at: r.created_at as string,
          updated_at: r.updated_at as string,
          project_title: proj?.title as string,
          project_description: proj?.description as string,
          project_requirements: proj?.requirements as string[],
          project_tools: proj?.tools as string[],
          project_deliverables: proj?.deliverables as string[],
          intern_name: intr?.full_name as string,
          intern_email: intr?.email as string,
          intern_id_human: intr?.intern_id as string,
          batch_name: batch?.name as string | undefined,
        };
      });
      setAssignments(mapped);
    }
    setInterns((internRes.data as Intern[]) ?? []);
    setProjects((projectRes.data as Project[]) ?? []);
    setBatches((batchRes.data as { id: string; name: string }[]) ?? []);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    return assignments.filter((a) => {
      if (filterStatus && a.status !== filterStatus) return false;
      if (filterBatch) {
        const intern = interns.find((i) => i.id === a.intern_id);
        if (intern?.batch_id !== filterBatch) return false;
      }
      return true;
    });
  }, [assignments, filterStatus, filterBatch, interns]);

  async function loadAudit(assignmentId: string) {
    const { data } = await supabase
      .from("project_assignment_audit")
      .select("*")
      .eq("assignment_id", assignmentId)
      .order("changed_at", { ascending: false });
    setAuditByAssignment((prev) => ({ ...prev, [assignmentId]: (data as ProjectAssignmentAudit[]) ?? [] }));
  }

  function toggleExpand(id: string) {
    if (expandedId === id) {
      setExpandedId(null);
    } else {
      setExpandedId(id);
      if (!auditByAssignment[id]) loadAudit(id);
    }
  }

  async function handleCreateAssignment(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    if (form.intern_ids.length === 0) {
      setError("Select at least one intern.");
      return;
    }
    if (form.use_existing_project && !form.project_id) {
      setError("Select a project or create a new one.");
      return;
    }
    if (!form.use_existing_project && !form.new_project_title.trim()) {
      setError("New project title is required.");
      return;
    }
    setBusy(true);
    try {
      let projectId = form.project_id;

      if (!form.use_existing_project) {
        const { data: projData, error: projErr } = await supabase
          .from("projects")
          .insert({
            title: form.new_project_title.trim(),
            description: form.new_project_description.trim(),
            requirements: splitList(form.new_project_requirements),
            tools: splitList(form.new_project_tools),
            deliverables: splitList(form.new_project_deliverables),
            status: "active",
            deadline: form.deadline || null,
          })
          .select("id")
          .single();
        if (projErr) throw projErr;
        projectId = projData.id;
      }

      const milestones = splitList(form.milestones);
      for (const internId of form.intern_ids) {
        const { error: insertErr } = await supabase.from("project_assignments").insert({
          project_id: projectId,
          intern_id: internId,
          objectives: form.objectives.trim(),
          milestones,
          completion_instructions: form.completion_instructions.trim(),
          start_date: form.start_date || null,
          deadline: form.deadline || null,
          difficulty: form.difficulty,
          status: "Assigned",
        });
        if (insertErr) throw insertErr;

        const { data: auditData } = await supabase
          .from("project_assignment_audit")
          .insert({
            assignment_id: (await supabase.from("project_assignments").select("id").eq("project_id", projectId).eq("intern_id", internId).single()).data?.id,
            action: "created",
            new_value: "Assigned",
          })
          .select("assignment_id");
        void auditData;
      }

      setSuccessMsg(`Project assigned to ${form.intern_ids.length} intern${form.intern_ids.length > 1 ? "s" : ""}.`);
      setForm(emptyForm);
      setShowForm(false);
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Assignment failed.");
    }
    setBusy(false);
  }

  async function handleExtendDeadline() {
    if (!showExtendModal || !newDeadline) return;
    setError(null);
    setBusy(true);
    try {
      const oldDeadline = showExtendModal.deadline;
      const { error: updateErr } = await supabase
        .from("project_assignments")
        .update({ deadline: newDeadline })
        .eq("id", showExtendModal.id);
      if (updateErr) throw updateErr;

      await supabase.from("project_assignment_audit").insert({
        assignment_id: showExtendModal.id,
        action: "deadline_extended",
        old_value: oldDeadline ?? "none",
        new_value: newDeadline,
      });

      setSuccessMsg("Deadline extended successfully.");
      setShowExtendModal(null);
      setNewDeadline("");
      setExtendReason("");
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to extend deadline.");
    }
    setBusy(false);
  }

  async function handleReassign(assignment: ProjectAssignmentWithRelations, newInternId: string) {
    if (!newInternId || newInternId === assignment.intern_id) return;
    setError(null);
    setBusy(true);
    try {
      const oldIntern = assignment.intern_name;
      const newIntern = interns.find((i) => i.id === newInternId);

      const { error: updateErr } = await supabase
        .from("project_assignments")
        .update({ intern_id: newInternId })
        .eq("id", assignment.id);
      if (updateErr) throw updateErr;

      await supabase.from("project_assignment_audit").insert({
        assignment_id: assignment.id,
        action: "reassigned",
        old_value: oldIntern ?? "unknown",
        new_value: newIntern?.full_name ?? "unknown",
      });

      setSuccessMsg(`Project reassigned from ${oldIntern} to ${newIntern?.full_name}.`);
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Reassignment failed.");
    }
    setBusy(false);
  }

  return (
    <AdminLayout>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Project Assignments</h1>
          <p className="mt-1 text-sm text-slate-500">
            Assign projects to interns individually, set milestones and deadlines, and track progress.
          </p>
        </div>
        <button
          onClick={() => { if (showForm) { setShowForm(false); setForm(emptyForm); } else setShowForm(true); }}
          className="btn-primary"
        >
          {showForm ? "Close" : "Assign project"}
        </button>
      </div>

      {error && <div className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}
      {successMsg && <div className="mt-4 rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-700">{successMsg}</div>}

      {showForm && (
        <form onSubmit={handleCreateAssignment} className="card mt-6 p-6">
          <h2 className="text-lg font-semibold text-slate-900">New project assignment</h2>

          {/* Intern selection */}
          <div className="mt-4">
            <label className="label">Select interns *</label>
            <div className="mt-2 max-h-48 overflow-y-auto rounded-lg border border-slate-200 p-3">
              {interns.map((i) => (
                <label key={i.id} className="flex items-center gap-2 py-1 text-sm">
                  <input
                    type="checkbox"
                    checked={form.intern_ids.includes(i.id)}
                    onChange={(e) => {
                      if (e.target.checked) setForm({ ...form, intern_ids: [...form.intern_ids, i.id] });
                      else setForm({ ...form, intern_ids: form.intern_ids.filter((id) => id !== i.id) });
                    }}
                  />
                  <span className="text-slate-700">{i.full_name}</span>
                  <span className="text-slate-400">({i.intern_id})</span>
                  <span className="text-slate-400">{i.email}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Project selection */}
          <div className="mt-4">
            <label className="label">Project *</label>
            <div className="flex gap-4">
              <label className="flex items-center gap-2 text-sm">
                <input type="radio" checked={form.use_existing_project} onChange={() => setForm({ ...form, use_existing_project: true })} />
                Existing project
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input type="radio" checked={!form.use_existing_project} onChange={() => setForm({ ...form, use_existing_project: false })} />
                Create new project
              </label>
            </div>
            {form.use_existing_project ? (
              <select className="input mt-2" value={form.project_id} onChange={(e) => setForm({ ...form, project_id: e.target.value })}>
                <option value="">— Select a project —</option>
                {projects.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}
              </select>
            ) : (
              <div className="mt-2 space-y-3">
                <input className="input" placeholder="Project title" value={form.new_project_title} onChange={(e) => setForm({ ...form, new_project_title: e.target.value })} />
                <textarea rows={2} className="input" placeholder="Project description" value={form.new_project_description} onChange={(e) => setForm({ ...form, new_project_description: e.target.value })} />
                <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                  <textarea rows={3} className="input" placeholder="Requirements (one per line)" value={form.new_project_requirements} onChange={(e) => setForm({ ...form, new_project_requirements: e.target.value })} />
                  <textarea rows={3} className="input" placeholder="Deliverables (one per line)" value={form.new_project_deliverables} onChange={(e) => setForm({ ...form, new_project_deliverables: e.target.value })} />
                </div>
                <input className="input" placeholder="Tools (comma-separated)" value={form.new_project_tools} onChange={(e) => setForm({ ...form, new_project_tools: e.target.value })} />
              </div>
            )}
          </div>

          {/* Assignment details */}
          <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="md:col-span-2">
              <label className="label">Objectives</label>
              <textarea rows={2} className="input" value={form.objectives} onChange={(e) => setForm({ ...form, objectives: e.target.value })} placeholder="What should the intern achieve?" />
            </div>
            <div className="md:col-span-2">
              <label className="label">Milestones (one per line)</label>
              <textarea rows={3} className="input" value={form.milestones} onChange={(e) => setForm({ ...form, milestones: e.target.value })} placeholder="Milestone 1: Setup&#10;Milestone 2: Core features&#10;Milestone 3: Testing" />
            </div>
            <div className="md:col-span-2">
              <label className="label">Completion instructions</label>
              <textarea rows={2} className="input" value={form.completion_instructions} onChange={(e) => setForm({ ...form, completion_instructions: e.target.value })} placeholder="How should the intern complete and submit this project?" />
            </div>
            <div>
              <label className="label">Start date</label>
              <input type="date" className="input" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} />
            </div>
            <div>
              <label className="label">Deadline</label>
              <input type="date" className="input" value={form.deadline} onChange={(e) => setForm({ ...form, deadline: e.target.value })} />
            </div>
            <div>
              <label className="label">Difficulty</label>
              <select className="input" value={form.difficulty} onChange={(e) => setForm({ ...form, difficulty: e.target.value })}>
                <option value="easy">Easy</option>
                <option value="medium">Medium</option>
                <option value="hard">Hard</option>
              </select>
            </div>
          </div>

          <div className="mt-4 flex gap-2">
            <button type="submit" disabled={busy} className="btn-primary">
              {busy ? "Assigning…" : "Assign project"}
            </button>
            <button type="button" onClick={() => { setShowForm(false); setForm(emptyForm); }} className="btn-secondary">Cancel</button>
          </div>
        </form>
      )}

      {/* Filters */}
      <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
        <div>
          <label className="label">Filter by status</label>
          <select className="input" value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
            <option value="">All statuses</option>
            <option>Assigned</option>
            <option>In Progress</option>
            <option>Submitted</option>
            <option>Revision Requested</option>
            <option>Resubmitted</option>
            <option>Approved</option>
            <option>Completed</option>
          </select>
        </div>
        <div>
          <label className="label">Filter by batch</label>
          <select className="input" value={filterBatch} onChange={(e) => setFilterBatch(e.target.value)}>
            <option value="">All batches</option>
            {batches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
        </div>
      </div>

      {/* Assignment list */}
      <div className="mt-6 space-y-4">
        {loading ? (
          <div className="card p-8 text-center text-slate-400">Loading assignments…</div>
        ) : filtered.length === 0 ? (
          <div className="card p-8 text-center text-slate-400">
            No project assignments yet. Click "Assign project" to assign a project to an intern.
          </div>
        ) : (
          filtered.map((a) => (
            <div key={a.id} className="card p-5">
              <button onClick={() => toggleExpand(a.id)} className="flex w-full flex-wrap items-start justify-between gap-2 text-left">
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-base font-semibold text-slate-900">{a.project_title}</h3>
                    {statusBadge(a.status)}
                    {difficultyBadge(a.difficulty)}
                  </div>
                  <p className="mt-1 text-sm text-slate-500">
                    {a.intern_name} ({a.intern_id_human}){a.batch_name ? ` · ${a.batch_name}` : ""}
                  </p>
                  <div className="mt-2 flex flex-wrap gap-3 text-xs text-slate-400">
                    {a.deadline && <span>Deadline: {a.deadline}</span>}
                    {a.milestones.length > 0 && <span>{a.milestones.length} milestones</span>}
                    <span>Max rating: {a.max_rating}/10</span>
                    {a.progress_updated_at && <span>Progress updated: {new Date(a.progress_updated_at).toLocaleDateString()}</span>}
                  </div>
                </div>
                <span className="text-sm text-brand-600">{expandedId === a.id ? "Hide details" : "View details"}</span>
              </button>

              {expandedId === a.id && (
                <div className="mt-4 border-t border-slate-200 pt-4">
                  {/* Assignment details */}
                  <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                    {a.objectives && (
                      <div>
                        <p className="text-xs font-semibold uppercase text-slate-400">Objectives</p>
                        <p className="mt-1 text-sm text-slate-600">{a.objectives}</p>
                      </div>
                    )}
                    {a.completion_instructions && (
                      <div>
                        <p className="text-xs font-semibold uppercase text-slate-400">Completion instructions</p>
                        <p className="mt-1 text-sm text-slate-600">{a.completion_instructions}</p>
                      </div>
                    )}
                    {a.milestones.length > 0 && (
                      <div className="md:col-span-2">
                        <p className="text-xs font-semibold uppercase text-slate-400">Milestones</p>
                        <ul className="mt-1 list-disc pl-4 text-sm text-slate-600">
                          {a.milestones.map((m, i) => <li key={i}>{m}</li>)}
                        </ul>
                      </div>
                    )}
                    {a.project_requirements && a.project_requirements.length > 0 && (
                      <div>
                        <p className="text-xs font-semibold uppercase text-slate-400">Project requirements</p>
                        <ul className="mt-1 list-disc pl-4 text-sm text-slate-600">
                          {a.project_requirements.map((r, i) => <li key={i}>{r}</li>)}
                        </ul>
                      </div>
                    )}
                    {a.project_tools && a.project_tools.length > 0 && (
                      <div>
                        <p className="text-xs font-semibold uppercase text-slate-400">Tools</p>
                        <div className="mt-1 flex flex-wrap gap-1">
                          {a.project_tools.map((t, i) => <span key={i} className="badge bg-slate-100 text-slate-600">{t}</span>)}
                        </div>
                      </div>
                    )}
                    {a.progress_description && (
                      <div className="md:col-span-2">
                        <p className="text-xs font-semibold uppercase text-slate-400">Intern progress notes</p>
                        <p className="mt-1 whitespace-pre-wrap text-sm text-slate-600">{a.progress_description}</p>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="mt-4 flex flex-wrap gap-2">
                    <button
                      onClick={() => { setShowExtendModal(a); setNewDeadline(a.deadline ?? ""); }}
                      className="btn-secondary text-xs"
                    >
                      Extend deadline
                    </button>
                    <select
                      className="input max-w-xs py-1 text-xs"
                      value=""
                      onChange={(e) => { if (e.target.value) handleReassign(a, e.target.value); }}
                    >
                      <option value="">Reassign to…</option>
                      {interns.filter((i) => i.id !== a.intern_id).map((i) => (
                        <option key={i.id} value={i.id}>{i.full_name} ({i.intern_id})</option>
                      ))}
                    </select>
                  </div>

                  {/* Audit trail */}
                  <div className="mt-4">
                    <p className="text-xs font-semibold uppercase text-slate-400">Audit trail</p>
                    {(auditByAssignment[a.id] ?? []).length === 0 ? (
                      <p className="mt-1 text-sm text-slate-400">No changes recorded.</p>
                    ) : (
                      <div className="mt-2 space-y-2">
                        {(auditByAssignment[a.id] ?? []).map((audit) => (
                          <div key={audit.id} className="flex items-center gap-2 text-xs text-slate-500">
                            <span className="badge bg-slate-100 text-slate-600">{audit.action.replace(/_/g, " ")}</span>
                            {audit.old_value && <span>from "{audit.old_value}"</span>}
                            {audit.new_value && <span>to "{audit.new_value}"</span>}
                            <span>· {new Date(audit.changed_at).toLocaleString()}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Extend deadline modal */}
      {showExtendModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-md rounded-xl bg-white p-6 shadow-xl">
            <h3 className="text-lg font-semibold text-slate-900">Extend deadline</h3>
            <p className="mt-1 text-sm text-slate-500">
              {showExtendModal.project_title} · {showExtendModal.intern_name}
            </p>
            <div className="mt-4">
              <label className="label">New deadline</label>
              <input type="date" className="input" value={newDeadline} onChange={(e) => setNewDeadline(e.target.value)} />
            </div>
            <div className="mt-3">
              <label className="label">Reason (optional)</label>
              <input className="input" value={extendReason} onChange={(e) => setExtendReason(e.target.value)} placeholder="Why is the deadline being extended?" />
            </div>
            <div className="mt-4 flex gap-2">
              <button onClick={handleExtendDeadline} disabled={busy || !newDeadline} className="btn-primary">
                {busy ? "Extending…" : "Extend deadline"}
              </button>
              <button onClick={() => { setShowExtendModal(null); setNewDeadline(""); setExtendReason(""); }} className="btn-secondary">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
