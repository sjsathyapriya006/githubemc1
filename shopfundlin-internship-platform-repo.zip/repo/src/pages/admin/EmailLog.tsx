import { useEffect, useMemo, useState } from "react";
import { AdminLayout } from "../../components/Layouts";
import { supabase } from "../../lib/supabase";
import { sendEmail } from "../../lib/edge-functions";
import type { EmailLogEntry, EmailTemplate, Intern } from "../../types";

interface LogWithRelations extends EmailLogEntry {
  template_name?: string;
  intern_name?: string;
}

export default function AdminEmailLog() {
  const [logs, setLogs] = useState<LogWithRelations[]>([]);
  const [templates, setTemplates] = useState<EmailTemplate[]>([]);
  const [interns, setInterns] = useState<Intern[]>([]);
  const [filterStatus, setFilterStatus] = useState("");
  const [showCompose, setShowCompose] = useState(false);
  const [composeTemplate, setComposeTemplate] = useState("");
  const [composeIntern, setComposeIntern] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [expandedLog, setExpandedLog] = useState<string | null>(null);

  async function load() {
    const { data } = await supabase
      .from("email_log")
      .select("*")
      .order("created_at", { ascending: false });
    const rows = (data ?? []) as EmailLogEntry[];

    const [{ data: tmplRows }, { data: internRows }] = await Promise.all([
      supabase.from("email_templates").select("id, name"),
      supabase.from("interns").select("id, full_name"),
    ]);

    const tmplMap = new Map((tmplRows ?? []).map((t) => [t.id, t.name]));
    const internMap = new Map((internRows ?? []).map((i) => [i.id, i.full_name]));

    setLogs(
      rows.map((r) => ({
        ...r,
        template_name: r.template_id ? tmplMap.get(r.template_id) : undefined,
        intern_name: r.intern_id ? internMap.get(r.intern_id) : undefined,
      }))
    );
    setTemplates((tmplRows as EmailTemplate[]) ?? []);
    setInterns((internRows as Intern[]) ?? []);
  }

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    if (!filterStatus) return logs;
    return logs.filter((l) => l.status === filterStatus);
  }, [logs, filterStatus]);

  async function handleSendCompose(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    if (!composeTemplate || !composeIntern) {
      setError("Select a template and an intern.");
      return;
    }
    setBusy(true);
    try {
      const intern = interns.find((i) => i.id === composeIntern);
      const result = await sendEmail({
        template_id: composeTemplate,
        intern_id: composeIntern,
        variables: intern
          ? {
              intern_name: intern.full_name,
              intern_id: intern.intern_id,
              start_date: intern.start_date ?? "",
              expected_end_date: intern.expected_end_date ?? "",
            }
          : undefined,
      });
      setSuccessMsg(
        result.mock
          ? `Email sent in mock mode to ${intern?.full_name}. No real email was delivered.`
          : `Email sent to ${intern?.full_name}.`
      );
      setShowCompose(false);
      setComposeTemplate("");
      setComposeIntern("");
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to send email.");
    }
    setBusy(false);
  }

  async function handleRetry(logId: string) {
    setError(null);
    const log = logs.find((l) => l.id === logId);
    if (!log) return;
    setBusy(true);
    try {
      await supabase.from("email_log").update({ status: "retrying" }).eq("id", logId);
      load();
      const result = await sendEmail({
        template_id: log.template_id ?? undefined,
        recipient_email: log.recipient_email,
        recipient_name: log.recipient_name ?? undefined,
        intern_id: log.intern_id ?? undefined,
      });
      if (result.mock) {
        setSuccessMsg("Retry sent in mock mode.");
      } else {
        setSuccessMsg("Retry sent.");
      }
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Retry failed.");
    }
    setBusy(false);
  }

  const statusBadgeCls = (s: string) => {
    switch (s) {
      case "sent":
        return "bg-emerald-50 text-emerald-700";
      case "failed":
        return "bg-red-50 text-red-700";
      case "retrying":
        return "bg-amber-50 text-amber-700";
      default:
        return "bg-slate-100 text-slate-600";
    }
  };

  return (
    <AdminLayout>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Email Log</h1>
          <p className="mt-1 text-sm text-slate-500">
            Audit trail of all emails sent. Compose a new email or retry failed deliveries.
          </p>
        </div>
        <button
          onClick={() => setShowCompose((s) => !s)}
          className="btn-primary"
        >
          {showCompose ? "Close" : "Compose email"}
        </button>
      </div>

      {error && (
        <div className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>
      )}
      {successMsg && (
        <div className="mt-4 rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-700">
          {successMsg}
        </div>
      )}

      {showCompose && (
        <form onSubmit={handleSendCompose} className="card mt-6 p-6">
          <h2 className="text-lg font-semibold text-slate-900">Compose email</h2>
          <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
            <div>
              <label className="label">Template</label>
              <select
                className="input"
                value={composeTemplate}
                onChange={(e) => setComposeTemplate(e.target.value)}
              >
                <option value="">— Select template —</option>
                {templates.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Recipient (intern)</label>
              <select
                className="input"
                value={composeIntern}
                onChange={(e) => setComposeIntern(e.target.value)}
              >
                <option value="">— Select intern —</option>
                {interns.map((i) => (
                  <option key={i.id} value={i.id}>
                    {i.full_name} ({i.intern_id}) — {i.email}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="mt-4 flex gap-2">
            <button type="submit" disabled={busy} className="btn-primary">
              {busy ? "Sending…" : "Send email"}
            </button>
            <button
              type="button"
              onClick={() => setShowCompose(false)}
              className="btn-secondary"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="mt-6">
        <label className="label">Filter by status</label>
        <select
          className="input max-w-xs"
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
        >
          <option value="">All</option>
          <option value="sent">Sent</option>
          <option value="failed">Failed</option>
          <option value="retrying">Retrying</option>
          <option value="pending">Pending</option>
        </select>
      </div>

      <div className="card mt-4 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-xs uppercase text-slate-500">
              <tr>
                <th className="px-4 py-3">Recipient</th>
                <th className="px-4 py-3">Subject</th>
                <th className="px-4 py-3">Template</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Sent</th>
                <th className="px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-slate-400">
                    No emails logged yet.
                  </td>
                </tr>
              )}
              {filtered.map((l) => (
                <tr key={l.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3">
                    <div className="font-medium text-slate-900">
                      {l.recipient_name ?? l.recipient_email}
                    </div>
                    {l.recipient_name && (
                      <div className="text-xs text-slate-400">{l.recipient_email}</div>
                    )}
                  </td>
                  <td className="px-4 py-3 text-slate-600">
                    <button
                      onClick={() =>
                        setExpandedLog(expandedLog === l.id ? null : l.id)
                      }
                      className="hover:underline"
                    >
                      {l.subject}
                    </button>
                    {expandedLog === l.id && (
                      <pre className="mt-2 max-w-md whitespace-pre-wrap rounded-lg bg-slate-50 p-3 text-xs text-slate-500">
                        {l.body}
                      </pre>
                    )}
                  </td>
                  <td className="px-4 py-3 text-slate-600">
                    {l.template_name ?? "—"}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`badge ${statusBadgeCls(l.status)}`}>{l.status}</span>
                    {l.error_message && (
                      <div className="mt-1 max-w-xs text-xs text-red-500">{l.error_message}</div>
                    )}
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-400">
                    {l.sent_at
                      ? new Date(l.sent_at).toLocaleString()
                      : "—"}
                  </td>
                  <td className="px-4 py-3">
                    {(l.status === "failed" || l.status === "retrying") && (
                      <button
                        onClick={() => handleRetry(l.id)}
                        disabled={busy}
                        className="btn-secondary text-xs"
                      >
                        Retry
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
}
