import { useEffect, useState } from "react";
import { AdminLayout } from "../../components/Layouts";
import { supabase } from "../../lib/supabase";
import type { Project } from "../../types";

const emptyForm = {
  title: "",
  description: "",
  requirements: "",
  tools: "",
  deliverables: "",
  deadline: "",
};

function splitList(value: string): string[] {
  return value
    .split(/[,\n]/)
    .map((s) => s.trim())
    .filter(Boolean);
}

export default function AdminProjects() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  async function load() {
    const { data } = await supabase.from("projects").select("*").order("created_at", { ascending: false });
    setProjects((data as Project[]) ?? []);
  }

  useEffect(() => {
    load();
  }, []);

  function startEdit(p: Project) {
    setEditingId(p.id);
    setForm({
      title: p.title,
      description: p.description,
      requirements: p.requirements.join("\n"),
      tools: p.tools.join(", "),
      deliverables: p.deliverables.join("\n"),
      deadline: p.deadline ?? "",
    });
    setShowForm(true);
    setError(null);
  }

  function resetForm() {
    setForm(emptyForm);
    setEditingId(null);
    setShowForm(false);
    setError(null);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!form.title.trim()) {
      setError("Title is required.");
      return;
    }
    setBusy(true);
    const payload = {
      title: form.title.trim(),
      description: form.description.trim(),
      requirements: splitList(form.requirements),
      tools: splitList(form.tools),
      deliverables: splitList(form.deliverables),
      deadline: form.deadline || null,
    };
    let result;
    if (editingId) {
      result = await supabase.from("projects").update(payload).eq("id", editingId);
    } else {
      result = await supabase.from("projects").insert(payload);
    }
    setBusy(false);
    if (result.error) {
      setError(result.error.message);
      return;
    }
    resetForm();
    load();
  }

  async function toggleStatus(p: Project) {
    const next = p.status === "draft" ? "active" : p.status === "active" ? "archived" : "active";
    await supabase.from("projects").update({ status: next }).eq("id", p.id);
    load();
  }

  const statusBadge = (s: string) => {
    const cls =
      s === "active" ? "bg-emerald-50 text-emerald-700" :
      s === "archived" ? "bg-slate-100 text-slate-500" :
      "bg-amber-50 text-amber-700";
    return <span className={`badge ${cls}`}>{s}</span>;
  };

  return (
    <AdminLayout>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Projects</h1>
          <p className="mt-1 text-sm text-slate-500">Define projects with requirements, tools, and deliverables.</p>
        </div>
        <button
          onClick={() => {
            if (showForm) resetForm();
            else setShowForm(true);
          }}
          className="btn-primary"
        >
          {showForm ? "Close" : "Add project"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="card mt-6 p-6">
          <h2 className="text-lg font-semibold text-slate-900">
            {editingId ? "Edit project" : "New project"}
          </h2>
          <div className="mt-4 grid grid-cols-1 gap-4">
            <div>
              <label className="label">Title *</label>
              <input className="input" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            </div>
            <div>
              <label className="label">Description</label>
              <textarea rows={3} className="input" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div>
                <label className="label">Requirements (one per line or comma-separated)</label>
                <textarea rows={4} className="input" value={form.requirements} onChange={(e) => setForm({ ...form, requirements: e.target.value })} />
              </div>
              <div>
                <label className="label">Deliverables (one per line or comma-separated)</label>
                <textarea rows={4} className="input" value={form.deliverables} onChange={(e) => setForm({ ...form, deliverables: e.target.value })} />
              </div>
            </div>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div>
                <label className="label">Tools (comma-separated)</label>
                <input className="input" value={form.tools} onChange={(e) => setForm({ ...form, tools: e.target.value })} placeholder="React, Node, PostgreSQL" />
              </div>
              <div>
                <label className="label">Deadline</label>
                <input type="date" className="input" value={form.deadline} onChange={(e) => setForm({ ...form, deadline: e.target.value })} />
              </div>
            </div>
          </div>
          {error && <div className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}
          <div className="mt-4 flex gap-2">
            <button type="submit" disabled={busy} className="btn-primary">
              {busy ? "Saving…" : editingId ? "Update project" : "Create project"}
            </button>
            <button type="button" onClick={resetForm} className="btn-secondary">Cancel</button>
          </div>
        </form>
      )}

      <div className="mt-6 space-y-4">
        {projects.length === 0 && (
          <div className="card p-8 text-center text-slate-400">No projects yet. Create one to get started.</div>
        )}
        {projects.map((p) => (
          <div key={p.id} className="card p-5">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-semibold text-slate-900">{p.title}</h3>
                  {statusBadge(p.status)}
                </div>
                {p.description && <p className="mt-1 text-sm text-slate-600">{p.description}</p>}
              </div>
              <div className="flex gap-2">
                <button onClick={() => startEdit(p)} className="btn-secondary text-xs">Edit</button>
                <button onClick={() => toggleStatus(p)} className="btn-secondary text-xs">
                  {p.status === "draft" ? "Activate" : p.status === "active" ? "Archive" : "Reactivate"}
                </button>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-1 gap-3 text-sm md:grid-cols-3">
              {p.requirements.length > 0 && (
                <div>
                  <p className="text-xs font-semibold uppercase text-slate-400">Requirements</p>
                  <ul className="mt-1 list-disc pl-4 text-slate-600">
                    {p.requirements.map((r, i) => <li key={i}>{r}</li>)}
                  </ul>
                </div>
              )}
              {p.tools.length > 0 && (
                <div>
                  <p className="text-xs font-semibold uppercase text-slate-400">Tools</p>
                  <div className="mt-1 flex flex-wrap gap-1">
                    {p.tools.map((t, i) => <span key={i} className="badge bg-slate-100 text-slate-600">{t}</span>)}
                  </div>
                </div>
              )}
              {p.deliverables.length > 0 && (
                <div>
                  <p className="text-xs font-semibold uppercase text-slate-400">Deliverables</p>
                  <ul className="mt-1 list-disc pl-4 text-slate-600">
                    {p.deliverables.map((d, i) => <li key={i}>{d}</li>)}
                  </ul>
                </div>
              )}
            </div>
            {p.deadline && <p className="mt-3 text-xs text-slate-400">Deadline: {p.deadline}</p>}
          </div>
        ))}
      </div>
    </AdminLayout>
  );
}
