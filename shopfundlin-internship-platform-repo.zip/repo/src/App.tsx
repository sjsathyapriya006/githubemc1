import { Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./lib/auth";
import { RequireAuth, RequireRole } from "./components/RequireAuth";
import Login from "./pages/Login";
import Register from "./pages/Register";
import AdminOverview from "./pages/admin/Overview";
import AdminInterns from "./pages/admin/Interns";
import AdminBatches from "./pages/admin/Batches";
import AdminProjects from "./pages/admin/Projects";
import AdminTasks from "./pages/admin/Tasks";
import AdminReviews from "./pages/admin/Reviews";
import AdminEmailTemplates from "./pages/admin/EmailTemplates";
import AdminEmailLog from "./pages/admin/EmailLog";
import AdminSubmissions from "./pages/admin/Submissions";
import AdminReviewCycles from "./pages/admin/ReviewCycles";
import AdminAnalytics from "./pages/admin/Analytics";
import AdminProjectAssignments from "./pages/admin/ProjectAssignments";
import InternDashboard from "./pages/intern/Dashboard";
import InternTasks from "./pages/intern/Tasks";
import InternSubmissions from "./pages/intern/Submissions";
import InternProjects from "./pages/intern/Projects";
import InternReviews from "./pages/intern/Reviews";

function RootRedirect() {
  const { role, loading } = useAuth();
  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="animate-pulse text-slate-400">Loading…</div>
      </div>
    );
  }
  if (!role) return <Navigate to="/login" replace />;
  return <Navigate to={role === "admin" ? "/admin" : "/intern"} replace />;
}

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/admin"
          element={
            <RequireAuth>
              <RequireRole role="admin">
                <AdminOverview />
              </RequireRole>
            </RequireAuth>
          }
        />
        <Route
          path="/admin/interns"
          element={
            <RequireAuth>
              <RequireRole role="admin">
                <AdminInterns />
              </RequireRole>
            </RequireAuth>
          }
        />
        <Route
          path="/admin/batches"
          element={
            <RequireAuth>
              <RequireRole role="admin">
                <AdminBatches />
              </RequireRole>
            </RequireAuth>
          }
        />
        <Route
          path="/admin/projects"
          element={
            <RequireAuth>
              <RequireRole role="admin">
                <AdminProjects />
              </RequireRole>
            </RequireAuth>
          }
        />
        <Route
          path="/admin/tasks"
          element={
            <RequireAuth>
              <RequireRole role="admin">
                <AdminTasks />
              </RequireRole>
            </RequireAuth>
          }
        />
        <Route
          path="/admin/reviews"
          element={
            <RequireAuth>
              <RequireRole role="admin">
                <AdminReviews />
              </RequireRole>
            </RequireAuth>
          }
        />
        <Route
          path="/admin/email-templates"
          element={
            <RequireAuth>
              <RequireRole role="admin">
                <AdminEmailTemplates />
              </RequireRole>
            </RequireAuth>
          }
        />
        <Route
          path="/admin/email-log"
          element={
            <RequireAuth>
              <RequireRole role="admin">
                <AdminEmailLog />
              </RequireRole>
            </RequireAuth>
          }
        />
        <Route
          path="/intern"
          element={
            <RequireAuth>
              <RequireRole role="intern">
                <InternDashboard />
              </RequireRole>
            </RequireAuth>
          }
        />
        <Route
          path="/admin/review-cycles"
          element={
            <RequireAuth>
              <RequireRole role="admin">
                <AdminReviewCycles />
              </RequireRole>
            </RequireAuth>
          }
        />
        <Route
          path="/admin/project-assignments"
          element={
            <RequireAuth>
              <RequireRole role="admin">
                <AdminProjectAssignments />
              </RequireRole>
            </RequireAuth>
          }
        />
        <Route
          path="/admin/analytics"
          element={
            <RequireAuth>
              <RequireRole role="admin">
                <AdminAnalytics />
              </RequireRole>
            </RequireAuth>
          }
        />
        <Route
          path="/admin/submissions"
          element={
            <RequireAuth>
              <RequireRole role="admin">
                <AdminSubmissions />
              </RequireRole>
            </RequireAuth>
          }
        />
        <Route
          path="/intern/projects"
          element={
            <RequireAuth>
              <RequireRole role="intern">
                <InternProjects />
              </RequireRole>
            </RequireAuth>
          }
        />
        <Route
          path="/intern/reviews"
          element={
            <RequireAuth>
              <RequireRole role="intern">
                <InternReviews />
              </RequireRole>
            </RequireAuth>
          }
        />
        <Route
          path="/intern/tasks"
          element={
            <RequireAuth>
              <RequireRole role="intern">
                <InternTasks />
              </RequireRole>
            </RequireAuth>
          }
        />
        <Route
          path="/intern/submissions"
          element={
            <RequireAuth>
              <RequireRole role="intern">
                <InternSubmissions />
              </RequireRole>
            </RequireAuth>
          }
        />
        <Route path="/" element={<RootRedirect />} />
        <Route path="*" element={<RootRedirect />} />
      </Routes>
    </AuthProvider>
  );
}
