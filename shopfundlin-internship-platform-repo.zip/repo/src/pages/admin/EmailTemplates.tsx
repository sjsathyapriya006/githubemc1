import { useEffect, useState } from "react";
import { AdminLayout } from "../../components/Layouts";
import { supabase } from "../../lib/supabase";
import type { EmailTemplate } from "../../types";
import { TEMPLATE_TYPES } from "../../types";

const emptyForm = {
  name: "",
  subject: "",
  body: "",
  template_type: "welcome",
};

const typeLabels: Record<string, string> = {
  welcome: "Welcome",
  review_invite: "Review Invite",
  task_assignment: "Task Assignment",
  deadline_reminder: "Deadline Reminder",
  submission_confirmation: "Submission Confirmation",
  review_feedback: "Review Feedback",
  revision_request: "Revision Request",
  next_review: "Next Review",
  completion: "Completion",
};

export default function AdminEmailTemplates() {
  const [templates, setTemplates] = useState<EmailTemplate[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function load() {
    const { data } = await supabase
      .from("email_templates")
      .select("*")
      .order("created_at", { ascending: false });
    setTemplates((data as EmailTemplate[]) ?? []);
  }

  useEffect(() => {
    load();
  }, []);

  function startEdit(t: EmailTemplate) {
    setEditingId(t.id);
    setForm({
      name: t.name,
      subject: t.subject,
      body: t.body,
      template_type: t.template_type,
    });
    setShowForm(true);
    setError(null);
  }

  function resetForm() {
    setForm(emptyForm);
    setEditingId(null);
    setShowForm(false);
    setError(null);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!form.name.trim() || !form.subject.trim() || !form.body.trim()) {
      setError("Name, subject, and body are required.");
      return;
    }
    setBusy(true);
    const payload = {
      name: form.name.trim(),
      subject: form.subject.trim(),
      body: form.body.trim(),
      template_type: form.template_type,
    };
    let result;
    if (editingId) {
      result = await supabase.from("email_templates").update(payload).eq("id", editingId);
    } else {
      result = await supabase.from("email_templates").insert(payload);
    }
    setBusy(false);
    if (result.error) {
      setError(result.error.message);
      return;
    }
    resetForm();
    load();
  }

  async function handleDelete(id: string) {
    await supabase.from("email_templates").delete().eq("id", id);
    load();
  }

  return (
    <AdminLayout>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Email Templates</h1>
          <p className="mt-1 text-sm text-slate-500">
            Reusable templates with {"{{variable}}"} placeholders for automated emails.
          </p>
        </div>
        <button
          onClick={() => {
            if (showForm) resetForm();
            else setShowForm(true);
          }}
          className="btn-primary"
        >
          {showForm ? "Close" : "Add template"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="card mt-6 p-6">
          <h2 className="text-lg font-semibold text-slate-900">
            {editingId ? "Edit template" : "New template"}
          </h2>
          <div className="mt-4 grid grid-cols-1 gap-4">
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div>
                <label className="label">Template name *</label>
                <input
                  className="input"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="e.g. Welcome / Onboarding"
                />
              </div>
              <div>
                <label className="label">Type</label>
                <select
                  className="input"
                  value={form.template_type}
                  onChange={(e) => setForm({ ...form, template_type: e.target.value })}
                >
                  {TEMPLATE_TYPES.map((t) => (
                    <option key={t} value={t}>
                      {typeLabels[t]}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div>
              <label className="label">Subject *</label>
              <input
                className="input"
                value={form.subject}
                onChange={(e) => setForm({ ...form, subject: e.target.value })}
                placeholder="Welcome to Shop Fundlin, {{intern_name}}!"
              />
            </div>
            <div>
              <label className="label">Body *</label>
              <textarea
                rows={8}
                className="input font-mono text-xs"
                value={form.body}
                onChange={(e) => setForm({ ...form, body: e.target.value })}
                placeholder="Hi {{intern_name}},&#10;&#10;Welcome to your internship..."
              />
            </div>
          </div>
          <div className="mt-3 rounded-lg bg-slate-50 px-3 py-2 text-xs text-slate-500">
            Available variables: {"{{intern_name}}, {{intern_id}}, {{start_date}}, {{expected_end_date}}, "}
            {"{{meeting_date}}, {{meeting_time}}, {{meeting_link}}, {{duration_minutes}}, "}
            {"{{task_title}}, {{task_instructions}}, {{task_deadline}}"}
          </div>
          {error && (
            <div className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>
          )}
          <div className="mt-4 flex gap-2">
            <button type="submit" disabled={busy} className="btn-primary">
              {busy ? "Saving…" : editingId ? "Update template" : "Create template"}
            </button>
            <button type="button" onClick={resetForm} className="btn-secondary">
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="mt-6 space-y-4">
        {templates.length === 0 && (
          <div className="card p-8 text-center text-slate-400">No templates yet.</div>
        )}
        {templates.map((t) => (
          <div key={t.id} className="card p-5">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-semibold text-slate-900">{t.name}</h3>
                  <span className="badge bg-brand-50 text-brand-700">
                    {typeLabels[t.template_type] ?? t.template_type}
                  </span>
                </div>
                <p className="mt-1 text-sm font-medium text-slate-600">{t.subject}</p>
                <pre className="mt-2 max-h-32 overflow-auto rounded-lg bg-slate-50 p-3 text-xs text-slate-500 whitespace-pre-wrap">
                  {t.body}
                </pre>
              </div>
              <div className="flex gap-2">
                <button onClick={() => startEdit(t)} className="btn-secondary text-xs">
                  Edit
                </button>
                <button
                  onClick={() => handleDelete(t.id)}
                  className="btn-secondary text-xs text-red-600"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </AdminLayout>
  );
}
