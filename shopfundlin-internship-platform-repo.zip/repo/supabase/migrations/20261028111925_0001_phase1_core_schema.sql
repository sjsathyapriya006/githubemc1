/*
# Phase 1 — Core schema: profiles, batches, interns

## Purpose
Foundation for the Shop Fundlin internship management platform. Establishes
role-based auth (admin / intern), internship batches, and intern registrations.
Later phases add projects, tasks, submissions, reviews, emails, and audit logs
as separate migrations that reference these tables.

## New tables

### profiles
- `id` uuid PK, matches `auth.users.id` (1:1 with each auth user).
- `role` text — 'admin' or 'intern'. Determines dashboard access.
- `full_name` text — display name shown in UI.
- `created_at` timestamptz.

### batches
- `id` uuid PK.
- `name` text — batch label, e.g. "2026 Winter Cohort".
- `start_date` / `end_date` date — cohort window.
- `status` text — 'active' | 'completed' (default 'active').
- `created_at` timestamptz.

### interns
- `id` uuid PK.
- `intern_id` text unique — human-readable ID generated on registration (e.g. SF-2026-0001).
- `full_name`, `email` (unique), `phone`, `college`, `department`, `role` — registration fields.
- `batch_id` uuid FK -> batches(id) ON DELETE SET NULL.
- `start_date`, `expected_end_date` date.
- `status` text — lifecycle status (Registered / Onboarding / ... / Completed).
- `created_at` timestamptz.

## Security

- RLS enabled on all three tables.
- profiles: each authenticated user reads/updates only their own row.
- batches: admins have full CRUD; interns read-only.
- interns: admins have full CRUD; an intern may read their own row when their
  auth email matches the intern email.
- Grants restricted to `authenticated` (app requires sign-in). `service_role`
  granted for future edge-function use.
- `intern_id_seq` sequence grants USAGE to authenticated for INSERT.

## Notes
1. Sign-in is required, so policies target `authenticated` only.
2. `profiles.id` has DEFAULT auth.uid() so the upsert on signup succeeds even
   though the client does not pass an explicit id.
3. Admin/intern separation is enforced via `profiles.role`.
*/

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'intern' CHECK (role IN ('admin', 'intern')),
  full_name text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

GRANT SELECT, UPDATE ON profiles TO authenticated;
GRANT SELECT ON profiles TO service_role;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND role = 'admin'
  );
$$;

REVOKE EXECUTE ON FUNCTION is_admin() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION is_admin() TO authenticated;

CREATE TABLE IF NOT EXISTS batches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  start_date date,
  end_date date,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'completed')),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE batches ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON batches TO authenticated;
GRANT SELECT ON batches TO service_role;

DROP POLICY IF EXISTS "select_batches" ON batches;
CREATE POLICY "select_batches" ON batches FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_batches" ON batches;
CREATE POLICY "admin_insert_batches" ON batches FOR INSERT
  TO authenticated WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_update_batches" ON batches;
CREATE POLICY "admin_update_batches" ON batches FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_delete_batches" ON batches;
CREATE POLICY "admin_delete_batches" ON batches FOR DELETE
  TO authenticated USING (is_admin());

CREATE TABLE IF NOT EXISTS interns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  intern_id text UNIQUE NOT NULL,
  full_name text NOT NULL,
  email text UNIQUE NOT NULL,
  phone text,
  college text,
  department text,
  role text,
  batch_id uuid REFERENCES batches(id) ON DELETE SET NULL,
  start_date date,
  expected_end_date date,
  status text NOT NULL DEFAULT 'Registered' CHECK (
    status IN ('Registered','Onboarding','Task Assigned','In Progress',
               'Submitted','Under Review','Changes Requested','Resubmitted','Completed')
  ),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE interns ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON interns TO authenticated;
GRANT SELECT ON interns TO service_role;

DROP POLICY IF EXISTS "select_interns" ON interns;
CREATE POLICY "select_interns" ON interns FOR SELECT
  TO authenticated USING (
    is_admin()
    OR email = (SELECT email FROM auth.users WHERE id = auth.uid())
  );

DROP POLICY IF EXISTS "admin_insert_interns" ON interns;
CREATE POLICY "admin_insert_interns" ON interns FOR INSERT
  TO authenticated WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_update_interns" ON interns;
CREATE POLICY "admin_update_interns" ON interns FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_delete_interns" ON interns;
CREATE POLICY "admin_delete_interns" ON interns FOR DELETE
  TO authenticated USING (is_admin());

CREATE SEQUENCE IF NOT EXISTS intern_id_seq;

CREATE OR REPLACE FUNCTION next_intern_id()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  next_val bigint;
  yr text := to_char(now(), 'YYYY');
BEGIN
  next_val := nextval('intern_id_seq');
  RETURN 'SF-' || yr || '-' || lpad(next_val::text, 4, '0');
END;
$$;

REVOKE EXECUTE ON FUNCTION next_intern_id() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION next_intern_id() TO authenticated;

GRANT USAGE ON SEQUENCE intern_id_seq TO authenticated;
