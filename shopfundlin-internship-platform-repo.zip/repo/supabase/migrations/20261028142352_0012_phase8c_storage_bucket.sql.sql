/*
# Phase 8c — Storage Bucket for Private Project File Uploads

## Purpose
Creates a private storage bucket `project-files` where interns can upload
project deliverable files (ZIP, PDF, DOCX, images, source code). The bucket
is private — files are only accessible via authenticated requests with RLS
policies enforcing per-user access.

## Storage policies

### project-files bucket
- Interns can upload files to a path pattern: `assignments/{assignment_id}/{filename}`
  but only for assignments that belong to them.
- Interns can read files only from their own assignment paths.
- Admins can read and manage all files in the bucket.
- Public access is denied (no anon policies).

## Security
- Bucket is private (not public).
- RLS policies on storage.objects enforce path-based access control.
- Upload paths must include the assignment_id for ownership verification.
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('project-files', 'project-files', false)
ON CONFLICT (id) DO NOTHING;

-- Interns can upload to their own assignment folder
DROP POLICY IF EXISTS "intern_upload_project_files" ON storage.objects;
CREATE POLICY "intern_upload_project_files"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'project-files'
  AND (storage.foldername(name))[1] = 'assignments'
  AND (
    is_admin()
    OR EXISTS (
      SELECT 1 FROM project_assignments pa
      WHERE pa.id::text = (storage.foldername(name))[2]
      AND pa.intern_id IN (
        SELECT i.id FROM interns i
        WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
      )
    )
  )
);

-- Interns can read their own assignment files
DROP POLICY IF EXISTS "intern_read_project_files" ON storage.objects;
CREATE POLICY "intern_read_project_files"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'project-files'
  AND (
    is_admin()
    OR EXISTS (
      SELECT 1 FROM project_assignments pa
      WHERE pa.id::text = (storage.foldername(name))[2]
      AND pa.intern_id IN (
        SELECT i.id FROM interns i
        WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
      )
    )
  )
);

-- Admins can update/delete any file
DROP POLICY IF EXISTS "admin_update_project_files" ON storage.objects;
CREATE POLICY "admin_update_project_files"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'project-files' AND is_admin());

DROP POLICY IF EXISTS "admin_delete_project_files" ON storage.objects;
CREATE POLICY "admin_delete_project_files"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'project-files' AND is_admin());