# Shop Fundlin Internship Platform

AI-assisted internship management: interns, batches, projects, task assignment,
review meetings, submissions, AI project evaluation, and repeat review cycles.

**Stack:** React + TypeScript + Vite + Tailwind, Supabase (Postgres, Auth, Storage, Edge Functions).

## Quick start

```bash
npm install
cp .env.example .env      # then fill in your Supabase URL and anon key
npm run dev               # http://localhost:5173
```

## Database

SQL migrations are in `supabase/migrations/` (run in order, 0001 to 0013).
With the Supabase CLI:

```bash
supabase link --project-ref YOUR-PROJECT-REF
supabase db push
```

## Edge Functions

`ai-recommend-tasks`, `ai-evaluate-submission`, `send-email`, `create-meeting`.

```bash
cp supabase/functions/.env.example supabase/functions/.env   # fill in values
supabase secrets set --env-file supabase/functions/.env
supabase functions deploy
```

**Mock mode:** if a service's keys are not set, the function falls back to a
mock result and flags it with `mock: true`. Mock output is not real. Configure
and test each integration before relying on it or sending bulk emails.

## Security notes

- Never commit `.env` files (they are git-ignored).
- The service-role key and all third-party keys live only in Edge Function secrets.
- Only the public anon key belongs in the frontend.

## Scripts

| Command | What it does |
|---|---|
| `npm run dev` | Start dev server |
| `npm run build` | Type-check and build |
| `npm run typecheck` | Type-check only |
