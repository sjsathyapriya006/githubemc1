import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface RecommendRequest {
  project_id: string;
  intern_id: string;
  intern_skills?: string;
  task_difficulty?: string;
}

interface TaskRecommendation {
  title: string;
  instructions: string;
  deliverables: string;
  difficulty: string;
  review_criteria: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") as string;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") as string;
    const aiApiKey = Deno.env.get("AI_API_KEY");
    const aiApiUrl = Deno.env.get("AI_API_URL");

    const supabase = createClient(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false },
    });

    const body = (await req.json()) as RecommendRequest;
    if (!body.project_id || !body.intern_id) {
      return new Response(
        JSON.stringify({ error: "project_id and intern_id are required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Fetch project + intern details
    const { data: project, error: projError } = await supabase
      .from("projects")
      .select("title, description, requirements, tools, deliverables, deadline")
      .eq("id", body.project_id)
      .maybeSingle();
    if (projError || !project) {
      return new Response(
        JSON.stringify({ error: "Project not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { data: intern, error: internError } = await supabase
      .from("interns")
      .select("full_name, email, role, college, department")
      .eq("id", body.intern_id)
      .maybeSingle();
    if (internError || !intern) {
      return new Response(
        JSON.stringify({ error: "Intern not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const difficulty = body.task_difficulty || "intermediate";
    const internSkills = body.intern_skills || `${intern.role ?? ""} ${intern.department ?? ""}`.trim();

    // Build the prompt
    const prompt = `You are a technical mentor at Shop Fundlin. Recommend ONE personalized task for an intern based on the project and the intern's profile.

Project: ${project.title}
Description: ${project.description}
Requirements: ${(project.requirements as string[]).join(", ")}
Tools: ${(project.tools as string[]).join(", ")}
Expected deliverables: ${(project.deliverables as string[]).join(", ")}
Project deadline: ${project.deadline ?? "not set"}

Intern: ${intern.full_name}
Role: ${intern.role ?? "intern"}
Department: ${intern.department ?? "not specified"}
Skills: ${internSkills}
Requested difficulty: ${difficulty}

Return a JSON object with these exact fields:
{
  "title": "short task title",
  "instructions": "3-5 sentences of detailed, actionable instructions",
  "deliverables": "what the intern must submit",
  "difficulty": "${difficulty}",
  "review_criteria": "how the task will be evaluated (2-3 criteria)"
}
Return ONLY the JSON object, no other text.`;

    // If AI API is configured, call it. Otherwise use mock.
    let recommendation: TaskRecommendation;
    let usedMock = false;

    if (aiApiKey && aiApiUrl) {
      const aiResponse = await fetch(aiApiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${aiApiKey}`,
        },
        body: JSON.stringify({
          prompt,
          max_tokens: 600,
          temperature: 0.7,
        }),
      });

      if (!aiResponse.ok) {
        const errText = await aiResponse.text();
        return new Response(
          JSON.stringify({ error: `AI API error (${aiResponse.status}): ${errText}`, mock: false }),
          { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const aiData = await aiResponse.json();
      const text = aiData.choices?.[0]?.text ??
        aiData.choices?.[0]?.message?.content ??
        aiData.output ??
        JSON.stringify(aiData);

      try {
        // Try to extract JSON from the response
        const jsonMatch = text.match(/\{[\s\S]*\}/);
        recommendation = JSON.parse(jsonMatch ? jsonMatch[0] : text);
      } catch {
        // If parsing fails, wrap the text as instructions
        recommendation = {
          title: `Task for ${intern.full_name}`,
          instructions: text,
          deliverables: (project.deliverables as string[]).join(", "),
          difficulty,
          review_criteria: "Meets project requirements",
        };
      }
    } else {
      // Mock recommendation — clearly labeled
      usedMock = true;
      recommendation = {
        title: `${project.title}: Core Implementation Task`,
        instructions: `Based on the project "${project.title}", implement the core feature using ${(project.tools as string[]).join(", ")}. Focus on the following requirements: ${(project.requirements as string[]).join(", ")}. Start by setting up your development environment, then build the feature incrementally. Test your work at each step. This task is tailored for ${intern.full_name} with role ${intern.role ?? "intern"} and skills in ${internSkills}.`,
        deliverables: `Submit: ${(project.deliverables as string[]).join(", ")}. Include source code and a brief README.`,
        difficulty,
        review_criteria: `1. Meets stated requirements. 2. Code is clean and functional. 3. Deliverables match project expectations. Difficulty: ${difficulty}.`,
      };
    }

    return new Response(
      JSON.stringify({
        recommendation,
        mock: usedMock,
        intern_name: intern.full_name,
        project_title: project.title,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
