import { useEffect, useMemo, useState } from "react";
import { AdminLayout } from "../../components/Layouts";
import { supabase } from "../../lib/supabase";
import type {
  InternProgressReport,
  BatchCohortSummary,
  TaskCompletionBreakdown,
  SubmissionActivityTrend,
} from "../../types";

const taskStatusColor: Record<string, string> = {
  Assigned: "bg-brand-500",
  "In Progress": "bg-blue-500",
  Submitted: "bg-amber-500",
  Completed: "bg-emerald-500",
  Rejected: "bg-red-500",
  Recommended: "bg-slate-300",
  Approved: "bg-brand-300",
};

const completionColor = (rate: number) => {
  if (rate >= 80) return "text-emerald-600";
  if (rate >= 50) return "text-amber-600";
  if (rate > 0) return "text-orange-600";
  return "text-slate-400";
};

const completionBar = (rate: number) => {
  if (rate >= 80) return "bg-emerald-500";
  if (rate >= 50) return "bg-amber-500";
  if (rate > 0) return "bg-orange-500";
  return "bg-slate-300";
};

export default function AdminAnalytics() {
  const [interns, setInterns] = useState<InternProgressReport[]>([]);
  const [batches, setBatches] = useState<BatchCohortSummary[]>([]);
  const [taskBreakdown, setTaskBreakdown] = useState<TaskCompletionBreakdown[]>([]);
  const [trend, setTrend] = useState<SubmissionActivityTrend[]>([]);
  const [batchFilter, setBatchFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sortKey, setSortKey] = useState<"completion_rate" | "avg_review_score" | "total_submissions" | "full_name">("completion_rate");

  useEffect(() => {
    (async () => {
      const [internRes, batchRes, taskRes, trendRes] = await Promise.all([
        supabase.from("intern_progress_report").select("*"),
        supabase.from("batch_cohort_summary").select("*").order("batch_name"),
        supabase.from("task_completion_breakdown").select("*"),
        supabase.from("submission_activity_trend").select("*").limit(30),
      ]);

      if (internRes.error) setError(internRes.error.message);
      if (batchRes.error) setError(batchRes.error.message);

      setInterns((internRes.data as InternProgressReport[]) ?? []);
      setBatches((batchRes.data as BatchCohortSummary[]) ?? []);
      setTaskBreakdown((taskRes.data as TaskCompletionBreakdown[]) ?? []);
      setTrend((trendRes.data as SubmissionActivityTrend[]) ?? []);
      setLoading(false);
    })();
  }, []);

  const filteredInterns = useMemo(() => {
    const list = batchFilter
      ? interns.filter((i) => i.batch_id === batchFilter)
      : interns;
    return [...list].sort((a, b) => {
      if (sortKey === "full_name") return a.full_name.localeCompare(b.full_name);
      return (b[sortKey] ?? 0) - (a[sortKey] ?? 0);
    });
  }, [interns, batchFilter, sortKey]);

  const totalTasks = taskBreakdown.reduce((sum, t) => sum + t.count, 0);

  // Overall program metrics
  const programStats = useMemo(() => {
    const totalInterns = filteredInterns.length;
    const totalCompleted = filteredInterns.reduce((s, i) => s + i.completed_tasks, 0);
    const totalSubs = filteredInterns.reduce((s, i) => s + i.total_submissions, 0);
    const totalApproved = filteredInterns.reduce((s, i) => s + i.approved_submissions, 0);
    const scores = filteredInterns.filter((i) => i.avg_review_score != null);
    const avgScore =
      scores.length > 0
        ? (scores.reduce((s, i) => s + (i.avg_review_score ?? 0), 0) / scores.length).toFixed(1)
        : null;
    const avgCompletion =
      totalInterns > 0
        ? (filteredInterns.reduce((s, i) => s + i.completion_rate, 0) / totalInterns).toFixed(1)
        : "0";
    return { totalInterns, totalCompleted, totalSubs, totalApproved, avgScore, avgCompletion };
  }, [filteredInterns]);

  // Trend chart data (reversed for chronological order)
  const trendData = useMemo(() => [...trend].reverse(), [trend]);
  const maxTrendCount = Math.max(1, ...trendData.map((t) => t.submission_count));

  if (loading) {
    return (
      <AdminLayout>
        <div className="animate-pulse text-slate-400">Loading analytics…</div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <h1 className="text-2xl font-bold text-slate-900">Analytics</h1>
      <p className="mt-1 text-sm text-slate-500">
        Program-wide reporting: intern progress, cohort performance, task completion, and
        submission trends.
      </p>

      {error && (
        <div className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>
      )}

      {/* Batch filter */}
      <div className="mt-6">
        <label className="label">Filter by batch</label>
        <select
          className="input max-w-xs"
          value={batchFilter}
          onChange={(e) => setBatchFilter(e.target.value)}
        >
          <option value="">All batches</option>
          {batches.map((b) => (
            <option key={b.batch_id} value={b.batch_id}>
              {b.batch_name}
            </option>
          ))}
        </select>
      </div>

      {/* Program-level stat cards */}
      <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
        <div className="card p-4">
          <p className="text-xs font-semibold uppercase text-slate-400">Interns</p>
          <p className="mt-1 text-2xl font-bold text-slate-900">{programStats.totalInterns}</p>
        </div>
        <div className="card p-4">
          <p className="text-xs font-semibold uppercase text-slate-400">Tasks completed</p>
          <p className="mt-1 text-2xl font-bold text-emerald-600">{programStats.totalCompleted}</p>
        </div>
        <div className="card p-4">
          <p className="text-xs font-semibold uppercase text-slate-400">Submissions</p>
          <p className="mt-1 text-2xl font-bold text-brand-600">{programStats.totalSubs}</p>
        </div>
        <div className="card p-4">
          <p className="text-xs font-semibold uppercase text-slate-400">Approved</p>
          <p className="mt-1 text-2xl font-bold text-emerald-600">{programStats.totalApproved}</p>
        </div>
        <div className="card p-4">
          <p className="text-xs font-semibold uppercase text-slate-400">Avg completion</p>
          <p className="mt-1 text-2xl font-bold text-slate-900">{programStats.avgCompletion}%</p>
        </div>
        <div className="card p-4">
          <p className="text-xs font-semibold uppercase text-slate-400">Avg score</p>
          <p className="mt-1 text-2xl font-bold text-slate-900">
            {programStats.avgScore ?? "—"}
            {programStats.avgScore && "/10"}
          </p>
        </div>
      </div>

      {/* Task status breakdown */}
      {totalTasks > 0 && (
        <div className="mt-8 card p-6">
          <h2 className="text-lg font-semibold text-slate-900">Task status breakdown</h2>
          <div className="mt-4 space-y-3">
            {taskBreakdown.map((t) => {
              const pct = totalTasks > 0 ? Math.round((t.count / totalTasks) * 100) : 0;
              return (
                <div key={t.status}>
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium text-slate-700">{t.status}</span>
                    <span className="text-slate-500">
                      {t.count} {t.count === 1 ? "task" : "tasks"} ({pct}%)
                    </span>
                  </div>
                  <div className="mt-1 h-2 overflow-hidden rounded-full bg-slate-100">
                    <div
                      className={`h-full rounded-full ${taskStatusColor[t.status] ?? "bg-slate-400"}`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Batch cohort summary (when no batch filter) */}
      {!batchFilter && batches.length > 0 && (
        <div className="mt-8 card p-6">
          <h2 className="text-lg font-semibold text-slate-900">Batch cohort summary</h2>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-left text-xs font-semibold uppercase text-slate-400">
                  <th className="pb-2 pr-4">Batch</th>
                  <th className="pb-2 pr-4">Status</th>
                  <th className="pb-2 pr-4">Interns</th>
                  <th className="pb-2 pr-4">Completed</th>
                  <th className="pb-2 pr-4">Avg completion</th>
                  <th className="pb-2 pr-4">Avg score</th>
                  <th className="pb-2 pr-4">Submissions</th>
                </tr>
              </thead>
              <tbody>
                {batches.map((b) => (
                  <tr key={b.batch_id} className="border-b border-slate-100 last:border-0">
                    <td className="py-3 pr-4 font-medium text-slate-700">{b.batch_name}</td>
                    <td className="py-3 pr-4">
                      <span
                        className={`badge ${
                          b.batch_status === "active"
                            ? "bg-emerald-50 text-emerald-700"
                            : "bg-slate-100 text-slate-600"
                        }`}
                      >
                        {b.batch_status}
                      </span>
                    </td>
                    <td className="py-3 pr-4 text-slate-600">{b.intern_count}</td>
                    <td className="py-3 pr-4 text-slate-600">{b.completed_count}</td>
                    <td className="py-3 pr-4">
                      <span className={completionColor(b.avg_completion_rate ?? 0)}>
                        {b.avg_completion_rate ?? 0}%
                      </span>
                    </td>
                    <td className="py-3 pr-4 text-slate-600">
                      {b.avg_score != null ? `${b.avg_score}/10` : "—"}
                    </td>
                    <td className="py-3 pr-4 text-slate-600">{b.total_submissions ?? 0}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Submission activity trend */}
      {trendData.length > 0 && (
        <div className="mt-8 card p-6">
          <h2 className="text-lg font-semibold text-slate-900">Submission activity (last 30 days)</h2>
          <div className="mt-4 flex items-end gap-1" style={{ height: "120px" }}>
            {trendData.map((t, i) => {
              const heightPct = (t.submission_count / maxTrendCount) * 100;
              return (
                <div
                  key={i}
                  className="group relative flex flex-1 flex-col items-center justify-end"
                  style={{ minWidth: "8px" }}
                >
                  <div
                    className="w-full rounded-t bg-brand-400 transition-all hover:bg-brand-600"
                    style={{ height: `${Math.max(heightPct, 2)}%` }}
                  />
                  <div className="absolute -top-8 hidden whitespace-nowrap rounded bg-slate-800 px-2 py-1 text-xs text-white group-hover:block">
                    {new Date(t.activity_date).toLocaleDateString()}: {t.submission_count}
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-2 flex justify-between text-xs text-slate-400">
            <span>{new Date(trendData[0].activity_date).toLocaleDateString()}</span>
            <span>{new Date(trendData[trendData.length - 1].activity_date).toLocaleDateString()}</span>
          </div>
        </div>
      )}

      {/* Intern progress table */}
      <div className="mt-8 card p-6">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-lg font-semibold text-slate-900">Intern progress report</h2>
          <div className="flex items-center gap-2">
            <label className="text-xs font-medium text-slate-500">Sort by</label>
            <select
              className="input max-w-xs py-1 text-sm"
              value={sortKey}
              onChange={(e) => setSortKey(e.target.value as typeof sortKey)}
            >
              <option value="completion_rate">Completion rate</option>
              <option value="avg_review_score">Avg review score</option>
              <option value="total_submissions">Total submissions</option>
              <option value="full_name">Name (A-Z)</option>
            </select>
          </div>
        </div>

        {filteredInterns.length === 0 ? (
          <p className="mt-4 text-sm text-slate-400">No interns found.</p>
        ) : (
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-left text-xs font-semibold uppercase text-slate-400">
                  <th className="pb-2 pr-3">Intern</th>
                  <th className="pb-2 pr-3">Batch</th>
                  <th className="pb-2 pr-3">Status</th>
                  <th className="pb-2 pr-3">Tasks</th>
                  <th className="pb-2 pr-3">Done</th>
                  <th className="pb-2 pr-3">Subs</th>
                  <th className="pb-2 pr-3">Approved</th>
                  <th className="pb-2 pr-3">Avg score</th>
                  <th className="pb-2 pr-3">Completion</th>
                </tr>
              </thead>
              <tbody>
                {filteredInterns.map((i) => (
                  <tr key={i.intern_id} className="border-b border-slate-100 last:border-0">
                    <td className="py-3 pr-3">
                      <p className="font-medium text-slate-700">{i.full_name}</p>
                      <p className="text-xs text-slate-400">{i.intern_id_human}</p>
                    </td>
                    <td className="py-3 pr-3 text-slate-600">{i.batch_name ?? "—"}</td>
                    <td className="py-3 pr-3">
                      <span
                        className={`badge ${
                          i.intern_status === "Completed"
                            ? "bg-emerald-50 text-emerald-700"
                            : i.intern_status === "In Progress"
                              ? "bg-blue-50 text-blue-700"
                              : "bg-slate-100 text-slate-600"
                        }`}
                      >
                        {i.intern_status}
                      </span>
                    </td>
                    <td className="py-3 pr-3 text-slate-600">{i.total_tasks}</td>
                    <td className="py-3 pr-3 text-emerald-600">{i.completed_tasks}</td>
                    <td className="py-3 pr-3 text-slate-600">{i.total_submissions}</td>
                    <td className="py-3 pr-3 text-emerald-600">{i.approved_submissions}</td>
                    <td className="py-3 pr-3 text-slate-600">
                      {i.avg_review_score != null ? `${i.avg_review_score}/10` : "—"}
                    </td>
                    <td className="py-3 pr-3">
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-16 overflow-hidden rounded-full bg-slate-100">
                          <div
                            className={`h-full rounded-full ${completionBar(i.completion_rate)}`}
                            style={{ width: `${i.completion_rate}%` }}
                          />
                        </div>
                        <span className={`text-xs font-medium ${completionColor(i.completion_rate)}`}>
                          {i.completion_rate}%
                        </span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
