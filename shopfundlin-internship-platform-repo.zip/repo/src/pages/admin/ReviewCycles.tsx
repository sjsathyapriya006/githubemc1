import { useEffect, useMemo, useState } from "react";
import { AdminLayout } from "../../components/Layouts";
import { supabase } from "../../lib/supabase";
import type { ReviewCycleSummary, TimelineEvent } from "../../types";

const decisionBadge = (d: string | null) => {
  if (!d) return null;
  const cls =
    d === "approved"
      ? "bg-emerald-50 text-emerald-700"
      : d === "changes_requested"
        ? "bg-orange-50 text-orange-700"
        : "bg-red-50 text-red-700";
  return <span className={`badge ${cls}`}>{d.replace(/_/g, " ")}</span>;
};

const statusBadge = (s: string | null) => {
  if (!s) return null;
  const cls =
    s === "approved"
      ? "bg-emerald-50 text-emerald-700"
      : s === "under_review"
        ? "bg-blue-50 text-blue-700"
        : s === "changes_requested"
          ? "bg-orange-50 text-orange-700"
          : s === "rejected"
            ? "bg-red-50 text-red-700"
            : "bg-amber-50 text-amber-700";
  return <span className={`badge ${cls}`}>{s.replace(/_/g, " ")}</span>;
};

export default function AdminReviewCycles() {
  const [cycles, setCycles] = useState<ReviewCycleSummary[]>([]);
  const [timelineByTask, setTimelineByTask] = useState<Record<string, TimelineEvent[]>>({});
  const [filterComplete, setFilterComplete] = useState("");
  const [expandedTask, setExpandedTask] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    const { data, error: err } = await supabase
      .from("review_cycle_summary")
      .select("*")
      .order("last_activity_at", { ascending: false });

    if (err) {
      setError(err.message);
    } else {
      setCycles((data as ReviewCycleSummary[]) ?? []);
    }
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function loadTimeline(taskId: string) {
    const { data } = await supabase
      .from("submission_timeline")
      .select("*")
      .eq("task_id", taskId)
      .order("event_timestamp", { ascending: true });
    setTimelineByTask((prev) => ({
      ...prev,
      [taskId]: (data as TimelineEvent[]) ?? [],
    }));
  }

  const filtered = useMemo(() => {
    if (!filterComplete) return cycles;
    if (filterComplete === "active") return cycles.filter((c) => !c.cycle_complete);
    if (filterComplete === "complete") return cycles.filter((c) => c.cycle_complete);
    return cycles;
  }, [cycles, filterComplete]);

  function toggleExpand(taskId: string) {
    if (expandedTask === taskId) {
      setExpandedTask(null);
    } else {
      setExpandedTask(taskId);
      if (!timelineByTask[taskId]) loadTimeline(taskId);
    }
  }

  return (
    <AdminLayout>
      <h1 className="text-2xl font-bold text-slate-900">Review Cycles</h1>
      <p className="mt-1 text-sm text-slate-500">
        Track the full review progression for each task — submissions, revisions, and final
        decisions across multiple rounds.
      </p>

      {error && (
        <div className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>
      )}

      {/* Filter */}
      <div className="mt-6">
        <label className="label">Filter by cycle state</label>
        <select
          className="input max-w-xs"
          value={filterComplete}
          onChange={(e) => setFilterComplete(e.target.value)}
        >
          <option value="">All cycles</option>
          <option value="active">Active (in progress)</option>
          <option value="complete">Completed (approved)</option>
        </select>
      </div>

      {/* Summary stats */}
      <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
        <div className="card p-4">
          <p className="text-xs font-semibold uppercase text-slate-400">Total cycles</p>
          <p className="mt-1 text-2xl font-bold text-slate-900">{cycles.length}</p>
        </div>
        <div className="card p-4">
          <p className="text-xs font-semibold uppercase text-slate-400">Active</p>
          <p className="mt-1 text-2xl font-bold text-amber-600">
            {cycles.filter((c) => !c.cycle_complete).length}
          </p>
        </div>
        <div className="card p-4">
          <p className="text-xs font-semibold uppercase text-slate-400">Completed</p>
          <p className="mt-1 text-2xl font-bold text-emerald-600">
            {cycles.filter((c) => c.cycle_complete).length}
          </p>
        </div>
        <div className="card p-4">
          <p className="text-xs font-semibold uppercase text-slate-400">Avg rounds</p>
          <p className="mt-1 text-2xl font-bold text-brand-600">
            {cycles.length > 0
              ? (cycles.reduce((sum, c) => sum + c.total_submissions, 0) / cycles.length).toFixed(1)
              : "—"}
          </p>
        </div>
      </div>

      {/* Cycle list */}
      <div className="mt-6 space-y-4">
        {loading ? (
          <div className="card p-8 text-center text-slate-400">Loading review cycles…</div>
        ) : filtered.length === 0 ? (
          <div className="card p-8 text-center text-slate-400">
            No review cycles yet. Cycles appear here once interns start submitting work.
          </div>
        ) : (
          filtered.map((c) => {
            const expanded = expandedTask === c.task_id;
            const timeline = timelineByTask[c.task_id] ?? [];
            return (
              <div key={c.task_id} className="card p-5">
                <button
                  onClick={() => toggleExpand(c.task_id)}
                  className="flex w-full flex-wrap items-start justify-between gap-2 text-left"
                >
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-base font-semibold text-slate-900">{c.task_title}</h3>
                      {statusBadge(c.current_status)}
                      {decisionBadge(c.final_decision)}
                    </div>
                    <p className="mt-1 text-sm text-slate-500">
                      {c.intern_name} ({c.intern_id_human}) · {c.project_title}
                    </p>
                    <div className="mt-2 flex flex-wrap gap-3 text-xs text-slate-400">
                      <span>{c.total_submissions} round{c.total_submissions !== 1 ? "s" : ""}</span>
                      {c.highest_score != null && (
                        <span>Best score: {c.highest_score}/10</span>
                      )}
                      {c.avg_score != null && (
                        <span>Avg: {c.avg_score}/10</span>
                      )}
                      {c.has_changes_requested && (
                        <span className="text-orange-500">Revisions requested</span>
                      )}
                      {c.cycle_complete && (
                        <span className="text-emerald-600">Cycle complete</span>
                      )}
                      {c.first_submitted_at && (
                        <span>
                          Started {new Date(c.first_submitted_at).toLocaleDateString()}
                        </span>
                      )}
                    </div>
                  </div>
                  <span className="text-sm text-brand-600">
                    {expanded ? "Hide timeline" : "View timeline"}
                  </span>
                </button>

                {/* Timeline */}
                {expanded && (
                  <div className="mt-4 border-t border-slate-200 pt-4">
                    {timeline.length === 0 ? (
                      <p className="text-sm text-slate-400">Loading timeline…</p>
                    ) : (
                      <div className="space-y-3">
                        {timeline.map((evt, i) => (
                          <div key={i} className="flex gap-3">
                            {/* Vertical line */}
                            <div className="flex flex-col items-center">
                              <div
                                className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold ${
                                  evt.event_type === "submission"
                                    ? "bg-brand-100 text-brand-700"
                                    : evt.review_decision === "approved"
                                      ? "bg-emerald-100 text-emerald-700"
                                      : evt.review_decision === "changes_requested"
                                        ? "bg-orange-100 text-orange-700"
                                        : "bg-red-100 text-red-700"
                                }`}
                              >
                                {evt.event_type === "submission" ? "S" : "R"}
                              </div>
                              {i < timeline.length - 1 && (
                                <div className="h-full w-px flex-1 bg-slate-200" />
                              )}
                            </div>

                            {/* Event content */}
                            <div className="flex-1 pb-3">
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="text-sm font-medium text-slate-700">
                                  {evt.event_type === "submission"
                                    ? `Submission (round ${evt.submission_number})`
                                    : "Mentor review"}
                                </span>
                                {evt.event_type === "submission" && (
                                  statusBadge(evt.submission_status)
                                )}
                                {evt.event_type === "review" && (
                                  decisionBadge(evt.review_decision)
                                )}
                                {evt.review_score != null && (
                                  <span className="badge bg-brand-50 text-brand-700">
                                    {evt.review_score}/10
                                  </span>
                                )}
                              </div>
                              <p className="mt-0.5 text-xs text-slate-400">
                                {new Date(evt.event_timestamp).toLocaleString()}
                              </p>

                              {evt.event_type === "submission" && evt.submission_text && (
                                <p className="mt-1 text-sm text-slate-600">
                                  {evt.submission_text.length > 200
                                    ? evt.submission_text.substring(0, 200) + "…"
                                    : evt.submission_text}
                                </p>
                              )}
                              {evt.event_type === "submission" && evt.file_urls &&
                                evt.file_urls.length > 0 && (
                                  <p className="mt-1 text-xs text-brand-600">
                                    {evt.file_urls.length} link{evt.file_urls.length !== 1 ? "s" : ""} attached
                                  </p>
                                )}

                              {evt.event_type === "review" && evt.review_feedback && (
                                <p className="mt-1 text-sm text-slate-600">{evt.review_feedback}</p>
                              )}
                              {evt.event_type === "review" && evt.review_strengths && (
                                <p className="mt-1 text-xs text-emerald-700">
                                  Strengths: {evt.review_strengths}
                                </p>
                              )}
                              {evt.event_type === "review" && evt.review_improvement && (
                                <p className="mt-1 text-xs text-orange-700">
                                  Improvement: {evt.review_improvement}
                                </p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </AdminLayout>
  );
}
