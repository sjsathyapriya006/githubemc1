/*
# Phase 7 — Reporting & Analytics Views

## Purpose
Adds aggregation views that power the admin analytics dashboard:
- Per-intern progress across all tasks, submissions, and reviews
- Per-batch cohort summary (completion rates, avg scores)
- Task completion breakdown by status
- Submission activity trend (counts per day)

All views are read-only and inherit RLS via security_invoker.

## New views

### intern_progress_report
One row per intern with aggregated metrics:
- intern details (name, email, batch, status)
- total_tasks, completed_tasks, in_progress_tasks, assigned_tasks
- total_submissions, approved_submissions, changes_requested_count
- avg_review_score, highest_score
- first_submission_date, last_activity_date
- completion_rate (completed_tasks / total_tasks * 100)

### batch_cohort_summary
One row per batch with aggregated metrics for interns in that batch.

### task_completion_breakdown
One row per task status with counts.

### submission_activity_trend
One row per day with submission count.

## Security
- All views are security_invoker, granted SELECT to authenticated.
*/

-- ── intern_progress_report ──
CREATE OR REPLACE VIEW intern_progress_report AS
SELECT
  i.id AS intern_id,
  i.intern_id AS intern_id_human,
  i.full_name,
  i.email,
  i.college,
  i.department,
  i.role,
  i.status AS intern_status,
  i.batch_id,
  b.name AS batch_name,
  COUNT(DISTINCT t.id) AS total_tasks,
  COUNT(DISTINCT t.id) FILTER (WHERE t.status = 'Completed') AS completed_tasks,
  COUNT(DISTINCT t.id) FILTER (WHERE t.status IN ('In Progress', 'Submitted')) AS in_progress_tasks,
  COUNT(DISTINCT t.id) FILTER (WHERE t.status = 'Assigned') AS assigned_tasks,
  COUNT(DISTINCT t.id) FILTER (WHERE t.status = 'Rejected') AS rejected_tasks,
  COUNT(DISTINCT s.id) AS total_submissions,
  COUNT(DISTINCT s.id) FILTER (WHERE s.status = 'approved') AS approved_submissions,
  COUNT(DISTINCT s.id) FILTER (WHERE s.status = 'changes_requested') AS changes_requested_count,
  ROUND(AVG(sr.score), 1) AS avg_review_score,
  MAX(sr.score) AS highest_score,
  MIN(s.submitted_at) AS first_submission_date,
  MAX(s.submitted_at) AS last_submission_date,
  MAX(sr.created_at) AS last_review_date,
  CASE
    WHEN COUNT(DISTINCT t.id) > 0
    THEN ROUND(
      COUNT(DISTINCT t.id) FILTER (WHERE t.status = 'Completed')::numeric /
      COUNT(DISTINCT t.id)::numeric * 100, 1
    )
    ELSE 0
  END AS completion_rate
FROM interns i
LEFT JOIN batches b ON b.id = i.batch_id
LEFT JOIN tasks t ON t.intern_id = i.id
LEFT JOIN submissions s ON s.intern_id = i.id
LEFT JOIN submission_reviews sr ON sr.submission_id = s.id
GROUP BY i.id, i.intern_id, i.full_name, i.email, i.college, i.department, i.role, i.status, i.batch_id, b.name;

ALTER VIEW intern_progress_report SET (security_invoker = true);
GRANT SELECT ON intern_progress_report TO authenticated;
GRANT SELECT ON intern_progress_report TO service_role;

-- ── batch_cohort_summary ──
CREATE OR REPLACE VIEW batch_cohort_summary AS
SELECT
  b.id AS batch_id,
  b.name AS batch_name,
  b.start_date,
  b.end_date,
  b.status AS batch_status,
  COUNT(DISTINCT i.id) AS intern_count,
  COUNT(DISTINCT i.id) FILTER (WHERE i.status = 'Completed') AS completed_count,
  COUNT(DISTINCT i.id) FILTER (WHERE i.status IN ('In Progress', 'Task Assigned', 'Submitted', 'Under Review', 'Changes Requested', 'Resubmitted')) AS in_progress_count,
  ROUND(AVG(ipr.completion_rate), 1) AS avg_completion_rate,
  ROUND(AVG(ipr.avg_review_score), 1) AS avg_score,
  SUM(ipr.total_submissions) AS total_submissions,
  SUM(ipr.completed_tasks) AS total_completed_tasks
FROM batches b
LEFT JOIN interns i ON i.batch_id = b.id
LEFT JOIN intern_progress_report ipr ON ipr.intern_id = i.id
GROUP BY b.id, b.name, b.start_date, b.end_date, b.status;

ALTER VIEW batch_cohort_summary SET (security_invoker = true);
GRANT SELECT ON batch_cohort_summary TO authenticated;
GRANT SELECT ON batch_cohort_summary TO service_role;

-- ── task_completion_breakdown ──
CREATE OR REPLACE VIEW task_completion_breakdown AS
SELECT
  t.status,
  COUNT(*) AS count
FROM tasks t
GROUP BY t.status
ORDER BY
  CASE t.status
    WHEN 'Assigned' THEN 1
    WHEN 'In Progress' THEN 2
    WHEN 'Submitted' THEN 3
    WHEN 'Completed' THEN 4
    WHEN 'Rejected' THEN 5
    WHEN 'Recommended' THEN 6
    WHEN 'Approved' THEN 7
    ELSE 99
  END;

ALTER VIEW task_completion_breakdown SET (security_invoker = true);
GRANT SELECT ON task_completion_breakdown TO authenticated;
GRANT SELECT ON task_completion_breakdown TO service_role;

-- ── submission_activity_trend ──
CREATE OR REPLACE VIEW submission_activity_trend AS
SELECT
  DATE(s.submitted_at) AS activity_date,
  COUNT(*) AS submission_count,
  COUNT(DISTINCT s.intern_id) AS unique_interns
FROM submissions s
GROUP BY DATE(s.submitted_at)
ORDER BY activity_date DESC;

ALTER VIEW submission_activity_trend SET (security_invoker = true);
GRANT SELECT ON submission_activity_trend TO authenticated;
GRANT SELECT ON submission_activity_trend TO service_role;