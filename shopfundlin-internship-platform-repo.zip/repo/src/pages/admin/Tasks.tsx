import { useEffect, useMemo, useState } from "react";
import { AdminLayout } from "../../components/Layouts";
import { supabase } from "../../lib/supabase";
import { recommendTask } from "../../lib/ai";
import type { Intern, Project, Task, TaskWithRelations } from "../../types";

const emptyDraft = {
  title: "",
  instructions: "",
  deliverables: "",
  difficulty: "intermediate",
  deadline: "",
  review_criteria: "",
};

export default function AdminTasks() {
  const [tasks, setTasks] = useState<TaskWithRelations[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [interns, setInterns] = useState<Intern[]>([]);
  const [filterProject, setFilterProject] = useState("");
  const [filterIntern, setFilterIntern] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  // AI recommendation panel state
  const [aiOpen, setAiOpen] = useState(false);
  const [aiProject, setAiProject] = useState("");
  const [aiIntern, setAiIntern] = useState("");
  const [aiDifficulty, setAiDifficulty] = useState("intermediate");
  const [aiSkills, setAiSkills] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiMock, setAiMock] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [draft, setDraft] = useState(emptyDraft);

  // Edit state
  const [editingTask, setEditingTask] = useState<TaskWithRelations | null>(null);

  async function load() {
    const [{ data: taskRows }, { data: projRows }, { data: internRows }] = await Promise.all([
      supabase.from("tasks_with_relations").select("*").order("created_at", { ascending: false }),
      supabase.from("projects").select("*").order("created_at", { ascending: false }),
      supabase.from("interns").select("*").order("created_at", { ascending: false }),
    ]);
    setTasks((taskRows as TaskWithRelations[]) ?? []);
    setProjects((projRows as Project[]) ?? []);
    setInterns((internRows as Intern[]) ?? []);
  }

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    return tasks.filter(
      (t) =>
        (!filterProject || t.project_id === filterProject) &&
        (!filterIntern || t.intern_id === filterIntern)
    );
  }, [tasks, filterProject, filterIntern]);

  const statusBadgeCls = (s: string) => {
    switch (s) {
      case "Assigned": return "bg-brand-50 text-brand-700";
      case "Approved": return "bg-emerald-50 text-emerald-700";
      case "Recommended": return "bg-amber-50 text-amber-700";
      case "Completed": return "bg-emerald-100 text-emerald-800";
      case "Rejected": return "bg-red-50 text-red-700";
      default: return "bg-slate-100 text-slate-600";
    }
  };

  async function handleRecommend() {
    setAiError(null);
    if (!aiProject || !aiIntern) {
      setAiError("Select a project and an intern.");
      return;
    }
    setAiLoading(true);
    try {
      const result = await recommendTask({
        project_id: aiProject,
        intern_id: aiIntern,
        intern_skills: aiSkills,
        task_difficulty: aiDifficulty,
      });
      setAiMock(result.mock);
      setDraft({
        title: result.recommendation.title,
        instructions: result.recommendation.instructions,
        deliverables: result.recommendation.deliverables,
        difficulty: result.recommendation.difficulty || aiDifficulty,
        deadline: projects.find((p) => p.id === aiProject)?.deadline ?? "",
        review_criteria: result.recommendation.review_criteria,
      });
    } catch (err) {
      setAiError(err instanceof Error ? err.message : "Recommendation failed.");
    }
    setAiLoading(false);
  }

  async function handleSaveDraft(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!draft.title.trim() || !aiProject || !aiIntern) {
      setError("Title, project, and intern are required.");
      return;
    }
    setBusy(true);
    const payload = {
      project_id: aiProject,
      intern_id: aiIntern,
      title: draft.title.trim(),
      instructions: draft.instructions.trim(),
      deliverables: draft.deliverables.trim(),
      difficulty: draft.difficulty || null,
      deadline: draft.deadline || null,
      review_criteria: draft.review_criteria.trim() || null,
      status: "Recommended" as const,
      ai_generated: true,
    };
    const { error } = await supabase.from("tasks").insert(payload);
    setBusy(false);
    if (error) {
      setError(error.message);
      return;
    }
    setDraft(emptyDraft);
    setAiOpen(false);
    setAiProject("");
    setAiIntern("");
    setAiSkills("");
    load();
  }

  async function updateTaskStatus(task: Task, status: string) {
    setError(null);
    const { error } = await supabase.rpc("admin_update_task_status", {
      p_id: task.id,
      p_status: status,
    });
    if (error) {
      setError(error.message);
      return;
    }
    load();
  }

  async function handleEditSave(e: React.FormEvent) {
    e.preventDefault();
    if (!editingTask) return;
    setError(null);
    setBusy(true);
    const { error } = await supabase.rpc("admin_update_task", {
      p_id: editingTask.id,
      p_title: editingTask.title,
      p_instructions: editingTask.instructions,
      p_deliverables: editingTask.deliverables,
      p_difficulty: editingTask.difficulty,
      p_deadline: editingTask.deadline,
      p_review_criteria: editingTask.review_criteria,
      p_status: editingTask.status,
    });
    setBusy(false);
    if (error) {
      setError(error.message);
      return;
    }
    setEditingTask(null);
    load();
  }

  const projectName = (id: string) => projects.find((p) => p.id === id)?.title ?? "—";
  const internName = (t: TaskWithRelations) => t.intern_name ?? "—";

  return (
    <AdminLayout>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Tasks</h1>
          <p className="mt-1 text-sm text-slate-500">Use AI to recommend tasks, then review, edit, approve, and assign.</p>
        </div>
        <button
          onClick={() => {
            setAiOpen((s) => !s);
            setDraft(emptyDraft);
            setAiError(null);
          }}
          className="btn-primary"
        >
          {aiOpen ? "Close" : "Recommend task with AI"}
        </button>
      </div>

      {error && <div className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}

      {aiOpen && (
        <div className="card mt-6 p-6">
          <h2 className="text-lg font-semibold text-slate-900">AI Task Recommendation</h2>
          <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-3">
            <div>
              <label className="label">Project *</label>
              <select className="input" value={aiProject} onChange={(e) => setAiProject(e.target.value)}>
                <option value="">— Select —</option>
                {projects.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Intern *</label>
              <select className="input" value={aiIntern} onChange={(e) => setAiIntern(e.target.value)}>
                <option value="">— Select —</option>
                {interns.map((i) => <option key={i.id} value={i.id}>{i.full_name} ({i.intern_id})</option>)}
              </select>
            </div>
            <div>
              <label className="label">Difficulty</label>
              <select className="input" value={aiDifficulty} onChange={(e) => setAiDifficulty(e.target.value)}>
                <option value="beginner">Beginner</option>
                <option value="intermediate">Intermediate</option>
                <option value="advanced">Advanced</option>
              </select>
            </div>
            <div className="md:col-span-3">
              <label className="label">Intern skills (optional — helps the AI personalize)</label>
              <input className="input" value={aiSkills} onChange={(e) => setAiSkills(e.target.value)} placeholder="e.g. JavaScript, React, Python" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-3">
            <button onClick={handleRecommend} disabled={aiLoading} className="btn-primary">
              {aiLoading ? "Generating…" : "Generate recommendation"}
            </button>
            {aiMock && (
              <span className="badge bg-amber-50 text-amber-700">Mock mode — AI_API_KEY not set</span>
            )}
            {aiError && <span className="text-sm text-red-600">{aiError}</span>}
          </div>

          {draft.title && (
            <form onSubmit={handleSaveDraft} className="mt-6 border-t border-slate-200 pt-6">
              <h3 className="text-sm font-semibold uppercase text-slate-500">Review &amp; edit recommendation</h3>
              <div className="mt-3 grid grid-cols-1 gap-4">
                <div>
                  <label className="label">Task title</label>
                  <input className="input" value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} />
                </div>
                <div>
                  <label className="label">Instructions</label>
                  <textarea rows={4} className="input" value={draft.instructions} onChange={(e) => setDraft({ ...draft, instructions: e.target.value })} />
                </div>
                <div>
                  <label className="label">Deliverables</label>
                  <textarea rows={2} className="input" value={draft.deliverables} onChange={(e) => setDraft({ ...draft, deliverables: e.target.value })} />
                </div>
                <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                  <div>
                    <label className="label">Difficulty</label>
                    <select className="input" value={draft.difficulty} onChange={(e) => setDraft({ ...draft, difficulty: e.target.value })}>
                      <option value="beginner">Beginner</option>
                      <option value="intermediate">Intermediate</option>
                      <option value="advanced">Advanced</option>
                    </select>
                  </div>
                  <div>
                    <label className="label">Deadline</label>
                    <input type="date" className="input" value={draft.deadline} onChange={(e) => setDraft({ ...draft, deadline: e.target.value })} />
                  </div>
                  <div>
                    <label className="label">Review criteria</label>
                    <input className="input" value={draft.review_criteria} onChange={(e) => setDraft({ ...draft, review_criteria: e.target.value })} />
                  </div>
                </div>
              </div>
              <div className="mt-4 flex gap-2">
                <button type="submit" disabled={busy} className="btn-primary">
                  {busy ? "Saving…" : "Save as recommended task"}
                </button>
              </div>
            </form>
          )}
        </div>
      )}

      {/* Filters */}
      <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
        <div>
          <label className="label">Filter by project</label>
          <select className="input" value={filterProject} onChange={(e) => setFilterProject(e.target.value)}>
            <option value="">All projects</option>
            {projects.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}
          </select>
        </div>
        <div>
          <label className="label">Filter by intern</label>
          <select className="input" value={filterIntern} onChange={(e) => setFilterIntern(e.target.value)}>
            <option value="">All interns</option>
            {interns.map((i) => <option key={i.id} value={i.id}>{i.full_name}</option>)}
          </select>
        </div>
      </div>

      {/* Task list */}
      <div className="mt-6 space-y-4">
        {filtered.length === 0 && (
          <div className="card p-8 text-center text-slate-400">
            No tasks yet. Use AI to recommend a task for an intern.
          </div>
        )}
        {filtered.map((t) => (
          <div key={t.id} className="card p-5">
            {editingTask?.id === t.id ? (
              <form onSubmit={handleEditSave} className="space-y-3">
                <input className="input" value={editingTask.title} onChange={(e) => setEditingTask({ ...editingTask, title: e.target.value })} />
                <textarea rows={3} className="input" value={editingTask.instructions} onChange={(e) => setEditingTask({ ...editingTask, instructions: e.target.value })} />
                <textarea rows={2} className="input" value={editingTask.deliverables} onChange={(e) => setEditingTask({ ...editingTask, deliverables: e.target.value })} />
                <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
                  <select className="input" value={editingTask.difficulty ?? ""} onChange={(e) => setEditingTask({ ...editingTask, difficulty: e.target.value })}>
                    <option value="">Difficulty</option>
                    <option value="beginner">Beginner</option>
                    <option value="intermediate">Intermediate</option>
                    <option value="advanced">Advanced</option>
                  </select>
                  <input type="date" className="input" value={editingTask.deadline ?? ""} onChange={(e) => setEditingTask({ ...editingTask, deadline: e.target.value })} />
                  <input className="input" value={editingTask.review_criteria ?? ""} onChange={(e) => setEditingTask({ ...editingTask, review_criteria: e.target.value })} placeholder="Review criteria" />
                </div>
                <div className="flex gap-2">
                  <button type="submit" disabled={busy} className="btn-primary text-xs">{busy ? "Saving…" : "Save"}</button>
                  <button type="button" onClick={() => setEditingTask(null)} className="btn-secondary text-xs">Cancel</button>
                </div>
              </form>
            ) : (
              <>
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-base font-semibold text-slate-900">{t.title}</h3>
                      <span className={`badge ${statusBadgeCls(t.status)}`}>{t.status}</span>
                      {t.ai_generated && <span className="badge bg-violet-50 text-violet-700">AI</span>}
                    </div>
                    <p className="mt-1 text-sm text-slate-500">
                      {internName(t)} · {projectName(t.project_id)}
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    <button onClick={() => setEditingTask(t)} className="btn-secondary text-xs">Edit</button>
                    {t.status === "Recommended" && (
                      <>
                        <button onClick={() => updateTaskStatus(t, "Approved")} className="btn-secondary text-xs">Approve</button>
                        <button onClick={() => updateTaskStatus(t, "Rejected")} className="btn-secondary text-xs text-red-600">Reject</button>
                      </>
                    )}
                    {t.status === "Approved" && (
                      <button onClick={() => updateTaskStatus(t, "Assigned")} className="btn-primary text-xs">Assign</button>
                    )}
                    {t.status === "Assigned" && (
                      <button onClick={() => updateTaskStatus(t, "Completed")} className="btn-secondary text-xs">Mark complete</button>
                    )}
                  </div>
                </div>
                {t.instructions && (
                  <p className="mt-2 text-sm text-slate-600">{t.instructions}</p>
                )}
                <div className="mt-3 flex flex-wrap gap-3 text-xs text-slate-400">
                  {t.difficulty && <span>Difficulty: {t.difficulty}</span>}
                  {t.deadline && <span>Deadline: {t.deadline}</span>}
                </div>
              </>
            )}
          </div>
        ))}
      </div>
    </AdminLayout>
  );
}
