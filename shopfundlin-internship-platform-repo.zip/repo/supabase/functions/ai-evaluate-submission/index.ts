import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface EvaluateRequest {
  submission_id: string;
}

interface AIEvaluationResult {
  recommended_decision: "approved" | "changes_requested" | "rejected";
  score: number;
  feedback: string;
  strengths: string;
  areas_for_improvement: string;
  criteria_analysis: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") as string;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") as string;
    const aiApiKey = Deno.env.get("AI_API_KEY");
    const aiApiUrl = Deno.env.get("AI_API_URL");

    const supabase = createClient(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false },
    });

    const body = (await req.json()) as EvaluateRequest;
    if (!body.submission_id) {
      return new Response(
        JSON.stringify({ error: "submission_id is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Fetch submission with task, project, and intern details
    const { data: submission, error: subError } = await supabase
      .from("submissions_with_details")
      .select("*")
      .eq("id", body.submission_id)
      .maybeSingle();

    if (subError || !submission) {
      return new Response(
        JSON.stringify({ error: "Submission not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Build the evaluation prompt
    const prompt = `You are a senior technical reviewer evaluating an intern's submission at Shop Fundlin. Analyze the submission against the task requirements and review criteria, then provide a structured evaluation.

Task: ${submission.task_title}
Task instructions: ${submission.task_instructions ?? "N/A"}
Expected deliverables: ${submission.task_deliverables ?? "N/A"}
Review criteria: ${submission.task_review_criteria ?? "N/A"}

Intern: ${submission.intern_name}
Project: ${submission.project_title}

Submission (attempt #${submission.submission_number}):
${submission.submission_text || "(no written text provided)"}

Submitted links:
${(submission.file_urls as string[]).join("\n") || "(no links provided)"}

Evaluate this submission and return a JSON object with these exact fields:
{
  "recommended_decision": "approved" | "changes_requested" | "rejected",
  "score": <1-10 integer>,
  "feedback": "2-4 sentences of overall assessment",
  "strengths": "what was done well (1-3 points)",
  "areas_for_improvement": "what needs work (1-3 points)",
  "criteria_analysis": "brief analysis of how well each review criterion was met"
}

Guidelines:
- "approved" = meets requirements, good quality work
- "changes_requested" = partially meets requirements, needs revision
- "rejected" = does not meet requirements, major issues
- Score 7-10 for approved, 4-6 for changes requested, 1-3 for rejected
- Be specific and constructive — reference the actual submission content
- If the submission text is empty and no links provided, recommend "changes_requested" with score 3

Return ONLY the JSON object, no other text.`;

    let evaluation: AIEvaluationResult;
    let usedMock = false;

    if (aiApiKey && aiApiUrl) {
      const aiResponse = await fetch(aiApiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${aiApiKey}`,
        },
        body: JSON.stringify({
          prompt,
          max_tokens: 800,
          temperature: 0.3,
        }),
      });

      if (!aiResponse.ok) {
        const errText = await aiResponse.text();
        return new Response(
          JSON.stringify({ error: `AI API error (${aiResponse.status}): ${errText}` }),
          { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const aiData = await aiResponse.json();
      const text =
        aiData.choices?.[0]?.text ??
        aiData.choices?.[0]?.message?.content ??
        aiData.output ??
        JSON.stringify(aiData);

      try {
        const jsonMatch = text.match(/\{[\s\S]*\}/);
        evaluation = JSON.parse(jsonMatch ? jsonMatch[0] : text);
      } catch {
        evaluation = {
          recommended_decision: "changes_requested",
          score: 5,
          feedback: text.substring(0, 500),
          strengths: "Unable to parse AI response into structured evaluation.",
          areas_for_improvement: "Please re-run the evaluation.",
          criteria_analysis: "Parsing error — raw AI output used as feedback.",
        };
      }
    } else {
      // Mock evaluation — heuristic based on submission content
      usedMock = true;
      const hasText = submission.submission_text && submission.submission_text.length > 50;
      const hasLinks = (submission.file_urls as string[]).length > 0;
      const textLen = submission.submission_text?.length ?? 0;

      if (hasText && hasLinks && textLen > 200) {
        evaluation = {
          recommended_decision: "approved",
          score: 8,
          feedback: `The submission for "${submission.task_title}" demonstrates a solid understanding of the requirements. The intern provided a detailed written explanation along with relevant links. The work aligns well with the expected deliverables and meets the review criteria.`,
          strengths: `1. Clear and detailed written submission showing thought process. 2. Provided supporting links demonstrating completed work. 3. Submission addresses the core task requirements for ${submission.project_title}.`,
          areas_for_improvement: `1. Could add more documentation or comments. 2. Consider edge cases not covered in the submission. 3. Add tests if applicable.`,
          criteria_analysis: `Review criteria: "${submission.task_review_criteria ?? "N/A"}". The submission appears to meet the stated criteria based on the content provided. The intern's explanation shows understanding of the task scope.`,
        };
      } else if (hasText || hasLinks) {
        evaluation = {
          recommended_decision: "changes_requested",
          score: 5,
          feedback: `The submission for "${submission.task_title}" partially meets the requirements. The intern has started the work but the submission could be more comprehensive. Additional detail and supporting materials would strengthen the submission.`,
          strengths: `1. Submitted work showing effort toward the task. 2. Addressed the task topic.`,
          areas_for_improvement: `1. Provide a more detailed written explanation of your approach and decisions. 2. Include all relevant links (GitHub, docs, etc.). 3. Ensure all deliverables are addressed.`,
          criteria_analysis: `Review criteria: "${submission.task_review_criteria ?? "N/A"}". The submission partially meets the criteria — some areas are addressed but others need more work.`,
        };
      } else {
        evaluation = {
          recommended_decision: "changes_requested",
          score: 3,
          feedback: `The submission for "${submission.task_title}" is insufficient. No meaningful content or links were provided. The intern should resubmit with a detailed explanation of their work and all relevant links.`,
          strengths: `1. The intern submitted on time, showing engagement with the process.`,
          areas_for_improvement: `1. Provide a detailed written submission explaining your work. 2. Include links to your code, documents, or other deliverables. 3. Address each requirement from the task instructions.`,
          criteria_analysis: `Review criteria: "${submission.task_review_criteria ?? "N/A"}". Cannot evaluate — submission is essentially empty. Please resubmit with actual work.`,
        };
      }
    }

    // Ensure score is within valid range
    if (evaluation.score < 1) evaluation.score = 1;
    if (evaluation.score > 10) evaluation.score = 10;

    // Validate decision
    const validDecisions = ["approved", "changes_requested", "rejected"];
    if (!validDecisions.includes(evaluation.recommended_decision)) {
      evaluation.recommended_decision = "changes_requested";
    }

    // Store the evaluation
    const { data: inserted, error: insertError } = await supabase
      .from("ai_evaluations")
      .insert({
        submission_id: body.submission_id,
        task_id: submission.task_id,
        intern_id: submission.intern_id,
        recommended_decision: evaluation.recommended_decision,
        score: evaluation.score,
        feedback: evaluation.feedback,
        strengths: evaluation.strengths,
        areas_for_improvement: evaluation.areas_for_improvement,
        criteria_analysis: evaluation.criteria_analysis,
        mock: usedMock,
      })
      .select("id")
      .single();

    if (insertError) {
      return new Response(
        JSON.stringify({ error: `Failed to store evaluation: ${insertError.message}` }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({
        evaluation_id: inserted.id,
        evaluation,
        mock: usedMock,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
