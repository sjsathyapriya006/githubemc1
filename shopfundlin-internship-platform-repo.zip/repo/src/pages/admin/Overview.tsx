import { useEffect, useState } from "react";
import { AdminLayout } from "../../components/Layouts";
import { StatCard } from "../../components/StatCard";
import { supabase } from "../../lib/supabase";

interface Overview {
  totalInterns: number;
  activeBatches: number;
  completed: number;
  registered: number;
  pendingSubmissions: number;
  approvedSubmissions: number;
  activeCycles: number;
  completedCycles: number;
  assignedProjects: number;
  inProgressProjects: number;
  revisionsPending: number;
  completedProjects: number;
}

export default function AdminOverview() {
  const [stats, setStats] = useState<Overview | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      const [
        { count: totalInterns },
        { count: activeBatches },
        { count: completed },
        { count: registered },
        { count: pendingSubmissions },
        { count: approvedSubmissions },
        { data: cycleData },
        { count: assignedProjects },
        { count: inProgressProjects },
        { count: revisionsPending },
        { count: completedProjects },
      ] = await Promise.all([
        supabase.from("interns").select("*", { count: "exact", head: true }),
        supabase.from("batches").select("*", { count: "exact", head: true }).eq("status", "active"),
        supabase.from("interns").select("*", { count: "exact", head: true }).eq("status", "Completed"),
        supabase.from("interns").select("*", { count: "exact", head: true }).eq("status", "Registered"),
        supabase
          .from("submissions")
          .select("*", { count: "exact", head: true })
          .in("status", ["submitted", "resubmitted", "under_review"]),
        supabase
          .from("submissions")
          .select("*", { count: "exact", head: true })
          .eq("status", "approved"),
        supabase.from("review_cycle_summary").select("cycle_complete"),
        supabase.from("project_assignments").select("*", { count: "exact", head: true }),
        supabase.from("project_assignments").select("*", { count: "exact", head: true }).in("status", ["In Progress", "Submitted", "Resubmitted"]),
        supabase.from("project_assignments").select("*", { count: "exact", head: true }).eq("status", "Revision Requested"),
        supabase.from("project_assignments").select("*", { count: "exact", head: true }).in("status", ["Approved", "Completed"]),
      ]);
      const cycles = (cycleData as { cycle_complete: boolean | null }[]) ?? [];
      setStats({
        totalInterns: totalInterns ?? 0,
        activeBatches: activeBatches ?? 0,
        completed: completed ?? 0,
        registered: registered ?? 0,
        pendingSubmissions: pendingSubmissions ?? 0,
        approvedSubmissions: approvedSubmissions ?? 0,
        activeCycles: cycles.filter((c) => !c.cycle_complete).length,
        completedCycles: cycles.filter((c) => c.cycle_complete).length,
        assignedProjects: assignedProjects ?? 0,
        inProgressProjects: inProgressProjects ?? 0,
        revisionsPending: revisionsPending ?? 0,
        completedProjects: completedProjects ?? 0,
      });
      setError(null);
    })();
  }, []);

  return (
    <AdminLayout>
      <h1 className="text-2xl font-bold text-slate-900">Overview</h1>
      <p className="mt-1 text-sm text-slate-500">Snapshot of your internship program at Shop Fundlin.</p>
      {error && (
        <div className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>
      )}
      <div className="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-3">
        <StatCard label="Total interns" value={stats?.totalInterns ?? "—"} accent="brand" />
        <StatCard label="Active batches" value={stats?.activeBatches ?? "—"} accent="emerald" />
        <StatCard label="Newly registered" value={stats?.registered ?? "—"} accent="amber" />
        <StatCard label="Completed" value={stats?.completed ?? "—"} accent="slate" />
        <StatCard
          label="Submissions pending review"
          value={stats?.pendingSubmissions ?? "—"}
          accent="amber"
        />
        <StatCard
          label="Submissions approved"
          value={stats?.approvedSubmissions ?? "—"}
          accent="emerald"
        />
        <StatCard
          label="Active review cycles"
          value={stats?.activeCycles ?? "—"}
          accent="amber"
        />
        <StatCard
          label="Completed cycles"
          value={stats?.completedCycles ?? "—"}
          accent="emerald"
        />
        <StatCard
          label="Projects assigned"
          value={stats?.assignedProjects ?? "—"}
          accent="brand"
        />
        <StatCard
          label="Projects in progress"
          value={stats?.inProgressProjects ?? "—"}
          accent="amber"
        />
        <StatCard
          label="Revisions pending"
          value={stats?.revisionsPending ?? "—"}
          accent="amber"
        />
        <StatCard
          label="Projects completed"
          value={stats?.completedProjects ?? "—"}
          accent="emerald"
        />
      </div>

      <div className="mt-8 card p-6">
        <h2 className="text-lg font-semibold text-slate-900">What's next</h2>
        <ul className="mt-3 space-y-2 text-sm text-slate-600">
          <li>Add interns from the Interns tab, or let interns self-register.</li>
          <li>Create a batch to group interns by cohort.</li>
          <li>Create projects and use AI to recommend personalized tasks per intern.</li>
          <li>Assign projects to interns individually from the Assignments tab.</li>
          <li>Review intern submissions and provide structured feedback with category ratings.</li>
          <li>Track repeatable review cycles — multiple rounds of submit, review, and resubmit.</li>
          <li>Schedule review meetings with Google Meet and send invitation emails.</li>
          <li>Manage email templates and review the email log for delivery status.</li>
          <li>Check the Analytics tab for program-wide reporting and cohort performance.</li>
        </ul>
      </div>
    </AdminLayout>
  );
}
