import { useEffect, useState } from "react";
import { AdminLayout } from "../../components/Layouts";
import { supabase } from "../../lib/supabase";
import type { Batch } from "../../types";

export default function AdminBatches() {
  const [batches, setBatches] = useState<Batch[]>([]);
  const [name, setName] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function load() {
    const { data } = await supabase.from("batches").select("*").order("created_at", { ascending: false });
    setBatches((data as Batch[]) ?? []);
  }

  useEffect(() => {
    load();
  }, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!name.trim()) {
      setError("Batch name is required.");
      return;
    }
    setBusy(true);
    const { error } = await supabase.from("batches").insert({
      name: name.trim(),
      start_date: startDate || null,
      end_date: endDate || null,
    });
    setBusy(false);
    if (error) {
      setError(error.message);
      return;
    }
    setName("");
    setStartDate("");
    setEndDate("");
    load();
  }

  return (
    <AdminLayout>
      <h1 className="text-2xl font-bold text-slate-900">Batches</h1>
      <p className="mt-1 text-sm text-slate-500">Group interns into cohorts by start period.</p>

      <form onSubmit={handleCreate} className="card mt-6 p-6">
        <h2 className="text-lg font-semibold text-slate-900">Create batch</h2>
        <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-3">
          <div className="md:col-span-1">
            <label className="label">Batch name</label>
            <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. 2026 Winter Cohort" />
          </div>
          <div>
            <label className="label">Start date</label>
            <input type="date" className="input" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
          </div>
          <div>
            <label className="label">End date</label>
            <input type="date" className="input" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
          </div>
        </div>
        {error && <div className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}
        <button type="submit" disabled={busy} className="btn-primary mt-4">
          {busy ? "Creating…" : "Create batch"}
        </button>
      </form>

      <div className="card mt-6 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-xs uppercase text-slate-500">
              <tr>
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Start</th>
                <th className="px-4 py-3">End</th>
                <th className="px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {batches.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-4 py-8 text-center text-slate-400">No batches yet.</td>
                </tr>
              )}
              {batches.map((b) => (
                <tr key={b.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3 font-medium text-slate-900">{b.name}</td>
                  <td className="px-4 py-3 text-slate-600">{b.start_date ?? "—"}</td>
                  <td className="px-4 py-3 text-slate-600">{b.end_date ?? "—"}</td>
                  <td className="px-4 py-3">
                    <span className={`badge ${b.status === "active" ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-600"}`}>
                      {b.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
}
