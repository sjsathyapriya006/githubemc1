import { useEffect, useState } from "react";
import { AdminLayout } from "../../components/Layouts";
import { supabase } from "../../lib/supabase";
import { sendEmail, createMeeting } from "../../lib/edge-functions";
import type { Intern, Batch, Meeting, MeetingAttendeeWithIntern, EmailTemplate } from "../../types";

const emptyForm = {
  title: "",
  description: "",
  meeting_type: "initial_review",
  scheduled_date: "",
  scheduled_time: "10:00",
  duration_minutes: 60,
  batch_id: "",
  selectedInterns: [] as string[],
};

const meetingTypeLabels: Record<string, string> = {
  initial_review: "Initial Review",
  follow_up_review: "Follow-up Review",
  final_review: "Final Review",
};

export default function AdminReviews() {
  const [meetings, setMeetings] = useState<(Meeting & { attendee_count?: number })[]>([]);
  const [interns, setInterns] = useState<Intern[]>([]);
  const [batches, setBatches] = useState<Batch[]>([]);
  const [templates, setTemplates] = useState<EmailTemplate[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [expandedMeeting, setExpandedMeeting] = useState<string | null>(null);
  const [attendeesByMeeting, setAttendeesByMeeting] = useState<Record<string, MeetingAttendeeWithIntern[]>>({});
  const [mockMode, setMockMode] = useState(false);

  async function load() {
    const [{ data: meetingRows }, { data: internRows }, { data: batchRows }, { data: templateRows }] =
      await Promise.all([
        supabase.from("meetings").select("*").order("scheduled_date", { ascending: false }),
        supabase.from("interns").select("*").order("created_at", { ascending: false }),
        supabase.from("batches").select("*").order("created_at", { ascending: false }),
        supabase.from("email_templates").select("*").eq("template_type", "review_invite").order("created_at", { ascending: false }),
      ]);
    setMeetings((meetingRows as Meeting[]) ?? []);
    setInterns((internRows as Intern[]) ?? []);
    setBatches((batchRows as Batch[]) ?? []);
    setTemplates((templateRows as EmailTemplate[]) ?? []);
  }

  useEffect(() => {
    load();
  }, []);

  async function loadAttendees(meetingId: string) {
    const { data } = await supabase
      .from("meeting_attendees")
      .select("*, interns:intern_id(full_name, email, intern_id)")
      .eq("meeting_id", meetingId);
    const rows = (data ?? []) as unknown as Array<Record<string, unknown> & { id: string; meeting_id: string; intern_id: string; invitation_status: string; attended: boolean | null; created_at: string }>;
    const mapped: MeetingAttendeeWithIntern[] = rows.map((r) => {
      const intern = r.interns as { full_name: string; email: string; intern_id: string } | null;
      return {
        id: r.id,
        meeting_id: r.meeting_id,
        intern_id: r.intern_id,
        invitation_status: r.invitation_status,
        attended: r.attended,
        created_at: r.created_at,
        intern_name: intern?.full_name,
        intern_email: intern?.email,
        intern_id_human: intern?.intern_id,
      };
    });
    setAttendeesByMeeting((prev) => ({ ...prev, [meetingId]: mapped }));
  }

  function toggleIntern(id: string) {
    setForm((f) => ({
      ...f,
      selectedInterns: f.selectedInterns.includes(id)
        ? f.selectedInterns.filter((i) => i !== id)
        : [...f.selectedInterns, id],
    }));
  }

  function selectBatchInterns(batchId: string) {
    setForm((f) => ({
      ...f,
      batch_id: batchId,
      selectedInterns: batchId
        ? interns.filter((i) => i.batch_id === batchId).map((i) => i.id)
        : [],
    }));
  }

  async function handleCreateMeeting(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    if (!form.title.trim() || !form.scheduled_date || !form.scheduled_time) {
      setError("Title, date, and time are required.");
      return;
    }
    if (form.selectedInterns.length === 0) {
      setError("Select at least one intern to invite.");
      return;
    }
    setBusy(true);
    try {
      const result = await createMeeting({
        title: form.title.trim(),
        description: form.description.trim(),
        meeting_type: form.meeting_type,
        scheduled_date: form.scheduled_date,
        scheduled_time: form.scheduled_time,
        duration_minutes: form.duration_minutes,
        batch_id: form.batch_id || undefined,
        intern_ids: form.selectedInterns,
      });
      setMockMode(result.mock);

      // Send invitation emails to each attendee
      const inviteTemplate = templates[0];
      const meetingDate = form.scheduled_date;
      const meetingTime = form.scheduled_time;
      const meetingLink = result.meeting_link;
      let sentCount = 0;
      for (const internId of form.selectedInterns) {
        const intern = interns.find((i) => i.id === internId);
        if (!intern) continue;
        try {
          await sendEmail({
            template_id: inviteTemplate?.id,
            template_type: inviteTemplate ? undefined : "review_invite",
            intern_id: intern.id,
            variables: {
              intern_name: intern.full_name,
              intern_id: intern.intern_id,
              meeting_date: meetingDate,
              meeting_time: meetingTime,
              meeting_link: meetingLink,
              duration_minutes: String(form.duration_minutes),
            },
          });
          sentCount++;
        } catch {
          // continue sending to others even if one fails
        }
      }

      // Update attendee invitation status
      await supabase
        .from("meeting_attendees")
        .update({ invitation_status: "sent" })
        .eq("meeting_id", result.meeting_id);

      setSuccessMsg(
        result.mock
          ? `Meeting scheduled (mock Google Meet). ${sentCount} invitation email(s) sent (mock mode).`
          : `Meeting scheduled with Google Meet. ${sentCount} invitation email(s) sent.`
      );
      setForm(emptyForm);
      setShowForm(false);
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to create meeting.");
    }
    setBusy(false);
  }

  async function updateMeetingStatus(meeting: Meeting, status: string) {
    await supabase.from("meetings").update({ status }).eq("id", meeting.id);
    load();
  }

  async function markAttendance(attendeeId: string, attended: boolean) {
    await supabase.from("meeting_attendees").update({ attended }).eq("id", attendeeId);
    if (expandedMeeting) loadAttendees(expandedMeeting);
  }

  async function sendReminder(meeting: Meeting, intern: Intern) {
    setError(null);
    try {
      const inviteTemplate = templates[0];
      await sendEmail({
        template_id: inviteTemplate?.id,
        template_type: inviteTemplate ? undefined : "next_review",
        intern_id: intern.id,
        variables: {
          intern_name: intern.full_name,
          intern_id: intern.intern_id,
          meeting_date: meeting.scheduled_date,
          meeting_time: meeting.scheduled_time,
          meeting_link: meeting.meeting_link ?? "",
          duration_minutes: String(meeting.duration_minutes),
        },
      });
      setSuccessMsg(`Reminder sent to ${intern.full_name}.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to send reminder.");
    }
  }

  const statusBadgeCls = (s: string) => {
    switch (s) {
      case "scheduled":
        return "bg-brand-50 text-brand-700";
      case "completed":
        return "bg-emerald-50 text-emerald-700";
      case "cancelled":
        return "bg-red-50 text-red-700";
      default:
        return "bg-slate-100 text-slate-600";
    }
  };

  const filteredInterns = form.batch_id
    ? interns.filter((i) => i.batch_id === form.batch_id)
    : interns;

  return (
    <AdminLayout>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Review Meetings</h1>
          <p className="mt-1 text-sm text-slate-500">
            Schedule review sessions with Google Meet and send invitation emails to interns.
          </p>
        </div>
        <button
          onClick={() => {
            if (showForm) {
              setForm(emptyForm);
              setShowForm(false);
            } else {
              setShowForm(true);
            }
          }}
          className="btn-primary"
        >
          {showForm ? "Close" : "Schedule meeting"}
        </button>
      </div>

      {mockMode && (
        <div className="mt-4 rounded-lg bg-amber-50 px-3 py-2 text-sm text-amber-700">
          Mock mode active — Google Calendar credentials and/or email API key not set. Meetings and
          emails are logged but not actually sent. See setup notes below.
        </div>
      )}
      {error && (
        <div className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>
      )}
      {successMsg && (
        <div className="mt-4 rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-700">
          {successMsg}
        </div>
      )}

      {showForm && (
        <form onSubmit={handleCreateMeeting} className="card mt-6 p-6">
          <h2 className="text-lg font-semibold text-slate-900">Schedule review meeting</h2>
          <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="md:col-span-2">
              <label className="label">Title *</label>
              <input
                className="input"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="e.g. Initial Review — Winter 2026 Cohort"
              />
            </div>
            <div className="md:col-span-2">
              <label className="label">Description / agenda</label>
              <textarea
                rows={2}
                className="input"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />
            </div>
            <div>
              <label className="label">Meeting type</label>
              <select
                className="input"
                value={form.meeting_type}
                onChange={(e) => setForm({ ...form, meeting_type: e.target.value })}
              >
                <option value="initial_review">Initial Review</option>
                <option value="follow_up_review">Follow-up Review</option>
                <option value="final_review">Final Review</option>
              </select>
            </div>
            <div>
              <label className="label">Batch (optional — select all interns in batch)</label>
              <select
                className="input"
                value={form.batch_id}
                onChange={(e) => selectBatchInterns(e.target.value)}
              >
                <option value="">— No batch —</option>
                {batches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Date *</label>
              <input
                type="date"
                className="input"
                value={form.scheduled_date}
                onChange={(e) => setForm({ ...form, scheduled_date: e.target.value })}
              />
            </div>
            <div>
              <label className="label">Time *</label>
              <input
                type="time"
                className="input"
                value={form.scheduled_time}
                onChange={(e) => setForm({ ...form, scheduled_time: e.target.value })}
              />
            </div>
            <div>
              <label className="label">Duration (minutes)</label>
              <input
                type="number"
                className="input"
                value={form.duration_minutes}
                onChange={(e) =>
                  setForm({ ...form, duration_minutes: parseInt(e.target.value) || 60 })
                }
              />
            </div>
          </div>

          <div className="mt-4">
            <label className="label">Invite interns</label>
            <div className="max-h-48 overflow-auto rounded-lg border border-slate-200 p-3">
              {filteredInterns.length === 0 && (
                <p className="text-sm text-slate-400">No interns available.</p>
              )}
              {filteredInterns.map((i) => (
                <label key={i.id} className="flex items-center gap-2 py-1 text-sm">
                  <input
                    type="checkbox"
                    checked={form.selectedInterns.includes(i.id)}
                    onChange={() => toggleIntern(i.id)}
                    className="rounded border-slate-300"
                  />
                  <span className="text-slate-700">
                    {i.full_name} ({i.intern_id}) — {i.email}
                  </span>
                </label>
              ))}
            </div>
          </div>

          <div className="mt-4 flex gap-2">
            <button type="submit" disabled={busy} className="btn-primary">
              {busy ? "Scheduling…" : "Schedule & send invites"}
            </button>
            <button
              type="button"
              onClick={() => {
                setForm(emptyForm);
                setShowForm(false);
              }}
              className="btn-secondary"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="mt-6 space-y-4">
        {meetings.length === 0 && (
          <div className="card p-8 text-center text-slate-400">
            No meetings scheduled yet. Click "Schedule meeting" to get started.
          </div>
        )}
        {meetings.map((m) => (
          <div key={m.id} className="card p-5">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="text-base font-semibold text-slate-900">{m.title}</h3>
                  <span className={`badge ${statusBadgeCls(m.status)}`}>{m.status}</span>
                  <span className="badge bg-slate-100 text-slate-600">
                    {meetingTypeLabels[m.meeting_type] ?? m.meeting_type}
                  </span>
                </div>
                <p className="mt-1 text-sm text-slate-500">
                  {m.scheduled_date} at {m.scheduled_time} · {m.duration_minutes} min
                  {m.meeting_link && (
                    <>
                      {" · "}
                      <a
                        href={m.meeting_link}
                        target="_blank"
                        rel="noreferrer"
                        className="text-brand-600 hover:underline"
                      >
                        Join link
                      </a>
                    </>
                  )}
                </p>
                {m.description && (
                  <p className="mt-1 text-sm text-slate-600">{m.description}</p>
                )}
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => {
                    if (expandedMeeting === m.id) {
                      setExpandedMeeting(null);
                    } else {
                      setExpandedMeeting(m.id);
                      loadAttendees(m.id);
                    }
                  }}
                  className="btn-secondary text-xs"
                >
                  {expandedMeeting === m.id ? "Hide" : "Attendees"}
                </button>
                {m.status === "scheduled" && (
                  <>
                    <button
                      onClick={() => updateMeetingStatus(m, "completed")}
                      className="btn-secondary text-xs"
                    >
                      Mark completed
                    </button>
                    <button
                      onClick={() => updateMeetingStatus(m, "cancelled")}
                      className="btn-secondary text-xs text-red-600"
                    >
                      Cancel
                    </button>
                  </>
                )}
              </div>
            </div>

            {expandedMeeting === m.id && (
              <div className="mt-4 border-t border-slate-200 pt-4">
                <h4 className="text-xs font-semibold uppercase text-slate-400">
                  Attendees ({attendeesByMeeting[m.id]?.length ?? 0})
                </h4>
                <div className="mt-2 space-y-2">
                  {(attendeesByMeeting[m.id] ?? []).map((a) => (
                    <div
                      key={a.id}
                      className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-slate-50 px-3 py-2 text-sm"
                    >
                      <div>
                        <span className="font-medium text-slate-700">
                          {a.intern_name ?? "Unknown"}
                        </span>
                        <span className="ml-2 text-slate-400">
                          {a.intern_id_human} · {a.intern_email}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span
                          className={`badge ${
                            a.invitation_status === "sent"
                              ? "bg-emerald-50 text-emerald-700"
                              : a.invitation_status === "failed"
                                ? "bg-red-50 text-red-700"
                                : "bg-amber-50 text-amber-700"
                          }`}
                        >
                          {a.invitation_status}
                        </span>
                        {a.attended === null ? (
                          <>
                            <button
                              onClick={() => markAttendance(a.id, true)}
                              className="btn-secondary text-xs"
                            >
                              Present
                            </button>
                            <button
                              onClick={() => markAttendance(a.id, false)}
                              className="btn-secondary text-xs"
                            >
                              Absent
                            </button>
                          </>
                        ) : (
                          <span
                            className={`badge ${
                              a.attended
                                ? "bg-emerald-100 text-emerald-800"
                                : "bg-red-100 text-red-700"
                            }`}
                          >
                            {a.attended ? "Present" : "Absent"}
                          </span>
                        )}
                        <button
                          onClick={() => {
                            const intern = interns.find((i) => i.id === a.intern_id);
                            if (intern) sendReminder(m, intern);
                          }}
                          className="btn-secondary text-xs"
                        >
                          Remind
                        </button>
                      </div>
                    </div>
                  ))}
                  {(attendeesByMeeting[m.id] ?? []).length === 0 && (
                    <p className="text-sm text-slate-400">No attendees.</p>
                  )}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </AdminLayout>
  );
}
