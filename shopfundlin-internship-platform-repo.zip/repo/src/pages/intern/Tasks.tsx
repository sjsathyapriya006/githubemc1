import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { InternLayout } from "../../components/Layouts";
import { supabase } from "../../lib/supabase";
import { useAuth } from "../../lib/auth";
import type { TaskWithRelations } from "../../types";

const statusBadgeCls = (s: string) => {
  switch (s) {
    case "Assigned": return "bg-brand-50 text-brand-700";
    case "Approved": return "bg-emerald-50 text-emerald-700";
    case "Completed": return "bg-emerald-100 text-emerald-800";
    case "In Progress": return "bg-blue-50 text-blue-700";
    case "Submitted": return "bg-amber-50 text-amber-700";
    case "Rejected": return "bg-red-50 text-red-700";
    default: return "bg-slate-100 text-slate-600";
  }
};

export default function InternTasks() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<TaskWithRelations[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user?.email) return;
    (async () => {
      // Find intern record by email, then fetch tasks
      const { data: intern } = await supabase
        .from("interns")
        .select("id")
        .eq("email", user.email)
        .maybeSingle();

      if (!intern) {
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from("tasks_with_relations")
        .select("*")
        .eq("intern_id", intern.id)
        .order("created_at", { ascending: false });

      if (error) {
        setError(error.message);
      } else {
        setTasks((data as TaskWithRelations[]) ?? []);
      }
      setLoading(false);
    })();
  }, [user?.email]);

  // Interns can only see tasks that are Assigned, In Progress, Submitted, or Completed
  const visibleTasks = tasks.filter((t) =>
    ["Assigned", "In Progress", "Submitted", "Completed"].includes(t.status)
  );

  return (
    <InternLayout>
      <h1 className="text-2xl font-bold text-slate-900">My Tasks</h1>
      <p className="mt-1 text-sm text-slate-500">Your assigned tasks, instructions, and deadlines.</p>

      {error && <div className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}

      {loading ? (
        <div className="mt-8 animate-pulse text-slate-400">Loading your tasks…</div>
      ) : visibleTasks.length === 0 ? (
        <div className="card mt-6 p-8 text-center text-slate-400">
          No tasks assigned yet. Your mentor will assign tasks once they're ready.
        </div>
      ) : (
        <div className="mt-6 space-y-4">
          {visibleTasks.map((t) => (
            <div key={t.id} className="card p-5">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-base font-semibold text-slate-900">{t.title}</h3>
                    <span className={`badge ${statusBadgeCls(t.status)}`}>{t.status}</span>
                  </div>
                  <p className="mt-1 text-sm text-slate-500">Project: {t.project_title ?? "—"}</p>
                </div>
                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400">
                  {t.difficulty && <span>Difficulty: {t.difficulty}</span>}
                  {t.deadline && <span>Deadline: {t.deadline}</span>}
                  {(t.status === "Assigned" || t.status === "In Progress") && (
                    <Link
                      to="/intern/submissions"
                      className="font-medium text-brand-600 hover:underline"
                    >
                      Submit work →
                    </Link>
                  )}
                  {t.status === "Submitted" && (
                    <Link
                      to="/intern/submissions"
                      className="font-medium text-amber-600 hover:underline"
                    >
                      Awaiting review →
                    </Link>
                  )}
                  {t.status === "Completed" && (
                    <Link
                      to="/intern/submissions"
                      className="font-medium text-emerald-600 hover:underline"
                    >
                      Review feedback →
                    </Link>
                  )}
                </div>
              </div>
              {t.instructions && (
                <div className="mt-3">
                  <p className="text-xs font-semibold uppercase text-slate-400">Instructions</p>
                  <p className="mt-1 text-sm text-slate-600">{t.instructions}</p>
                </div>
              )}
              {t.deliverables && (
                <div className="mt-3">
                  <p className="text-xs font-semibold uppercase text-slate-400">Deliverables</p>
                  <p className="mt-1 text-sm text-slate-600">{t.deliverables}</p>
                </div>
              )}
              {t.review_criteria && (
                <div className="mt-3">
                  <p className="text-xs font-semibold uppercase text-slate-400">Review criteria</p>
                  <p className="mt-1 text-sm text-slate-600">{t.review_criteria}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </InternLayout>
  );
}
