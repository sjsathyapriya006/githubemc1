interface StatCardProps {
  label: string;
  value: number | string;
  accent?: "brand" | "amber" | "emerald" | "slate";
}

const accents: Record<NonNullable<StatCardProps["accent"]>, string> = {
  brand: "bg-brand-50 text-brand-700",
  amber: "bg-amber-50 text-amber-700",
  emerald: "bg-emerald-50 text-emerald-700",
  slate: "bg-slate-100 text-slate-700",
};

export function StatCard({ label, value, accent = "slate" }: StatCardProps) {
  return (
    <div className="card p-5">
      <div className={`badge ${accents[accent]}`}>{label}</div>
      <div className="mt-3 text-3xl font-bold text-slate-900">{value}</div>
    </div>
  );
}
