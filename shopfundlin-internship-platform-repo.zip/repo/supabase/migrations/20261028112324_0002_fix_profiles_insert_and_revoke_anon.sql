/*
# Fix: add INSERT policy on profiles

## Problem
The original Phase 1 migration created SELECT and UPDATE policies on `profiles`
but no INSERT policy. When a new user signs up, the frontend upserts a profile
row — but RLS blocks INSERT (no matching policy), so the profile never gets
created and the user can never reach the app.

## Change
- Add `insert_own_profile` INSERT policy allowing an authenticated user to
  insert only their own profile row (auth.uid() = id).
- Revoke excess `anon` grants on profiles, batches, and interns that were
  inherited from platform defaults; the app requires sign-in, so only
  `authenticated` needs table access. RLS already blocks anon, but removing
  the grants is defense-in-depth.
*/

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

REVOKE SELECT, INSERT, UPDATE, DELETE ON profiles FROM anon;
REVOKE SELECT, INSERT, UPDATE, DELETE ON batches FROM anon;
REVOKE SELECT, INSERT, UPDATE, DELETE ON interns FROM anon;
