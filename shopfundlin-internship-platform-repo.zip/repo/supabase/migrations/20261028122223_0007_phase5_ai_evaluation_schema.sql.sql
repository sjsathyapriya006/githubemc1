/*
# Phase 5 — AI Submission Evaluation

## Purpose
When an intern submits work, admins can request an AI evaluation that
analyzes the submission against the task's review criteria and project
requirements. The AI produces a draft review with a recommended decision,
score, strengths, areas for improvement, and structured feedback. The
admin can accept, edit, or discard the AI draft before submitting their
final review.

## New tables

### ai_evaluations
- `id` uuid PK.
- `submission_id` uuid FK -> submissions(id) ON DELETE CASCADE.
- `task_id` uuid FK -> tasks(id) ON DELETE CASCADE.
- `intern_id` uuid FK -> interns(id) ON DELETE CASCADE.
- `recommended_decision` text — 'approved' | 'changes_requested' | 'rejected'.
- `score` int — 1-10 (nullable).
- `feedback` text — overall assessment.
- `strengths` text — what was done well.
- `areas_for_improvement` text — what needs work.
- `criteria_analysis` text — per-criterion breakdown (JSON string).
- `mock` boolean — true if generated without a real AI API key.
- `created_at` timestamptz.

## New views

### ai_evaluations_with_details
Joins ai_evaluations → submissions → tasks → interns for display.
Marked security_invoker so RLS applies.

## Security
- RLS enabled on ai_evaluations.
- Admins have full CRUD; interns can read evaluations on their own
  submissions (matched via interns.email = auth email).
- Interns cannot create/update/delete evaluations.
- Only the edge function (using service_role) creates evaluations.
- service_role gets SELECT + INSERT for the edge function.

## Notes
1. The edge function fetches the submission, task, and project context,
   sends them to the AI API, and stores the result.
2. Admins trigger the evaluation from the Submissions page. The AI
   evaluation appears alongside the manual review form so the admin can
   pre-fill and edit before finalizing.
3. Multiple AI evaluations can exist per submission (e.g. if the admin
   re-runs after the intern resubmits). The latest one is shown.
*/

CREATE TABLE IF NOT EXISTS ai_evaluations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  submission_id uuid NOT NULL REFERENCES submissions(id) ON DELETE CASCADE,
  task_id uuid NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  intern_id uuid NOT NULL REFERENCES interns(id) ON DELETE CASCADE,
  recommended_decision text NOT NULL CHECK (recommended_decision IN ('approved', 'changes_requested', 'rejected')),
  score int CHECK (score >= 1 AND score <= 10),
  feedback text NOT NULL DEFAULT '',
  strengths text NOT NULL DEFAULT '',
  areas_for_improvement text NOT NULL DEFAULT '',
  criteria_analysis text NOT NULL DEFAULT '',
  mock boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ai_eval_submission ON ai_evaluations(submission_id);
CREATE INDEX IF NOT EXISTS idx_ai_eval_intern ON ai_evaluations(intern_id);

ALTER TABLE ai_evaluations ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON ai_evaluations TO authenticated;
GRANT SELECT, INSERT ON ai_evaluations TO service_role;

-- Admins can read all; interns can read evaluations on their own submissions
DROP POLICY IF EXISTS "select_ai_evaluations" ON ai_evaluations;
CREATE POLICY "select_ai_evaluations" ON ai_evaluations FOR SELECT
  TO authenticated USING (
    is_admin()
    OR intern_id IN (
      SELECT i.id FROM interns i
      WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
    )
  );

-- Only admins can insert (though normally the edge function does this via service_role)
DROP POLICY IF EXISTS "admin_insert_ai_evaluations" ON ai_evaluations;
CREATE POLICY "admin_insert_ai_evaluations" ON ai_evaluations FOR INSERT
  TO authenticated WITH CHECK (is_admin());

-- Only admins can delete
DROP POLICY IF EXISTS "admin_delete_ai_evaluations" ON ai_evaluations;
CREATE POLICY "admin_delete_ai_evaluations" ON ai_evaluations FOR DELETE
  TO authenticated USING (is_admin());

-- No UPDATE policy — evaluations are immutable once created

-- ── ai_evaluations_with_details view ──

CREATE OR REPLACE VIEW ai_evaluations_with_details AS
SELECT
  ae.*,
  s.submission_number,
  s.status AS submission_status,
  t.title AS task_title,
  t.review_criteria AS task_review_criteria,
  i.full_name AS intern_name,
  i.intern_id AS intern_id_human
FROM ai_evaluations ae
JOIN submissions s ON s.id = ae.submission_id
JOIN tasks t ON t.id = ae.task_id
JOIN interns i ON i.id = ae.intern_id;

ALTER VIEW ai_evaluations_with_details SET (security_invoker = true);
GRANT SELECT ON ai_evaluations_with_details TO authenticated;