import { useEffect, useState } from "react";
import { InternLayout } from "../../components/Layouts";
import { supabase } from "../../lib/supabase";
import { useAuth } from "../../lib/auth";
import type { Intern } from "../../types";

export default function InternDashboard() {
  const { user } = useAuth();
  const [intern, setIntern] = useState<Intern | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.email) return;
    (async () => {
      const { data } = await supabase
        .from("interns")
        .select("*")
        .eq("email", user.email)
        .maybeSingle();
      setIntern(data as Intern | null);
      setLoading(false);
    })();
  }, [user?.email]);

  return (
    <InternLayout>
      <h1 className="text-2xl font-bold text-slate-900">Welcome, {intern?.full_name ?? "intern"}</h1>
      <p className="mt-1 text-sm text-slate-500">Your internship hub at Shop Fundlin.</p>

      {loading ? (
        <div className="mt-8 animate-pulse text-slate-400">Loading your details…</div>
      ) : intern ? (
        <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
          <div className="card p-5">
            <h2 className="text-sm font-semibold uppercase text-slate-500">Your intern ID</h2>
            <p className="mt-2 font-mono text-lg text-slate-900">{intern.intern_id}</p>
          </div>
          <div className="card p-5">
            <h2 className="text-sm font-semibold uppercase text-slate-500">Status</h2>
            <p className="mt-2">
              <span className="badge bg-brand-50 text-brand-700">{intern.status}</span>
            </p>
          </div>
          <div className="card p-5">
            <h2 className="text-sm font-semibold uppercase text-slate-500">Role</h2>
            <p className="mt-2 text-slate-900">{intern.role ?? "—"}</p>
          </div>
          <div className="card p-5">
            <h2 className="text-sm font-semibold uppercase text-slate-500">Timeline</h2>
            <p className="mt-2 text-sm text-slate-700">
              {intern.start_date ?? "Start TBD"} → {intern.expected_end_date ?? "End TBD"}
            </p>
          </div>
        </div>
      ) : (
        <div className="card mt-6 p-6">
          <h2 className="text-lg font-semibold text-slate-900">No intern record yet</h2>
          <p className="mt-2 text-sm text-slate-600">
            Your account is ready, but an admin hasn't added you as an intern with this email yet.
            Once they do, your tasks, reviews, and submissions will appear here.
          </p>
        </div>
      )}

      <div className="card mt-6 p-6">
        <h2 className="text-lg font-semibold text-slate-900">Your tasks</h2>
        <p className="mt-2 text-sm text-slate-600">
          Visit the <strong>My Tasks</strong> tab to see assigned tasks, instructions, and deadlines.
          When you're ready, go to <strong>My Submissions</strong> to submit your work and track
          mentor feedback.
        </p>
      </div>
    </InternLayout>
  );
}
