import { supabase } from "./supabase";

export interface TaskRecommendation {
  title: string;
  instructions: string;
  deliverables: string;
  difficulty: string;
  review_criteria: string;
}

export interface RecommendResponse {
  recommendation: TaskRecommendation;
  mock: boolean;
  intern_name: string;
  project_title: string;
  error?: string;
}

export async function recommendTask(params: {
  project_id: string;
  intern_id: string;
  intern_skills?: string;
  task_difficulty?: string;
}): Promise<RecommendResponse> {
  const { data: session } = await supabase.auth.getSession();
  const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-recommend-tasks`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${session.session?.access_token}`,
      apikey: import.meta.env.VITE_SUPABASE_ANON_KEY,
    },
    body: JSON.stringify(params),
  });
  if (!res.ok) {
    const errBody = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(errBody.error ?? `Request failed (${res.status})`);
  }
  return res.json();
}
