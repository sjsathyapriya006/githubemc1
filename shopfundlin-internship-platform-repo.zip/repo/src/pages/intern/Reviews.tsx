import { useEffect, useState } from "react";
import { InternLayout } from "../../components/Layouts";
import { supabase } from "../../lib/supabase";
import { useAuth } from "../../lib/auth";
import type { ProjectAssignmentWithRelations, Submission, SubmissionReviewWithCategories } from "../../types";

const decisionBadge = (d: string) => {
  const cls = d === "approved" ? "bg-emerald-50 text-emerald-700" : d === "changes_requested" ? "bg-orange-50 text-orange-700" : "bg-red-50 text-red-700";
  return <span className={`badge ${cls}`}>{d.replace(/_/g, " ")}</span>;
};

export default function InternReviews() {
  const { user } = useAuth();
  const [assignments, setAssignments] = useState<ProjectAssignmentWithRelations[]>([]);
  const [submissionsByAssignment, setSubmissionsByAssignment] = useState<Record<string, Submission[]>>({});
  const [reviewsBySubmission, setReviewsBySubmission] = useState<Record<string, SubmissionReviewWithCategories[]>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  useEffect(() => {
    if (!user?.email) return;
    (async () => {
      const { data: intern } = await supabase
        .from("interns")
        .select("id")
        .eq("email", user.email)
        .maybeSingle();
      if (!intern) { setLoading(false); return; }

      const { data: assignData, error: assignErr } = await supabase
        .from("project_assignments")
        .select("*, projects!inner(title, description, requirements, tools, deliverables), interns!inner(full_name, email, intern_id, batch_id, batches(name))")
        .eq("intern_id", intern.id)
        .order("created_at", { ascending: false });

      if (assignErr) { setError(assignErr.message); setLoading(false); return; }

      const rows = (assignData as unknown as Array<Record<string, unknown>>) ?? [];
      const mapped: ProjectAssignmentWithRelations[] = rows.map((r) => {
        const proj = r.projects as Record<string, unknown>;
        const intr = r.interns as Record<string, unknown>;
        const batch = intr.batches as Record<string, unknown> | null;
        return {
          id: r.id as string,
          project_id: r.project_id as string,
          intern_id: r.intern_id as string,
          assigned_by: r.assigned_by as string | null,
          objectives: r.objectives as string,
          milestones: r.milestones as string[],
          completion_instructions: r.completion_instructions as string,
          start_date: r.start_date as string | null,
          deadline: r.deadline as string | null,
          difficulty: r.difficulty as string | null,
          max_rating: r.max_rating as number,
          status: r.status as ProjectAssignmentWithRelations["status"],
          progress_description: r.progress_description as string,
          progress_updated_at: r.progress_updated_at as string | null,
          created_at: r.created_at as string,
          updated_at: r.updated_at as string,
          project_title: proj?.title as string,
          project_description: proj?.description as string,
          project_requirements: proj?.requirements as string[],
          project_tools: proj?.tools as string[],
          project_deliverables: proj?.deliverables as string[],
          intern_name: intr?.full_name as string,
          intern_email: intr?.email as string,
          intern_id_human: intr?.intern_id as string,
          batch_name: batch?.name as string | undefined,
        };
      });
      setAssignments(mapped);

      const subMap: Record<string, Submission[]> = {};
      const reviewMap: Record<string, SubmissionReviewWithCategories[]> = {};
      for (const a of mapped) {
        const { data: subs } = await supabase
          .from("submissions")
          .select("*")
          .eq("assignment_id", a.id)
          .order("submitted_at", { ascending: false });
        if (subs) {
          subMap[a.id] = subs as Submission[];
          for (const s of subs as Submission[]) {
            const { data: reviews } = await supabase
              .from("submission_reviews")
              .select("*")
              .eq("submission_id", s.id)
              .order("created_at", { ascending: false });
            if (reviews) reviewMap[s.id] = reviews as SubmissionReviewWithCategories[];
          }
        }
      }
      setSubmissionsByAssignment(subMap);
      setReviewsBySubmission(reviewMap);
      setLoading(false);
    })();
  }, [user?.email]);

  // Only show assignments that have at least one submission with a review
  const assignmentsWithReviews = assignments.filter((a) => {
    const subs = submissionsByAssignment[a.id] ?? [];
    return subs.some((s) => (reviewsBySubmission[s.id] ?? []).length > 0);
  });

  function toggleExpand(id: string) {
    setExpandedId(expandedId === id ? null : id);
  }

  return (
    <InternLayout>
      <h1 className="text-2xl font-bold text-slate-900">My Project Reviews</h1>
      <p className="mt-1 text-sm text-slate-500">
        View ratings, feedback, and review history for your submitted projects.
      </p>

      {error && <div className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}

      {loading ? (
        <div className="mt-8 animate-pulse text-slate-400">Loading your reviews…</div>
      ) : !user ? (
        <div className="card mt-6 p-6">
          <p className="text-sm text-slate-600">Please sign in to view your reviews.</p>
        </div>
      ) : assignmentsWithReviews.length === 0 ? (
        <div className="card mt-6 p-8 text-center text-slate-400">
          No reviews yet. Once your mentor reviews your project submissions, their feedback and
          ratings will appear here.
        </div>
      ) : (
        <div className="mt-6 space-y-4">
          {assignmentsWithReviews.map((a) => {
            const subs = submissionsByAssignment[a.id] ?? [];
            const expanded = expandedId === a.id;
            // Find latest review across all submissions
            let latestReview: SubmissionReviewWithCategories | null = null;
            let latestSub: Submission | null = null;
            for (const s of subs) {
              const reviews = reviewsBySubmission[s.id] ?? [];
              if (reviews.length > 0 && (!latestReview || reviews[0].created_at > latestReview.created_at)) {
                latestReview = reviews[0];
                latestSub = s;
              }
            }
            return (
              <div key={a.id} className="card p-5">
                <button onClick={() => toggleExpand(a.id)} className="flex w-full flex-wrap items-start justify-between gap-2 text-left">
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-base font-semibold text-slate-900">{a.project_title}</h3>
                      {latestReview && decisionBadge(latestReview.decision)}
                    </div>
                    {latestSub && (
                      <p className="mt-1 text-sm text-slate-500">
                        Submitted {new Date(latestSub.submitted_at).toLocaleDateString()}
                        {latestReview?.reviewer_name && ` · Reviewed by ${latestReview.reviewer_name}`}
                      </p>
                    )}
                    {latestReview?.score != null && (
                      <div className="mt-2 flex items-center gap-3">
                        <div className="flex items-center gap-1">
                          <span className="text-2xl font-bold text-slate-900">{latestReview.score}</span>
                          <span className="text-sm text-slate-400">/ {a.max_rating}</span>
                        </div>
                        {latestReview.score_override_reason && (
                          <span className="text-xs text-slate-400">Score overridden: {latestReview.score_override_reason}</span>
                        )}
                      </div>
                    )}
                  </div>
                  <span className="text-sm text-brand-600">{expanded ? "Hide details" : "View details"}</span>
                </button>

                {expanded && (
                  <div className="mt-4 border-t border-slate-200 pt-4">
                    {/* Category ratings for latest review */}
                    {latestReview && (latestReview.rating_code_quality != null || latestReview.rating_functionality != null || latestReview.rating_documentation != null || latestReview.rating_creativity != null || latestReview.rating_deadline_adherence != null) && (
                      <div className="mb-4">
                        <p className="text-xs font-semibold uppercase text-slate-400">Category ratings</p>
                        <div className="mt-2 grid grid-cols-2 gap-3 md:grid-cols-5">
                          {latestReview.rating_code_quality != null && (
                            <div className="rounded-lg bg-slate-50 p-2 text-center">
                              <p className="text-xs text-slate-500">Code quality</p>
                              <p className="mt-1 text-lg font-bold text-slate-900">{latestReview.rating_code_quality}/10</p>
                            </div>
                          )}
                          {latestReview.rating_functionality != null && (
                            <div className="rounded-lg bg-slate-50 p-2 text-center">
                              <p className="text-xs text-slate-500">Functionality</p>
                              <p className="mt-1 text-lg font-bold text-slate-900">{latestReview.rating_functionality}/10</p>
                            </div>
                          )}
                          {latestReview.rating_documentation != null && (
                            <div className="rounded-lg bg-slate-50 p-2 text-center">
                              <p className="text-xs text-slate-500">Documentation</p>
                              <p className="mt-1 text-lg font-bold text-slate-900">{latestReview.rating_documentation}/10</p>
                            </div>
                          )}
                          {latestReview.rating_creativity != null && (
                            <div className="rounded-lg bg-slate-50 p-2 text-center">
                              <p className="text-xs text-slate-500">Creativity</p>
                              <p className="mt-1 text-lg font-bold text-slate-900">{latestReview.rating_creativity}/10</p>
                            </div>
                          )}
                          {latestReview.rating_deadline_adherence != null && (
                            <div className="rounded-lg bg-slate-50 p-2 text-center">
                              <p className="text-xs text-slate-500">Deadline adherence</p>
                              <p className="mt-1 text-lg font-bold text-slate-900">{latestReview.rating_deadline_adherence}/10</p>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Latest review feedback */}
                    {latestReview?.feedback && (
                      <div className="mb-4">
                        <p className="text-xs font-semibold uppercase text-slate-400">Feedback</p>
                        <p className="mt-1 whitespace-pre-wrap text-sm text-slate-600">{latestReview.feedback}</p>
                      </div>
                    )}
                    {latestReview?.strengths && (
                      <div className="mb-3">
                        <p className="text-xs font-semibold uppercase text-emerald-600">Strengths</p>
                        <p className="mt-1 text-sm text-slate-600">{latestReview.strengths}</p>
                      </div>
                    )}
                    {latestReview?.areas_for_improvement && (
                      <div className="mb-3">
                        <p className="text-xs font-semibold uppercase text-orange-600">Areas for improvement</p>
                        <p className="mt-1 text-sm text-slate-600">{latestReview.areas_for_improvement}</p>
                      </div>
                    )}
                    {latestReview?.decision === "changes_requested" && a.deadline && (
                      <div className="mb-4 rounded-lg bg-orange-50 p-3">
                        <p className="text-xs font-semibold uppercase text-orange-600">Revision instructions</p>
                        <p className="mt-1 text-sm text-orange-700">
                          Please address the feedback above and resubmit your project.
                          Resubmission deadline: {a.deadline}
                        </p>
                      </div>
                    )}

                    {/* Full submission & review history */}
                    <div className="mt-4">
                      <p className="text-xs font-semibold uppercase text-slate-400">Full submission & review history</p>
                      <div className="mt-2 space-y-3">
                        {subs.map((s) => {
                          const reviews = reviewsBySubmission[s.id] ?? [];
                          return (
                            <div key={s.id} className="rounded-lg border border-slate-200 p-3">
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="badge bg-slate-100 text-slate-500">Attempt #{s.submission_number}</span>
                                <span className={`badge ${s.status === "approved" ? "bg-emerald-50 text-emerald-700" : s.status === "changes_requested" ? "bg-orange-50 text-orange-700" : s.status === "rejected" ? "bg-red-50 text-red-700" : "bg-amber-50 text-amber-700"}`}>
                                  {s.status.replace(/_/g, " ")}
                                </span>
                                <span className="text-xs text-slate-400">{new Date(s.submitted_at).toLocaleString()}</span>
                              </div>
                              {s.submission_text && <p className="mt-2 text-sm text-slate-600">{s.submission_text}</p>}
                              {s.repo_url && <p className="mt-1 text-xs"><a href={s.repo_url} target="_blank" rel="noreferrer" className="text-brand-600 hover:underline">Repository</a></p>}
                              {s.demo_url && <p className="mt-1 text-xs"><a href={s.demo_url} target="_blank" rel="noreferrer" className="text-brand-600 hover:underline">Live demo</a></p>}
                              {reviews.length > 0 && (
                                <div className="mt-2 space-y-2">
                                  {reviews.map((r) => (
                                    <div key={r.id} className="rounded bg-slate-50 p-2">
                                      <div className="flex flex-wrap items-center gap-2">
                                        {decisionBadge(r.decision)}
                                        {r.score != null && <span className="badge bg-brand-50 text-brand-700">{r.score}/{a.max_rating}</span>}
                                        {r.reviewer_name && <span className="text-xs text-slate-400">by {r.reviewer_name}</span>}
                                        <span className="text-xs text-slate-400">{new Date(r.created_at).toLocaleString()}</span>
                                      </div>
                                      {r.feedback && <p className="mt-1 text-xs text-slate-600">{r.feedback}</p>}
                                      {r.strengths && <p className="mt-1 text-xs text-emerald-700">Strengths: {r.strengths}</p>}
                                      {r.areas_for_improvement && <p className="mt-1 text-xs text-orange-700">Improvement: {r.areas_for_improvement}</p>}
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </InternLayout>
  );
}
