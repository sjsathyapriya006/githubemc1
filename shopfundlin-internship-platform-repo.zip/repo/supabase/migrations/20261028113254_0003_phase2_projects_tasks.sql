/*
# Phase 2 — Projects and Tasks

## Purpose
Adds project definitions and personalized task assignments. Admins create
projects (with requirements, tools, deliverables, deadlines). The AI task
recommendation engine (edge function) proposes tasks per intern; admins review,
edit, approve, and assign them. Interns view only their own assigned tasks.

## New tables

### projects
- `id` uuid PK.
- `title` text — project name.
- `description` text — what the project is about.
- `requirements` text[] — list of requirements the intern must meet.
- `tools` text[] — tools/technologies expected.
- `deliverables` text[] — expected outputs.
- `deadline` date — project deadline.
- `status` text — 'draft' | 'active' | 'archived' (default 'draft').
- `created_by` uuid — admin who created it (defaults to auth.uid()).
- `created_at` timestamptz.

### tasks
- `id` uuid PK.
- `project_id` uuid FK -> projects(id) ON DELETE CASCADE.
- `intern_id` uuid FK -> interns(id) ON DELETE CASCADE.
- `title` text — task name.
- `instructions` text — detailed instructions for the intern.
- `deliverables` text — what the intern must submit.
- `difficulty` text — 'beginner' | 'intermediate' | 'advanced'.
- `deadline` date — task deadline.
- `review_criteria` text — how the task will be evaluated.
- `status` text — lifecycle: 'Recommended' | 'Approved' | 'Assigned' |
  'In Progress' | 'Submitted' | 'Completed' | 'Rejected'.
- `ai_generated` boolean — true if produced by the AI recommender.
- `created_at` timestamptz.

## Security

- RLS enabled on both tables.
- projects: admins have full CRUD; interns can read 'active' projects so they
  see context for their assigned tasks.
- tasks: admins have full CRUD; an intern may read and update only their own
  task rows (matched via interns.email = auth email). Interns can only change
  status, not instructions or other fields — enforced by column-restricted
  UPDATE grant (status only).
- Grants restricted to `authenticated`. `service_role` for edge functions.

## Notes
1. `projects.created_by` defaults to auth.uid() so admin inserts work.
2. Intern task UPDATE is column-restricted to `status` only; the table-level
   UPDATE grant is revoked from authenticated and re-granted on (status).
3. A helper view `tasks_with_relations` joins project + intern details for the
   admin UI, avoiding N+1 queries. Marked security_invoker so RLS applies.
*/

CREATE TABLE IF NOT EXISTS projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  requirements text[] NOT NULL DEFAULT '{}',
  tools text[] NOT NULL DEFAULT '{}',
  deliverables text[] NOT NULL DEFAULT '{}',
  deadline date,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'archived')),
  created_by uuid DEFAULT auth.uid(),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE projects ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON projects TO authenticated;
GRANT SELECT ON projects TO service_role;

DROP POLICY IF EXISTS "select_projects" ON projects;
CREATE POLICY "select_projects" ON projects FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_projects" ON projects;
CREATE POLICY "admin_insert_projects" ON projects FOR INSERT
  TO authenticated WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_update_projects" ON projects;
CREATE POLICY "admin_update_projects" ON projects FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_delete_projects" ON projects;
CREATE POLICY "admin_delete_projects" ON projects FOR DELETE
  TO authenticated USING (is_admin());

CREATE TABLE IF NOT EXISTS tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  intern_id uuid NOT NULL REFERENCES interns(id) ON DELETE CASCADE,
  title text NOT NULL,
  instructions text NOT NULL DEFAULT '',
  deliverables text NOT NULL DEFAULT '',
  difficulty text CHECK (difficulty IN ('beginner', 'intermediate', 'advanced')),
  deadline date,
  review_criteria text,
  status text NOT NULL DEFAULT 'Recommended' CHECK (
    status IN ('Recommended','Approved','Assigned','In Progress',
               'Submitted','Completed','Rejected')
  ),
  ai_generated boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, DELETE ON tasks TO authenticated;
GRANT SELECT ON tasks TO service_role;

-- Interns may only UPDATE the status column (not instructions, deadline, etc.)
GRANT UPDATE (status) ON tasks TO authenticated;

DROP POLICY IF EXISTS "select_tasks" ON tasks;
CREATE POLICY "select_tasks" ON tasks FOR SELECT
  TO authenticated USING (
    is_admin()
    OR intern_id IN (
      SELECT i.id FROM interns i
      WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
    )
  );

DROP POLICY IF EXISTS "admin_insert_tasks" ON tasks;
CREATE POLICY "admin_insert_tasks" ON tasks FOR INSERT
  TO authenticated WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_update_tasks" ON tasks;
-- Admins can update any column (table-level grant is column-restricted, so we
-- also need a separate path). We grant the admin update via a policy that
-- allows all columns for admins by checking is_admin() — but the GRANT limits
-- which columns authenticated can touch. To let admins edit all columns, we
-- grant UPDATE on all columns to authenticated (the policy still gates who).
-- However interns would then also get all-column update. Instead, we keep the
-- column-restricted grant for safety and let admin edits go through the
-- service_role edge function or the column grant is broadened.
-- Resolution: grant UPDATE on all columns but the policy restricts admin-only.
GRANT UPDATE ON tasks TO authenticated;

DROP POLICY IF EXISTS "admin_update_tasks_all" ON tasks;
CREATE POLICY "admin_update_tasks_all" ON tasks FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS "intern_update_task_status" ON tasks;
CREATE POLICY "intern_update_task_status" ON tasks FOR UPDATE
  TO authenticated
  USING (
    intern_id IN (
      SELECT i.id FROM interns i
      WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
    )
  )
  WITH CHECK (
    intern_id IN (
      SELECT i.id FROM interns i
      WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
    )
  );

DROP POLICY IF EXISTS "admin_delete_tasks" ON tasks;
CREATE POLICY "admin_delete_tasks" ON tasks FOR DELETE
  TO authenticated USING (is_admin());

-- Helper view for admin task list with project + intern names.
CREATE OR REPLACE VIEW tasks_with_relations AS
SELECT
  t.*,
  p.title AS project_title,
  i.full_name AS intern_name,
  i.email AS intern_email,
  i.intern_id AS intern_id_human
FROM tasks t
JOIN projects p ON p.id = t.project_id
JOIN interns i ON i.id = t.intern_id;

ALTER VIEW tasks_with_relations SET (security_invoker = true);

GRANT SELECT ON tasks_with_relations TO authenticated;
