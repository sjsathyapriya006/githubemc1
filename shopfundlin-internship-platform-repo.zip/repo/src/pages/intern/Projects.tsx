import { useEffect, useState } from "react";
import { InternLayout } from "../../components/Layouts";
import { supabase } from "../../lib/supabase";
import { useAuth } from "../../lib/auth";
import type { ProjectAssignmentWithRelations, Submission, SubmissionReviewWithCategories } from "../../types";

const statusBadge = (s: string) => {
  const map: Record<string, string> = {
    Assigned: "bg-slate-100 text-slate-600",
    "In Progress": "bg-blue-50 text-blue-700",
    Submitted: "bg-amber-50 text-amber-700",
    "Revision Requested": "bg-orange-50 text-orange-700",
    Resubmitted: "bg-amber-100 text-amber-800",
    Approved: "bg-emerald-50 text-emerald-700",
    Completed: "bg-emerald-100 text-emerald-800",
  };
  return <span className={`badge ${map[s] ?? "bg-slate-100 text-slate-600"}`}>{s}</span>;
};

const difficultyBadge = (d: string | null) => {
  if (!d) return null;
  const cls = d === "easy" ? "bg-emerald-50 text-emerald-700" : d === "medium" ? "bg-amber-50 text-amber-700" : "bg-red-50 text-red-700";
  return <span className={`badge ${cls}`}>{d}</span>;
};

export default function InternProjects() {
  const { user } = useAuth();
  const [assignments, setAssignments] = useState<ProjectAssignmentWithRelations[]>([]);
  const [internId, setInternId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [progressText, setProgressText] = useState("");
  const [submitText, setSubmitText] = useState("");
  const [implementationSummary, setImplementationSummary] = useState("");
  const [completionNotes, setCompletionNotes] = useState("");
  const [repoUrl, setRepoUrl] = useState("");
  const [demoUrl, setDemoUrl] = useState("");
  const [fileUrls, setFileUrls] = useState("");
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [busy, setBusy] = useState(false);
  const [submissionsByAssignment, setSubmissionsByAssignment] = useState<Record<string, Submission[]>>({});
  const [reviewsBySubmission, setReviewsBySubmission] = useState<Record<string, SubmissionReviewWithCategories[]>>({});

  useEffect(() => {
    if (!user?.email) return;
    (async () => {
      const { data: intern } = await supabase
        .from("interns")
        .select("id")
        .eq("email", user.email)
        .maybeSingle();
      if (!intern) { setLoading(false); return; }
      setInternId(intern.id);
      await loadAssignments(intern.id);
      setLoading(false);
    })();
  }, [user?.email]);

  async function loadAssignments(iId: string) {
    const { data, error: err } = await supabase
      .from("project_assignments")
      .select("*, projects!inner(title, description, requirements, tools, deliverables), interns!inner(full_name, email, intern_id, batch_id, batches(name))")
      .eq("intern_id", iId)
      .order("created_at", { ascending: false });

    if (err) { setError(err.message); return; }

    const rows = (data as unknown as Array<Record<string, unknown>>) ?? [];
    const mapped: ProjectAssignmentWithRelations[] = rows.map((r) => {
      const proj = r.projects as Record<string, unknown>;
      const intr = r.interns as Record<string, unknown>;
      const batch = intr.batches as Record<string, unknown> | null;
      return {
        id: r.id as string,
        project_id: r.project_id as string,
        intern_id: r.intern_id as string,
        assigned_by: r.assigned_by as string | null,
        objectives: r.objectives as string,
        milestones: r.milestones as string[],
        completion_instructions: r.completion_instructions as string,
        start_date: r.start_date as string | null,
        deadline: r.deadline as string | null,
        difficulty: r.difficulty as string | null,
        max_rating: r.max_rating as number,
        status: r.status as ProjectAssignmentWithRelations["status"],
        progress_description: r.progress_description as string,
        progress_updated_at: r.progress_updated_at as string | null,
        created_at: r.created_at as string,
        updated_at: r.updated_at as string,
        project_title: proj?.title as string,
        project_description: proj?.description as string,
        project_requirements: proj?.requirements as string[],
        project_tools: proj?.tools as string[],
        project_deliverables: proj?.deliverables as string[],
        intern_name: intr?.full_name as string,
        intern_email: intr?.email as string,
        intern_id_human: intr?.intern_id as string,
        batch_name: batch?.name as string | undefined,
      };
    });
    setAssignments(mapped);

    // Load submissions for each assignment
    const subMap: Record<string, Submission[]> = {};
    const reviewMap: Record<string, SubmissionReviewWithCategories[]> = {};
    for (const a of mapped) {
      const { data: subs } = await supabase
        .from("submissions")
        .select("*")
        .eq("assignment_id", a.id)
        .order("submitted_at", { ascending: false });
      if (subs) {
        subMap[a.id] = subs as Submission[];
        for (const s of subs as Submission[]) {
          const { data: reviews } = await supabase
            .from("submission_reviews")
            .select("*")
            .eq("submission_id", s.id)
            .order("created_at", { ascending: false });
          if (reviews) reviewMap[s.id] = reviews as SubmissionReviewWithCategories[];
        }
      }
    }
    setSubmissionsByAssignment(subMap);
    setReviewsBySubmission(reviewMap);
  }

  const selected = assignments.find((a) => a.id === selectedId);
  const canSubmit = selected && ["Assigned", "In Progress", "Revision Requested", "Resubmitted"].includes(selected.status);
  const canUpdateProgress = selected && ["Assigned", "In Progress", "Revision Requested", "Resubmitted"].includes(selected.status);

  async function saveProgress() {
    if (!selected) return;
    setError(null);
    setSuccessMsg(null);
    setBusy(true);
    try {
      const { error: err } = await supabase
        .from("project_assignments")
        .update({
          progress_description: progressText.trim(),
          progress_updated_at: new Date().toISOString(),
          status: selected.status === "Assigned" ? "In Progress" : selected.status,
        })
        .eq("id", selected.id);
      if (err) throw err;
      setSuccessMsg("Progress saved.");
      if (internId) await loadAssignments(internId);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save progress.");
    }
    setBusy(false);
  }

  async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files;
    if (!files || !selected || !internId) return;
    setUploading(true);
    setUploadProgress(0);
    const urls: string[] = [];
    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const ext = file.name.split(".").pop();
        const path = `assignments/${selected.id}/${Date.now()}-${i}.${ext}`;
        const { error: upErr } = await supabase.storage
          .from("project-files")
          .upload(path, file, { upsert: false });
        if (upErr) throw upErr;
        const { data: urlData } = supabase.storage.from("project-files").getPublicUrl(path);
        urls.push(urlData.publicUrl);
        setUploadProgress(Math.round(((i + 1) / files.length) * 100));
      }
      setFileUrls((prev) => [...prev.split(/[,\n]/).map((s) => s.trim()).filter(Boolean), ...urls].join("\n"));
      setSuccessMsg(`${urls.length} file${urls.length > 1 ? "s" : ""} uploaded.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "File upload failed.");
    }
    setUploading(false);
  }

  async function submitProject() {
    if (!selected || !internId) return;
    setError(null);
    setSuccessMsg(null);
    if (!submitText.trim() && !fileUrls.trim() && !repoUrl.trim() && !demoUrl.trim()) {
      setError("Provide a submission description, files, or repository/demo links.");
      return;
    }
    setBusy(true);
    try {
      const urls = fileUrls.split(/[,\n]/).map((s) => s.trim()).filter(Boolean);
      const prevSubs = submissionsByAssignment[selected.id] ?? [];
      const nextNum = prevSubs.length + 1;

      const { error: subErr } = await supabase
        .from("submissions")
        .insert({
          task_id: selected.project_id,
          intern_id: internId,
          project_id: selected.project_id,
          assignment_id: selected.id,
          submission_text: submitText.trim(),
          implementation_summary: implementationSummary.trim(),
          completion_notes: completionNotes.trim(),
          repo_url: repoUrl.trim() || null,
          demo_url: demoUrl.trim() || null,
          file_urls: urls,
          status: selected.status === "Revision Requested" || selected.status === "Resubmitted" ? "resubmitted" : "submitted",
          submission_number: nextNum,
        })
        .select("id")
        .single();
      if (subErr) throw subErr;

      await supabase
        .from("project_assignments")
        .update({ status: selected.status === "Revision Requested" || selected.status === "Resubmitted" ? "Resubmitted" : "Submitted" })
        .eq("id", selected.id);

      setSuccessMsg("Project submitted for review! Your mentor will review it and provide feedback.");
      setSubmitText("");
      setImplementationSummary("");
      setCompletionNotes("");
      setRepoUrl("");
      setDemoUrl("");
      setFileUrls("");
      if (internId) await loadAssignments(internId);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Submission failed.");
    }
    setBusy(false);
  }

  if (loading) {
    return (
      <InternLayout>
        <div className="animate-pulse text-slate-400">Loading your projects…</div>
      </InternLayout>
    );
  }

  if (!internId) {
    return (
      <InternLayout>
        <div className="card mt-6 p-6">
          <p className="text-sm text-slate-600">Your account is ready, but an admin hasn't added you as an intern yet.</p>
        </div>
      </InternLayout>
    );
  }

  // Detail view
  if (selected) {
    const subs = submissionsByAssignment[selected.id] ?? [];
    return (
      <InternLayout>
        <button onClick={() => setSelectedId(null)} className="btn-ghost text-sm">← Back to projects</button>
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <h1 className="text-2xl font-bold text-slate-900">{selected.project_title}</h1>
          {statusBadge(selected.status)}
          {difficultyBadge(selected.difficulty)}
        </div>

        {error && <div className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}
        {successMsg && <div className="mt-4 rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-700">{successMsg}</div>}

        {/* Project details */}
        <div className="mt-6 card p-6">
          {selected.project_description && (
            <div>
              <p className="text-xs font-semibold uppercase text-slate-400">Description</p>
              <p className="mt-1 text-sm text-slate-600">{selected.project_description}</p>
            </div>
          )}
          {selected.objectives && (
            <div className="mt-4">
              <p className="text-xs font-semibold uppercase text-slate-400">Objectives</p>
              <p className="mt-1 text-sm text-slate-600">{selected.objectives}</p>
            </div>
          )}
          {selected.project_requirements && selected.project_requirements.length > 0 && (
            <div className="mt-4">
              <p className="text-xs font-semibold uppercase text-slate-400">Requirements</p>
              <ul className="mt-1 list-disc pl-4 text-sm text-slate-600">
                {selected.project_requirements.map((r, i) => <li key={i}>{r}</li>)}
              </ul>
            </div>
          )}
          {selected.project_tools && selected.project_tools.length > 0 && (
            <div className="mt-4">
              <p className="text-xs font-semibold uppercase text-slate-400">Tools / Technologies</p>
              <div className="mt-1 flex flex-wrap gap-1">
                {selected.project_tools.map((t, i) => <span key={i} className="badge bg-slate-100 text-slate-600">{t}</span>)}
              </div>
            </div>
          )}
          {selected.project_deliverables && selected.project_deliverables.length > 0 && (
            <div className="mt-4">
              <p className="text-xs font-semibold uppercase text-slate-400">Expected deliverables</p>
              <ul className="mt-1 list-disc pl-4 text-sm text-slate-600">
                {selected.project_deliverables.map((d, i) => <li key={i}>{d}</li>)}
              </ul>
            </div>
          )}
          {selected.milestones.length > 0 && (
            <div className="mt-4">
              <p className="text-xs font-semibold uppercase text-slate-400">Milestones</p>
              <ul className="mt-1 list-disc pl-4 text-sm text-slate-600">
                {selected.milestones.map((m, i) => <li key={i}>{m}</li>)}
              </ul>
            </div>
          )}
          {selected.completion_instructions && (
            <div className="mt-4">
              <p className="text-xs font-semibold uppercase text-slate-400">Completion instructions</p>
              <p className="mt-1 text-sm text-slate-600">{selected.completion_instructions}</p>
            </div>
          )}
          <div className="mt-4 flex flex-wrap gap-4 text-xs text-slate-400">
            {selected.start_date && <span>Start: {selected.start_date}</span>}
            {selected.deadline && <span>Deadline: {selected.deadline}</span>}
            <span>Max rating: {selected.max_rating}/10</span>
          </div>
        </div>

        {/* Progress tracking */}
        {canUpdateProgress && (
          <div className="mt-6 card p-6">
            <h2 className="text-lg font-semibold text-slate-900">Progress tracking</h2>
            <textarea
              rows={4}
              className="input mt-3"
              value={progressText}
              onChange={(e) => setProgressText(e.target.value)}
              placeholder="Describe your current progress, what you've done so far, and what's remaining…"
            />
            <button onClick={saveProgress} disabled={busy} className="btn-primary mt-3">
              {busy ? "Saving…" : "Save progress"}
            </button>
            {selected.progress_description && (
              <div className="mt-4 rounded-lg bg-slate-50 p-3">
                <p className="text-xs font-semibold uppercase text-slate-400">Last saved progress</p>
                <p className="mt-1 whitespace-pre-wrap text-sm text-slate-600">{selected.progress_description}</p>
                {selected.progress_updated_at && (
                  <p className="mt-1 text-xs text-slate-400">Updated {new Date(selected.progress_updated_at).toLocaleString()}</p>
                )}
              </div>
            )}
          </div>
        )}

        {/* Submit project */}
        {canSubmit && (
          <div className="mt-6 card p-6">
            <h2 className="text-lg font-semibold text-slate-900">Submit project for review</h2>
            <div className="mt-4 space-y-4">
              <div>
                <label className="label">Submission description *</label>
                <textarea rows={4} className="input" value={submitText} onChange={(e) => setSubmitText(e.target.value)} placeholder="Describe your work, approach, and key decisions…" />
              </div>
              <div>
                <label className="label">Implementation summary</label>
                <textarea rows={2} className="input" value={implementationSummary} onChange={(e) => setImplementationSummary(e.target.value)} placeholder="How did you implement it? Key technical decisions…" />
              </div>
              <div>
                <label className="label">Completion notes</label>
                <textarea rows={2} className="input" value={completionNotes} onChange={(e) => setCompletionNotes(e.target.value)} placeholder="Any notes about completion, testing, or known issues…" />
              </div>
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <div>
                  <label className="label">Repository URL</label>
                  <input className="input" value={repoUrl} onChange={(e) => setRepoUrl(e.target.value)} placeholder="https://github.com/…" />
                </div>
                <div>
                  <label className="label">Live demo URL</label>
                  <input className="input" value={demoUrl} onChange={(e) => setDemoUrl(e.target.value)} placeholder="https://my-demo.vercel.app/…" />
                </div>
              </div>

              {/* File upload */}
              <div>
                <label className="label">Upload project files</label>
                <input
                  type="file"
                  multiple
                  accept=".zip,.pdf,.doc,.docx,.png,.jpg,.jpeg,.gif,.txt,.js,.ts,.tsx,.jsx,.py,.java,.cpp,.c,.go,.rs,.rb,.php,.sql,.json,.xml,.yml,.yaml,.md"
                  onChange={handleFileUpload}
                  className="block w-full text-sm text-slate-500 file:mr-3 file:rounded-lg file:border-0 file:bg-brand-50 file:px-4 file:py-2 file:text-sm file:font-medium file:text-brand-700 hover:file:bg-brand-100"
                />
                {uploading && (
                  <div className="mt-2">
                    <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                      <div className="h-full rounded-full bg-brand-500 transition-all" style={{ width: `${uploadProgress}%` }} />
                    </div>
                    <p className="mt-1 text-xs text-slate-400">Uploading… {uploadProgress}%</p>
                  </div>
                )}
              </div>

              <div>
                <label className="label">Additional file / link URLs</label>
                <textarea rows={2} className="input" value={fileUrls} onChange={(e) => setFileUrls(e.target.value)} placeholder="https://…" />
              </div>

              <button onClick={submitProject} disabled={busy} className="btn-primary">
                {busy ? "Submitting…" : "Submit for review"}
              </button>
            </div>
          </div>
        )}

        {/* Submission history */}
        <div className="mt-6">
          <h2 className="text-lg font-semibold text-slate-900">Submission & review history</h2>
          {subs.length === 0 ? (
            <div className="card mt-4 p-6 text-center text-slate-400">No submissions yet.</div>
          ) : (
            <div className="mt-4 space-y-4">
              {subs.map((s) => {
                const reviews = reviewsBySubmission[s.id] ?? [];
                return (
                  <div key={s.id} className="card p-5">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="badge bg-slate-100 text-slate-500">Attempt #{s.submission_number}</span>
                      <span className={`badge ${s.status === "approved" ? "bg-emerald-50 text-emerald-700" : s.status === "changes_requested" ? "bg-orange-50 text-orange-700" : s.status === "rejected" ? "bg-red-50 text-red-700" : "bg-amber-50 text-amber-700"}`}>
                        {s.status.replace(/_/g, " ")}
                      </span>
                      <span className="text-xs text-slate-400">{new Date(s.submitted_at).toLocaleString()}</span>
                    </div>
                    {s.submission_text && <p className="mt-2 text-sm text-slate-600">{s.submission_text}</p>}
                    {s.implementation_summary && <p className="mt-1 text-xs text-slate-500">Implementation: {s.implementation_summary}</p>}
                    {s.repo_url && <p className="mt-1 text-xs"><a href={s.repo_url} target="_blank" rel="noreferrer" className="text-brand-600 hover:underline">Repository</a></p>}
                    {s.demo_url && <p className="mt-1 text-xs"><a href={s.demo_url} target="_blank" rel="noreferrer" className="text-brand-600 hover:underline">Live demo</a></p>}
                    {s.file_urls.length > 0 && (
                      <div className="mt-2">
                        <p className="text-xs font-semibold uppercase text-slate-400">Files</p>
                        <ul className="mt-1 space-y-1">
                          {s.file_urls.map((url, i) => <li key={i}><a href={url} target="_blank" rel="noreferrer" className="text-xs text-brand-600 hover:underline">{url.split("/").pop() ?? url}</a></li>)}
                        </ul>
                      </div>
                    )}
                    {reviews.length > 0 && (
                      <div className="mt-3 border-t border-slate-200 pt-3">
                        {reviews.map((r) => (
                          <div key={r.id} className="mt-2 rounded-lg bg-slate-50 p-3">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className={`badge ${r.decision === "approved" ? "bg-emerald-50 text-emerald-700" : r.decision === "changes_requested" ? "bg-orange-50 text-orange-700" : "bg-red-50 text-red-700"}`}>
                                {r.decision.replace(/_/g, " ")}
                              </span>
                              {r.score != null && <span className="badge bg-brand-50 text-brand-700">{r.score}/10</span>}
                              {r.reviewer_name && <span className="text-xs text-slate-400">by {r.reviewer_name}</span>}
                            </div>
                            {r.feedback && <p className="mt-2 text-sm text-slate-600">{r.feedback}</p>}
                            {(r.rating_code_quality != null || r.rating_functionality != null || r.rating_documentation != null || r.rating_creativity != null || r.rating_deadline_adherence != null) && (
                              <div className="mt-2 grid grid-cols-2 gap-2 text-xs md:grid-cols-5">
                                {r.rating_code_quality != null && <div><span className="text-slate-400">Code quality:</span> <span className="font-medium text-slate-700">{r.rating_code_quality}/10</span></div>}
                                {r.rating_functionality != null && <div><span className="text-slate-400">Functionality:</span> <span className="font-medium text-slate-700">{r.rating_functionality}/10</span></div>}
                                {r.rating_documentation != null && <div><span className="text-slate-400">Documentation:</span> <span className="font-medium text-slate-700">{r.rating_documentation}/10</span></div>}
                                {r.rating_creativity != null && <div><span className="text-slate-400">Creativity:</span> <span className="font-medium text-slate-700">{r.rating_creativity}/10</span></div>}
                                {r.rating_deadline_adherence != null && <div><span className="text-slate-400">Deadline:</span> <span className="font-medium text-slate-700">{r.rating_deadline_adherence}/10</span></div>}
                              </div>
                            )}
                            {r.strengths && <p className="mt-1 text-xs text-emerald-700">Strengths: {r.strengths}</p>}
                            {r.areas_for_improvement && <p className="mt-1 text-xs text-orange-700">Improvement: {r.areas_for_improvement}</p>}
                            {r.score_override_reason && <p className="mt-1 text-xs text-slate-400">Score override: {r.score_override_reason}</p>}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </InternLayout>
    );
  }

  // List view
  return (
    <InternLayout>
      <h1 className="text-2xl font-bold text-slate-900">My Projects</h1>
      <p className="mt-1 text-sm text-slate-500">Your assigned projects, progress, and review feedback.</p>

      {error && <div className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}
      {successMsg && <div className="mt-4 rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-700">{successMsg}</div>}

      <div className="mt-6 space-y-4">
        {assignments.length === 0 ? (
          <div className="card p-8 text-center text-slate-400">
            No projects assigned yet. When an admin assigns you a project, it will appear here.
          </div>
        ) : (
          assignments.map((a) => (
            <button
              key={a.id}
              onClick={() => {
                setSelectedId(a.id);
                setProgressText(a.progress_description);
                setError(null);
                setSuccessMsg(null);
              }}
              className="card block w-full p-5 text-left transition-shadow hover:shadow-md"
            >
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-base font-semibold text-slate-900">{a.project_title}</h3>
                {statusBadge(a.status)}
                {difficultyBadge(a.difficulty)}
              </div>
              {a.project_description && <p className="mt-1 text-sm text-slate-500 line-clamp-2">{a.project_description}</p>}
              <div className="mt-2 flex flex-wrap gap-3 text-xs text-slate-400">
                {a.deadline && <span>Deadline: {a.deadline}</span>}
                {a.milestones.length > 0 && <span>{a.milestones.length} milestones</span>}
                <span>Max rating: {a.max_rating}/10</span>
                {(submissionsByAssignment[a.id] ?? []).length > 0 && (
                  <span>{(submissionsByAssignment[a.id] ?? []).length} submission{(submissionsByAssignment[a.id] ?? []).length > 1 ? "s" : ""}</span>
                )}
              </div>
            </button>
          ))
        )}
      </div>
    </InternLayout>
  );
}
