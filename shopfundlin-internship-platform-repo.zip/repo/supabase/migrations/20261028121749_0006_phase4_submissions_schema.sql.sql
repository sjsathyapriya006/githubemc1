/*
# Phase 4 — Project Submission Portal

## Purpose
Interns submit their work for assigned tasks. Admins review submissions,
approve them, request changes, or reject them. Each review includes
structured feedback. The submission lifecycle integrates with the existing
task status flow (Assigned → In Progress → Submitted → Completed/Rejected).

## New tables

### submissions
- `id` uuid PK.
- `task_id` uuid FK -> tasks(id) ON DELETE CASCADE.
- `intern_id` uuid FK -> interns(id) ON DELETE CASCADE.
- `project_id` uuid FK -> projects(id) ON DELETE CASCADE.
- `submission_text` text — the intern's written submission / explanation.
- `file_urls` text[] — list of URLs to submitted files (GitHub, docs, etc.).
- `status` text — 'submitted' | 'under_review' | 'approved' | 'changes_requested' | 'rejected' | 'resubmitted'.
- `submission_number` int — 1 for first submission, increments on resubmit.
- `submitted_at` timestamptz.
- `reviewed_at` timestamptz — when admin last reviewed.
- `created_at` timestamptz.

### submission_reviews
- `id` uuid PK.
- `submission_id` uuid FK -> submissions(id) ON DELETE CASCADE.
- `reviewer_id` uuid — admin profile id (defaults to auth.uid()).
- `decision` text — 'approved' | 'changes_requested' | 'rejected'.
- `feedback` text — structured feedback for the intern.
- `strengths` text — what was done well.
- `areas_for_improvement` text — what needs work.
- `score` int — 1-10 rating (nullable).
- `created_at` timestamptz.

## New views

### submissions_with_details
Joins submissions → tasks → projects → interns, plus latest review info.
Marked security_invoker so RLS applies.

## Security
- RLS enabled on both new tables.
- submissions: admins have full CRUD; interns can read + insert their own
  submissions (matched via interns.email = auth email). Interns can only
  UPDATE status to 'resubmitted' (column-restricted grant). Full updates
  by admins go through a SECURITY DEFINER function.
- submission_reviews: admins have full CRUD; interns can read reviews on
  their own submissions. Interns cannot create/update/delete reviews.
- SECURITY DEFINER function `admin_review_submission(...)` lets admins
  record a review decision and update the submission + task status in one
  atomic operation.
- SECURITY DEFINER function `intern_submit_task(...)` lets interns create
  a submission and flip the task status to 'Submitted' atomically.
- SECURITY DEFINER function `intern_resubmit_task(...)` lets interns
  resubmit after changes requested, incrementing submission_number.

## Notes
1. When an admin approves a submission, the task status is set to
   'Completed' and the submission status to 'approved'.
2. When changes are requested, the task goes to 'In Progress' and the
   submission to 'changes_requested'. The intern can then resubmit.
3. When rejected, the task stays at 'Submitted' and the submission is
   'rejected'. Admin can still request changes later.
4. submission_number auto-increments per task — querying MAX + 1 on insert.
*/

CREATE TABLE IF NOT EXISTS submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  intern_id uuid NOT NULL REFERENCES interns(id) ON DELETE CASCADE,
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  submission_text text NOT NULL DEFAULT '',
  file_urls text[] NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'submitted' CHECK (
    status IN ('submitted', 'under_review', 'approved', 'changes_requested', 'rejected', 'resubmitted')
  ),
  submission_number int NOT NULL DEFAULT 1,
  submitted_at timestamptz NOT NULL DEFAULT now(),
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_submissions_task ON submissions(task_id);
CREATE INDEX IF NOT EXISTS idx_submissions_intern ON submissions(intern_id);
CREATE INDEX IF NOT EXISTS idx_submissions_status ON submissions(status);

ALTER TABLE submissions ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT ON submissions TO authenticated;
GRANT SELECT ON submissions TO service_role;
-- Interns can only update the status column (to resubmit)
GRANT UPDATE (status) ON submissions TO authenticated;

-- Admins can read all submissions; interns can read their own
DROP POLICY IF EXISTS "select_submissions" ON submissions;
CREATE POLICY "select_submissions" ON submissions FOR SELECT
  TO authenticated USING (
    is_admin()
    OR intern_id IN (
      SELECT i.id FROM interns i
      WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
    )
  );

-- Admins and interns can insert (interns only for their own tasks)
DROP POLICY IF EXISTS "insert_submissions" ON submissions;
CREATE POLICY "insert_submissions" ON submissions FOR INSERT
  TO authenticated WITH CHECK (
    is_admin()
    OR intern_id IN (
      SELECT i.id FROM interns i
      WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
    )
  );

-- Admins can update submission status; interns can update their own to resubmitted
DROP POLICY IF EXISTS "admin_update_submissions" ON submissions;
CREATE POLICY "admin_update_submissions" ON submissions FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS "intern_update_submission_status" ON submissions;
CREATE POLICY "intern_update_submission_status" ON submissions FOR UPDATE
  TO authenticated
  USING (
    intern_id IN (
      SELECT i.id FROM interns i
      WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
    )
  )
  WITH CHECK (
    intern_id IN (
      SELECT i.id FROM interns i
      WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
    )
  );

-- Admins can delete submissions
DROP POLICY IF EXISTS "admin_delete_submissions" ON submissions;
CREATE POLICY "admin_delete_submissions" ON submissions FOR DELETE
  TO authenticated USING (is_admin());

-- ── submission_reviews table ──

CREATE TABLE IF NOT EXISTS submission_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  submission_id uuid NOT NULL REFERENCES submissions(id) ON DELETE CASCADE,
  reviewer_id uuid DEFAULT auth.uid(),
  decision text NOT NULL CHECK (decision IN ('approved', 'changes_requested', 'rejected')),
  feedback text NOT NULL DEFAULT '',
  strengths text NOT NULL DEFAULT '',
  areas_for_improvement text NOT NULL DEFAULT '',
  score int CHECK (score >= 1 AND score <= 10),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_reviews_submission ON submission_reviews(submission_id);

ALTER TABLE submission_reviews ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON submission_reviews TO authenticated;
GRANT SELECT ON submission_reviews TO service_role;
-- Only admins insert/update/delete reviews
GRANT INSERT, UPDATE, DELETE ON submission_reviews TO authenticated;

-- Admins can read all reviews; interns can read reviews on their own submissions
DROP POLICY IF EXISTS "select_reviews" ON submission_reviews;
CREATE POLICY "select_reviews" ON submission_reviews FOR SELECT
  TO authenticated USING (
    is_admin()
    OR submission_id IN (
      SELECT s.id FROM submissions s
      WHERE s.intern_id IN (
        SELECT i.id FROM interns i
        WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
      )
    )
  );

-- Only admins can insert reviews
DROP POLICY IF EXISTS "admin_insert_reviews" ON submission_reviews;
CREATE POLICY "admin_insert_reviews" ON submission_reviews FOR INSERT
  TO authenticated WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_update_reviews" ON submission_reviews;
CREATE POLICY "admin_update_reviews" ON submission_reviews FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_delete_reviews" ON submission_reviews;
CREATE POLICY "admin_delete_reviews" ON submission_reviews FOR DELETE
  TO authenticated USING (is_admin());

-- ── submissions_with_details view ──

CREATE OR REPLACE VIEW submissions_with_details AS
SELECT
  s.*,
  t.title AS task_title,
  t.instructions AS task_instructions,
  t.deliverables AS task_deliverables,
  t.review_criteria AS task_review_criteria,
  t.status AS task_status,
  p.title AS project_title,
  i.full_name AS intern_name,
  i.email AS intern_email,
  i.intern_id AS intern_id_human,
  sr.decision AS latest_review_decision,
  sr.feedback AS latest_review_feedback,
  sr.strengths AS latest_review_strengths,
  sr.areas_for_improvement AS latest_review_improvement,
  sr.score AS latest_review_score,
  sr.created_at AS latest_review_at
FROM submissions s
JOIN tasks t ON t.id = s.task_id
JOIN projects p ON p.id = s.project_id
JOIN interns i ON i.id = s.intern_id
LEFT JOIN LATERAL (
  SELECT sr.* FROM submission_reviews sr
  WHERE sr.submission_id = s.id
  ORDER BY sr.created_at DESC
  LIMIT 1
) sr ON true;

ALTER VIEW submissions_with_details SET (security_invoker = true);
GRANT SELECT ON submissions_with_details TO authenticated;

-- ── SECURITY DEFINER: intern_submit_task ──
-- Intern creates a submission and flips task status to 'Submitted' atomically.

CREATE OR REPLACE FUNCTION intern_submit_task(
  p_task_id uuid,
  p_submission_text text,
  p_file_urls text[]
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_intern_id uuid;
  v_project_id uuid;
  v_task_status text;
  v_submission_id uuid;
  v_next_number int;
BEGIN
  -- Find the intern by auth email
  SELECT i.id INTO v_intern_id
  FROM interns i
  WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
  LIMIT 1;

  IF v_intern_id IS NULL THEN
    RAISE EXCEPTION 'No intern record found for your account';
  END IF;

  -- Verify the task belongs to this intern and is in a submittable state
  SELECT t.project_id, t.status INTO v_project_id, v_task_status
  FROM tasks t
  WHERE t.id = p_task_id AND t.intern_id = v_intern_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Task not found or not assigned to you';
  END IF;

  IF v_task_status NOT IN ('Assigned', 'In Progress', 'Changes Requested', 'Submitted') THEN
    RAISE EXCEPTION 'This task is not in a submittable state (current: %)', v_task_status;
  END IF;

  -- Calculate next submission number
  SELECT COALESCE(MAX(s.submission_number), 0) + 1 INTO v_next_number
  FROM submissions s WHERE s.task_id = p_task_id;

  -- Insert the submission
  INSERT INTO submissions (task_id, intern_id, project_id, submission_text, file_urls, status, submission_number, submitted_at)
  VALUES (p_task_id, v_intern_id, v_project_id, p_submission_text, p_file_urls,
          CASE WHEN v_next_number > 1 THEN 'resubmitted' ELSE 'submitted' END,
          v_next_number, now())
  RETURNING id INTO v_submission_id;

  -- Update task status to Submitted
  UPDATE tasks SET status = 'Submitted' WHERE id = p_task_id;

  RETURN v_submission_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION intern_submit_task(uuid, text, text[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION intern_submit_task(uuid, text, text[]) TO authenticated;

-- ── SECURITY DEFINER: admin_review_submission ──
-- Admin records a review decision and updates submission + task status atomically.

CREATE OR REPLACE FUNCTION admin_review_submission(
  p_submission_id uuid,
  p_decision text,
  p_feedback text,
  p_strengths text,
  p_areas_for_improvement text,
  p_score int
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_task_id uuid;
  v_task_status text;
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Only admins can review submissions';
  END IF;

  IF p_decision NOT IN ('approved', 'changes_requested', 'rejected') THEN
    RAISE EXCEPTION 'Invalid decision: %', p_decision;
  END IF;

  -- Get the task for this submission
  SELECT s.task_id INTO v_task_id FROM submissions s WHERE s.id = p_submission_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Submission not found';
  END IF;

  -- Insert the review
  INSERT INTO submission_reviews (submission_id, reviewer_id, decision, feedback, strengths, areas_for_improvement, score)
  VALUES (p_submission_id, auth.uid(), p_decision, p_feedback, p_strengths, p_areas_for_improvement, p_score);

  -- Update submission status + reviewed_at
  UPDATE submissions
  SET status = p_decision, reviewed_at = now()
  WHERE id = p_submission_id;

  -- Update task status based on decision
  IF p_decision = 'approved' THEN
    UPDATE tasks SET status = 'Completed' WHERE id = v_task_id;
  ELSIF p_decision = 'changes_requested' THEN
    UPDATE tasks SET status = 'In Progress' WHERE id = v_task_id;
  ELSIF p_decision = 'rejected' THEN
    UPDATE tasks SET status = 'Rejected' WHERE id = v_task_id;
  END IF;
END;
$$;

REVOKE EXECUTE ON FUNCTION admin_review_submission(uuid, text, text, text, text, int) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION admin_review_submission(uuid, text, text, text, text, int) TO authenticated;