import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface CreateMeetingRequest {
  title: string;
  description?: string;
  meeting_type?: string;
  scheduled_date: string;
  scheduled_time: string;
  duration_minutes?: number;
  batch_id?: string;
  intern_ids?: string[];
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") as string;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") as string;
    const googleClientId = Deno.env.get("GOOGLE_CLIENT_ID");
    const googleClientSecret = Deno.env.get("GOOGLE_CLIENT_SECRET");
    const googleRefreshToken = Deno.env.get("GOOGLE_REFRESH_TOKEN");

    const supabase = createClient(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false },
    });

    const body = (await req.json()) as CreateMeetingRequest;

    if (!body.title || !body.scheduled_date || !body.scheduled_time) {
      return new Response(JSON.stringify({ error: "title, scheduled_date, and scheduled_time are required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const duration = body.duration_minutes || 60;
    const meetingType = body.meeting_type || "initial_review";
    let usedMock = false;
    let meetingLink = "";
    let calendarEventId = null;

    if (googleClientId && googleClientSecret && googleRefreshToken) {
      // Real Google Calendar API integration
      try {
        // Exchange refresh token for access token
        const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams({
            client_id: googleClientId,
            client_secret: googleClientSecret,
            refresh_token: googleRefreshToken,
            grant_type: "refresh_token",
          }),
        });

        if (!tokenResponse.ok) {
          throw new Error(`Google OAuth token exchange failed (${tokenResponse.status})`);
        }

        const tokenData = await tokenResponse.json();
        const accessToken = tokenData.access_token;

        // Build start/end datetime (assume timezone UTC for simplicity; admin can adjust)
        const startDateTime = `${body.scheduled_date}T${body.scheduled_time}:00`;
        const endDate = new Date(`${body.scheduled_date}T${body.scheduled_time}:00Z`);
        endDate.setMinutes(endDate.getMinutes() + duration);
        const endDateTime = endDate.toISOString().replace(/\.\d{3}Z$/, "");

        // Create calendar event with Google Meet conferencing
        const eventResponse = await fetch("https://www.googleapis.com/calendar/v3/calendars/primary/events?conferenceDataVersion=1", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            summary: body.title,
            description: body.description || "",
            start: { dateTime: startDateTime, timeZone: "UTC" },
            end: { dateTime: endDateTime, timeZone: "UTC" },
            conferenceData: {
              createRequest: { requestId: crypto.randomUUID() },
            },
          }),
        });

        if (!eventResponse.ok) {
          const errText = await eventResponse.text();
          throw new Error(`Google Calendar API error (${eventResponse.status}): ${errText}`);
        }

        const eventData = await eventResponse.json();
        calendarEventId = eventData.id;
        meetingLink = eventData.conferenceData?.entryPoints?.find(
          (e: { entryPointType: string }) => e.entryPointType === "video"
        )?.uri || eventData.hangoutLink || "";
      } catch (err) {
        return new Response(JSON.stringify({
          error: "Google Calendar integration failed: " + err.message,
          mock: false,
        }), {
          status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    } else {
      // Mock mode — generate a placeholder Meet link
      usedMock = true;
      const mockId = crypto.randomUUID().split("-")[0];
      meetingLink = `https://meet.google.com/mock-${mockId}`;
    }

    // Insert meeting into database
    const { data: meeting, error: meetingError } = await supabase
      .from("meetings")
      .insert({
        title: body.title,
        description: body.description || "",
        meeting_type: meetingType,
        scheduled_date: body.scheduled_date,
        scheduled_time: body.scheduled_time,
        duration_minutes: duration,
        meeting_link: meetingLink,
        calendar_event_id: calendarEventId,
        status: "scheduled",
        batch_id: body.batch_id || null,
      })
      .select("id")
      .single();

    if (meetingError) {
      return new Response(JSON.stringify({ error: "Failed to create meeting: " + meetingError.message }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Add attendees
    if (body.intern_ids && body.intern_ids.length > 0) {
      const attendees = body.intern_ids.map((internId) => ({
        meeting_id: meeting.id,
        intern_id: internId,
        invitation_status: "pending",
      }));
      await supabase.from("meeting_attendees").insert(attendees);
    }

    return new Response(JSON.stringify({
      success: true,
      meeting_id: meeting.id,
      meeting_link: meetingLink,
      calendar_event_id: calendarEventId,
      mock: usedMock,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
