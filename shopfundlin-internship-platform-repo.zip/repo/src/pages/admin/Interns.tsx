import { useEffect, useMemo, useState } from "react";
import { AdminLayout } from "../../components/Layouts";
import { supabase } from "../../lib/supabase";
import type { Batch, Intern } from "../../types";

const emptyForm = {
  full_name: "",
  email: "",
  phone: "",
  college: "",
  department: "",
  role: "",
  batch_id: "",
  start_date: "",
  expected_end_date: "",
};

export default function AdminInterns() {
  const [interns, setInterns] = useState<Intern[]>([]);
  const [batches, setBatches] = useState<Batch[]>([]);
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function load() {
    const [{ data: internRows }, { data: batchRows }] = await Promise.all([
      supabase.from("interns").select("*").order("created_at", { ascending: false }),
      supabase.from("batches").select("*").order("created_at", { ascending: false }),
    ]);
    setInterns((internRows as Intern[]) ?? []);
    setBatches((batchRows as Batch[]) ?? []);
  }

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return interns;
    return interns.filter(
      (i) =>
        i.full_name.toLowerCase().includes(q) ||
        i.email.toLowerCase().includes(q) ||
        i.intern_id.toLowerCase().includes(q)
    );
  }, [interns, search]);

  const batchName = (id: string | null) =>
    id ? batches.find((b) => b.id === id)?.name ?? "—" : "—";

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!form.full_name.trim() || !form.email.trim()) {
      setError("Full name and email are required.");
      return;
    }
    const dup = interns.find(
      (i) => i.email.toLowerCase() === form.email.trim().toLowerCase()
    );
    if (dup) {
      setError("An intern with this email already exists.");
      return;
    }
    setBusy(true);
    const { data: idRow } = await supabase.rpc("next_intern_id");
    const internId = idRow as string;
    const { error } = await supabase.from("interns").insert({
      intern_id: internId,
      full_name: form.full_name.trim(),
      email: form.email.trim(),
      phone: form.phone.trim() || null,
      college: form.college.trim() || null,
      department: form.department.trim() || null,
      role: form.role.trim() || null,
      batch_id: form.batch_id || null,
      start_date: form.start_date || null,
      expected_end_date: form.expected_end_date || null,
      status: "Registered",
    });
    setBusy(false);
    if (error) {
      setError(error.message);
      return;
    }
    setForm(emptyForm);
    setShowForm(false);
    load();
  }

  return (
    <AdminLayout>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Interns</h1>
          <p className="mt-1 text-sm text-slate-500">Add, search, and manage interns.</p>
        </div>
        <button onClick={() => setShowForm((s) => !s)} className="btn-primary">
          {showForm ? "Close form" : "Add intern"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="card mt-6 p-6">
          <h2 className="text-lg font-semibold text-slate-900">New intern registration</h2>
          <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
            <div>
              <label className="label">Full name *</label>
              <input className="input" value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} />
            </div>
            <div>
              <label className="label">Email *</label>
              <input type="email" className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
            <div>
              <label className="label">Phone</label>
              <input className="input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </div>
            <div>
              <label className="label">College</label>
              <input className="input" value={form.college} onChange={(e) => setForm({ ...form, college: e.target.value })} />
            </div>
            <div>
              <label className="label">Department</label>
              <input className="input" value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} />
            </div>
            <div>
              <label className="label">Internship role</label>
              <input className="input" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} />
            </div>
            <div>
              <label className="label">Batch</label>
              <select className="input" value={form.batch_id} onChange={(e) => setForm({ ...form, batch_id: e.target.value })}>
                <option value="">— Select batch —</option>
                {batches.map((b) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Start date</label>
              <input type="date" className="input" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} />
            </div>
            <div>
              <label className="label">Expected end date</label>
              <input type="date" className="input" value={form.expected_end_date} onChange={(e) => setForm({ ...form, expected_end_date: e.target.value })} />
            </div>
          </div>
          {error && <div className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}
          <div className="mt-4 flex gap-2">
            <button type="submit" disabled={busy} className="btn-primary">
              {busy ? "Saving…" : "Save intern"}
            </button>
            <button type="button" onClick={() => setShowForm(false)} className="btn-secondary">Cancel</button>
          </div>
        </form>
      )}

      <div className="mt-6">
        <input
          placeholder="Search by name, email, or intern ID…"
          className="input"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="card mt-4 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-xs uppercase text-slate-500">
              <tr>
                <th className="px-4 py-3">Intern ID</th>
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Email</th>
                <th className="px-4 py-3">Batch</th>
                <th className="px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-slate-400">No interns found.</td>
                </tr>
              )}
              {filtered.map((i) => (
                <tr key={i.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3 font-mono text-xs text-slate-500">{i.intern_id}</td>
                  <td className="px-4 py-3 font-medium text-slate-900">{i.full_name}</td>
                  <td className="px-4 py-3 text-slate-600">{i.email}</td>
                  <td className="px-4 py-3 text-slate-600">{batchName(i.batch_id)}</td>
                  <td className="px-4 py-3">
                    <span className="badge bg-brand-50 text-brand-700">{i.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
}
