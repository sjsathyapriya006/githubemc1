/*
# Phase 8a — Project Assignments + Audit Trail

## Purpose
Creates a dedicated `project_assignments` table that links an individual intern
to a project with assignment-specific metadata: objectives, milestones, start
date, deadline, difficulty, status, and an audit trail for reassignments and
deadline extensions. This is distinct from the existing `tasks` table because
it represents the full intern-to-project assignment lifecycle (not individual
tasks within a project).

## New tables

### project_assignments
- id (uuid PK)
- project_id (FK → projects.id) — which project is assigned
- intern_id (FK → interns.id) — which intern it's assigned to
- assigned_by (uuid, FK → auth.users.id) — admin who made the assignment
- objectives (text) — project objectives for this intern
- milestones (text[]) — list of milestone descriptions
- completion_instructions (text) — instructions for completing the project
- start_date (date) — when the intern should start
- deadline (date) — when the project is due
- difficulty (text, check: easy/medium/hard) — difficulty level
- max_rating (int, default 10) — maximum rating score
- status (text, check constraint) — Assigned/In Progress/Submitted/Revision Requested/Resubmitted/Approved/Completed
- progress_description (text) — intern's saved progress notes
- progress_updated_at (timestamptz) — when progress was last updated
- created_at (timestamptz)
- updated_at (timestamptz)

Unique constraint on (project_id, intern_id) to prevent duplicate assignments.

### project_assignment_audit
- id (uuid PK)
- assignment_id (FK → project_assignments.id ON DELETE CASCADE)
- action (text) — created/reassigned/deadline_extended/status_changed
- old_value (text) — previous value
- new_value (text) — new value
- changed_by (uuid, FK → auth.users.id) — admin who made the change
- changed_at (timestamptz)

## Security
- RLS enabled on both tables.
- Admins have full CRUD on project_assignments.
- Interns can SELECT only their own assignments (matched via interns.email = auth email).
- Interns can UPDATE only progress_description and progress_updated_at on their own assignments.
- Audit table: admins can SELECT/INSERT, interns can SELECT their own assignment's audit trail.
- Grants: authenticated gets SELECT on both tables. Additional column-restricted UPDATE on
  project_assignments for interns (progress_description, progress_updated_at only).
- service_role gets full access for edge functions.
*/

CREATE TABLE IF NOT EXISTS project_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  intern_id uuid NOT NULL REFERENCES interns(id) ON DELETE CASCADE,
  assigned_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  objectives text NOT NULL DEFAULT '',
  milestones text[] NOT NULL DEFAULT '{}',
  completion_instructions text NOT NULL DEFAULT '',
  start_date date,
  deadline date,
  difficulty text CHECK (difficulty IN ('easy', 'medium', 'hard')),
  max_rating integer NOT NULL DEFAULT 10,
  status text NOT NULL DEFAULT 'Assigned' CHECK (
    status IN ('Assigned', 'In Progress', 'Submitted', 'Revision Requested', 'Resubmitted', 'Approved', 'Completed')
  ),
  progress_description text NOT NULL DEFAULT '',
  progress_updated_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (project_id, intern_id)
);

ALTER TABLE project_assignments ENABLE ROW LEVEL SECURITY;

-- Admin full CRUD
GRANT SELECT, INSERT, UPDATE, DELETE ON project_assignments TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON project_assignments TO service_role;

DROP POLICY IF EXISTS "admin_select_project_assignments" ON project_assignments;
CREATE POLICY "admin_select_project_assignments"
ON project_assignments FOR SELECT
TO authenticated USING (is_admin());

DROP POLICY IF EXISTS "intern_select_own_project_assignments" ON project_assignments;
CREATE POLICY "intern_select_own_project_assignments"
ON project_assignments FOR SELECT
TO authenticated
USING (
  intern_id IN (
    SELECT i.id FROM interns i
    WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
  )
);

DROP POLICY IF EXISTS "admin_insert_project_assignments" ON project_assignments;
CREATE POLICY "admin_insert_project_assignments"
ON project_assignments FOR INSERT
TO authenticated WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_update_project_assignments" ON project_assignments;
CREATE POLICY "admin_update_project_assignments"
ON project_assignments FOR UPDATE
TO authenticated USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS "intern_update_own_progress" ON project_assignments;
CREATE POLICY "intern_update_own_progress"
ON project_assignments FOR UPDATE
TO authenticated
USING (
  intern_id IN (
    SELECT i.id FROM interns i
    WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
  )
)
WITH CHECK (
  intern_id IN (
    SELECT i.id FROM interns i
    WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
  )
);

DROP POLICY IF EXISTS "admin_delete_project_assignments" ON project_assignments;
CREATE POLICY "admin_delete_project_assignments"
ON project_assignments FOR DELETE
TO authenticated USING (is_admin());

-- Audit table
CREATE TABLE IF NOT EXISTS project_assignment_audit (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  assignment_id uuid NOT NULL REFERENCES project_assignments(id) ON DELETE CASCADE,
  action text NOT NULL,
  old_value text,
  new_value text,
  changed_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  changed_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE project_assignment_audit ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT ON project_assignment_audit TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON project_assignment_audit TO service_role;

DROP POLICY IF EXISTS "admin_select_audit" ON project_assignment_audit;
CREATE POLICY "admin_select_audit"
ON project_assignment_audit FOR SELECT
TO authenticated USING (is_admin());

DROP POLICY IF EXISTS "intern_select_own_audit" ON project_assignment_audit;
CREATE POLICY "intern_select_own_audit"
ON project_assignment_audit FOR SELECT
TO authenticated
USING (
  assignment_id IN (
    SELECT pa.id FROM project_assignments pa
    WHERE pa.intern_id IN (
      SELECT i.id FROM interns i
      WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
    )
  )
);

DROP POLICY IF EXISTS "admin_insert_audit" ON project_assignment_audit;
CREATE POLICY "admin_insert_audit"
ON project_assignment_audit FOR INSERT
TO authenticated WITH CHECK (is_admin());

-- Indexes
CREATE INDEX IF NOT EXISTS idx_project_assignments_intern ON project_assignments(intern_id);
CREATE INDEX IF NOT EXISTS idx_project_assignments_project ON project_assignments(project_id);
CREATE INDEX IF NOT EXISTS idx_project_assignments_status ON project_assignments(status);
CREATE INDEX IF NOT EXISTS idx_audit_assignment ON project_assignment_audit(assignment_id);

-- updated_at trigger
CREATE OR REPLACE FUNCTION update_project_assignments_updated_at()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_project_assignments_updated_at ON project_assignments;
CREATE TRIGGER trg_project_assignments_updated_at
  BEFORE UPDATE ON project_assignments
  FOR EACH ROW EXECUTE FUNCTION update_project_assignments_updated_at();