import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface SendEmailRequest {
  template_id?: string;
  template_type?: string;
  intern_id?: string;
  recipient_email?: string;
  recipient_name?: string;
  variables?: Record<string, string>;
}

function resolveTemplate(text: string, vars: Record<string, string>): string {
  let result = text;
  for (const [key, value] of Object.entries(vars)) {
    result = result.replaceAll(`{{${key}}}`, value);
  }
  return result;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") as string;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") as string;
    const emailApiKey = Deno.env.get("EMAIL_API_KEY");
    const emailApiUrl = Deno.env.get("EMAIL_API_URL");
    const senderEmail = Deno.env.get("SENDER_EMAIL") || "no-reply@shopfundlin.com";
    const senderName = Deno.env.get("SENDER_NAME") || "Shop Fundlin";

    const supabase = createClient(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false },
    });

    const body = (await req.json()) as SendEmailRequest;

    // Fetch template
    let template;
    if (body.template_id) {
      const { data, error } = await supabase
        .from("email_templates")
        .select("*")
        .eq("id", body.template_id)
        .maybeSingle();
      if (error || !data) {
        return new Response(JSON.stringify({ error: "Template not found" }), {
          status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      template = data;
    } else if (body.template_type) {
      const { data, error } = await supabase
        .from("email_templates")
        .select("*")
        .eq("template_type", body.template_type)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (error || !data) {
        return new Response(JSON.stringify({ error: "Template not found for type: " + body.template_type }), {
          status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      template = data;
    } else {
      return new Response(JSON.stringify({ error: "Either template_id or template_type is required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Fetch intern if intern_id provided
    let intern = null;
    let recipientEmail = body.recipient_email || "";
    let recipientName = body.recipient_name || "";

    if (body.intern_id) {
      const { data, error } = await supabase
        .from("interns")
        .select("*")
        .eq("id", body.intern_id)
        .maybeSingle();
      if (error || !data) {
        return new Response(JSON.stringify({ error: "Intern not found" }), {
          status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      intern = data;
      recipientEmail = recipientEmail || intern.email;
      recipientName = recipientName || intern.full_name;
    }

    if (!recipientEmail) {
      return new Response(JSON.stringify({ error: "No recipient email determined" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Build variables from intern + provided variables
    const vars: Record<string, string> = {};
    if (intern) {
      vars["intern_name"] = intern.full_name;
      vars["intern_id"] = intern.intern_id;
      vars["start_date"] = intern.start_date || "";
      vars["expected_end_date"] = intern.expected_end_date || "";
    }
    if (body.variables) {
      Object.assign(vars, body.variables);
    }

    const resolvedSubject = resolveTemplate(template.subject, vars);
    const resolvedBody = resolveTemplate(template.body, vars);

    // Insert email_log entry as pending
    const { data: logEntry, error: logError } = await supabase
      .from("email_log")
      .insert({
        template_id: template.id,
        intern_id: body.intern_id || null,
        recipient_email: recipientEmail,
        recipient_name: recipientName,
        subject: resolvedSubject,
        body: resolvedBody,
        status: "pending",
      })
      .select("id")
      .single();

    if (logError) {
      return new Response(JSON.stringify({ error: "Failed to create email log: " + logError.message }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const logId = logEntry.id;
    let usedMock = false;

    if (emailApiKey && emailApiUrl) {
      // Real email API call
      try {
        const emailResponse = await fetch(emailApiUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${emailApiKey}`,
          },
          body: JSON.stringify({
            from: `${senderName} <${senderEmail}>`,
            to: recipientEmail,
            subject: resolvedSubject,
            text: resolvedBody,
          }),
        });

        if (!emailResponse.ok) {
          const errText = await emailResponse.text();
          await supabase.from("email_log").update({
            status: "failed",
            error_message: `Email API error (${emailResponse.status}): ${errText}`,
          }).eq("id", logId);
          return new Response(JSON.stringify({
            error: "Email API error",
            log_id: logId,
            status: "failed",
            mock: false,
          }), {
            status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        await supabase.from("email_log").update({
          status: "sent",
          sent_at: new Date().toISOString(),
        }).eq("id", logId);
      } catch (err) {
        await supabase.from("email_log").update({
          status: "failed",
          error_message: err.message,
        }).eq("id", logId);
        return new Response(JSON.stringify({
          error: "Email send failed: " + err.message,
          log_id: logId,
          status: "failed",
          mock: false,
        }), {
          status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    } else {
      // Mock mode — no real email sent, but log it as "sent" with a mock note
      usedMock = true;
      await supabase.from("email_log").update({
        status: "sent",
        sent_at: new Date().toISOString(),
        error_message: "Mock mode — EMAIL_API_KEY not set. No real email was delivered.",
      }).eq("id", logId);
    }

    return new Response(JSON.stringify({
      success: true,
      log_id: logId,
      status: "sent",
      mock: usedMock,
      recipient: recipientEmail,
      subject: resolvedSubject,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
