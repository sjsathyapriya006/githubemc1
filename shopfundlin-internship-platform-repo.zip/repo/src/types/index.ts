export type UserRole = "admin" | "intern";

export interface Profile {
  id: string;
  role: UserRole;
  full_name: string | null;
  created_at: string;
}

export interface Batch {
  id: string;
  name: string;
  start_date: string | null;
  end_date: string | null;
  status: string;
  created_at: string;
}

export interface Intern {
  id: string;
  intern_id: string;
  full_name: string;
  email: string;
  phone: string | null;
  college: string | null;
  department: string | null;
  role: string | null;
  batch_id: string | null;
  start_date: string | null;
  expected_end_date: string | null;
  status: string;
  created_at: string;
}

export const INTERN_STATUSES = [
  "Registered",
  "Onboarding",
  "Task Assigned",
  "In Progress",
  "Submitted",
  "Under Review",
  "Changes Requested",
  "Resubmitted",
  "Completed",
] as const;

export interface Project {
  id: string;
  title: string;
  description: string;
  requirements: string[];
  tools: string[];
  deliverables: string[];
  deadline: string | null;
  status: string;
  created_at: string;
}

export const TASK_STATUSES = [
  "Recommended",
  "Approved",
  "Assigned",
  "In Progress",
  "Submitted",
  "Completed",
  "Rejected",
] as const;

export type TaskStatus = (typeof TASK_STATUSES)[number];

export interface Task {
  id: string;
  project_id: string;
  intern_id: string;
  title: string;
  instructions: string;
  deliverables: string;
  difficulty: string | null;
  deadline: string | null;
  status: TaskStatus;
  ai_generated: boolean;
  review_criteria: string | null;
  created_at: string;
}

export interface ProjectWithInterns extends Project {
  intern_count?: number;
}

export interface TaskWithRelations extends Task {
  project_title?: string;
  intern_name?: string;
  intern_email?: string;
  intern_id_human?: string;
}

export interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  body: string;
  template_type: string;
  created_at: string;
}

export const TEMPLATE_TYPES = [
  "welcome",
  "review_invite",
  "task_assignment",
  "deadline_reminder",
  "submission_confirmation",
  "review_feedback",
  "revision_request",
  "next_review",
  "completion",
] as const;

export interface EmailLogEntry {
  id: string;
  template_id: string | null;
  intern_id: string | null;
  recipient_email: string;
  recipient_name: string | null;
  subject: string;
  body: string;
  status: string;
  error_message: string | null;
  sent_at: string | null;
  created_at: string;
}

export interface Meeting {
  id: string;
  batch_id: string | null;
  title: string;
  description: string;
  meeting_type: string;
  scheduled_date: string;
  scheduled_time: string;
  duration_minutes: number;
  meeting_link: string | null;
  calendar_event_id: string | null;
  status: string;
  created_at: string;
}

export interface MeetingAttendee {
  id: string;
  meeting_id: string;
  intern_id: string;
  invitation_status: string;
  attended: boolean | null;
  created_at: string;
}

export interface MeetingWithAttendees extends Meeting {
  attendees?: MeetingAttendeeWithIntern[];
  attendee_count?: number;
}

export interface MeetingAttendeeWithIntern extends MeetingAttendee {
  intern_name?: string;
  intern_email?: string;
  intern_id_human?: string;
}

export const SUBMISSION_STATUSES = [
  "submitted",
  "under_review",
  "approved",
  "changes_requested",
  "rejected",
  "resubmitted",
] as const;

export type SubmissionStatus = (typeof SUBMISSION_STATUSES)[number];

export interface Submission {
  id: string;
  task_id: string;
  intern_id: string;
  project_id: string;
  submission_text: string;
  file_urls: string[];
  status: SubmissionStatus;
  submission_number: number;
  submitted_at: string;
  reviewed_at: string | null;
  created_at: string;
  implementation_summary?: string;
  completion_notes?: string;
  repo_url?: string | null;
  demo_url?: string | null;
  assignment_id?: string | null;
}

export interface SubmissionReview {
  id: string;
  submission_id: string;
  reviewer_id: string;
  decision: "approved" | "changes_requested" | "rejected";
  feedback: string;
  strengths: string;
  areas_for_improvement: string;
  score: number | null;
  created_at: string;
}

export interface SubmissionWithDetails extends Submission {
  task_title?: string;
  task_instructions?: string;
  task_deliverables?: string;
  task_review_criteria?: string;
  task_status?: string;
  project_title?: string;
  intern_name?: string;
  intern_email?: string;
  intern_id_human?: string;
  latest_review_decision?: string;
  latest_review_feedback?: string;
  latest_review_strengths?: string;
  latest_review_improvement?: string;
  latest_review_score?: number | null;
  latest_review_at?: string;
}

export interface AIEvaluation {
  id: string;
  submission_id: string;
  task_id: string;
  intern_id: string;
  recommended_decision: "approved" | "changes_requested" | "rejected";
  score: number | null;
  feedback: string;
  strengths: string;
  areas_for_improvement: string;
  criteria_analysis: string;
  mock: boolean;
  created_at: string;
}

export interface AIEvaluationWithDetails extends AIEvaluation {
  submission_number?: number;
  submission_status?: string;
  task_title?: string;
  task_review_criteria?: string;
  intern_name?: string;
  intern_id_human?: string;
}

export interface ReviewCycleSummary {
  task_id: string;
  task_title: string;
  project_id: string;
  project_title: string;
  intern_id: string;
  intern_name: string;
  intern_id_human: string;
  intern_email: string;
  total_submissions: number;
  current_status: string | null;
  final_decision: string | null;
  first_submitted_at: string | null;
  last_activity_at: string | null;
  highest_score: number | null;
  avg_score: number | null;
  has_changes_requested: boolean | null;
  cycle_complete: boolean | null;
}

export interface TimelineEvent {
  task_id: string;
  submission_id: string;
  event_type: "submission" | "review";
  submission_number: number;
  submission_status: string;
  submission_text: string | null;
  file_urls: string[] | null;
  event_timestamp: string;
  review_decision: string | null;
  review_feedback: string | null;
  review_strengths: string | null;
  review_improvement: string | null;
  review_score: number | null;
  review_created_at: string | null;
}

export interface InternProgressReport {
  intern_id: string;
  intern_id_human: string;
  full_name: string;
  email: string;
  college: string | null;
  department: string | null;
  role: string | null;
  intern_status: string;
  batch_id: string | null;
  batch_name: string | null;
  total_tasks: number;
  completed_tasks: number;
  in_progress_tasks: number;
  assigned_tasks: number;
  rejected_tasks: number;
  total_submissions: number;
  approved_submissions: number;
  changes_requested_count: number;
  avg_review_score: number | null;
  highest_score: number | null;
  first_submission_date: string | null;
  last_submission_date: string | null;
  last_review_date: string | null;
  completion_rate: number;
}

export interface BatchCohortSummary {
  batch_id: string;
  batch_name: string;
  start_date: string | null;
  end_date: string | null;
  batch_status: string;
  intern_count: number;
  completed_count: number;
  in_progress_count: number;
  avg_completion_rate: number | null;
  avg_score: number | null;
  total_submissions: number | null;
  total_completed_tasks: number | null;
}

export interface TaskCompletionBreakdown {
  status: string;
  count: number;
}

export interface SubmissionActivityTrend {
  activity_date: string;
  submission_count: number;
  unique_interns: number;
}

export const ASSIGNMENT_STATUSES = [
  "Assigned",
  "In Progress",
  "Submitted",
  "Revision Requested",
  "Resubmitted",
  "Approved",
  "Completed",
] as const;

export type AssignmentStatus = (typeof ASSIGNMENT_STATUSES)[number];

export interface ProjectAssignment {
  id: string;
  project_id: string;
  intern_id: string;
  assigned_by: string | null;
  objectives: string;
  milestones: string[];
  completion_instructions: string;
  start_date: string | null;
  deadline: string | null;
  difficulty: string | null;
  max_rating: number;
  status: AssignmentStatus;
  progress_description: string;
  progress_updated_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface ProjectAssignmentWithRelations extends ProjectAssignment {
  project_title?: string;
  project_description?: string;
  project_requirements?: string[];
  project_tools?: string[];
  project_deliverables?: string[];
  intern_name?: string;
  intern_email?: string;
  intern_id_human?: string;
  batch_name?: string;
  assigned_by_name?: string;
}

export interface ProjectAssignmentAudit {
  id: string;
  assignment_id: string;
  action: string;
  old_value: string | null;
  new_value: string | null;
  changed_by: string | null;
  changed_at: string;
}

export interface SubmissionReviewWithCategories extends SubmissionReview {
  rating_code_quality: number | null;
  rating_functionality: number | null;
  rating_documentation: number | null;
  rating_creativity: number | null;
  rating_deadline_adherence: number | null;
  score_override_reason: string | null;
  reviewer_name: string | null;
}

export interface ProjectFile {
  id: string;
  assignment_id: string;
  submission_id: string | null;
  intern_id: string;
  storage_key: string;
  file_name: string;
  file_size: number;
  mime_type: string;
  created_at: string;
}
