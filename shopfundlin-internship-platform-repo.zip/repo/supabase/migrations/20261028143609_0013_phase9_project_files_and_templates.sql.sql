/*
# Phase 9 — Project Files Table + Email Templates + Draft Support

## Purpose
1. Creates a `project_files` table to track uploaded file metadata (storage key,
   original filename, file size, MIME type) linked to a project assignment.
   Files are stored in the private `project-files` bucket and accessed via
   signed URLs — not public URLs.

2. Extends the `email_templates` check constraint to allow `project_assignment`
   type and inserts three new email templates:
   - project_assignment: sent when a project is assigned to an intern
   - review_feedback: already allowed, template inserted if missing
   - revision_request: already allowed, template inserted if missing

3. Adds `is_draft` column to submissions for save-as-draft support.

## New tables

### project_files
- id (uuid PK)
- assignment_id (FK → project_assignments.id ON DELETE CASCADE)
- submission_id (FK → submissions.id ON DELETE SET NULL, nullable)
- intern_id (FK → interns.id ON DELETE CASCADE)
- storage_key (text) — path in the storage bucket
- file_name (text) — original filename
- file_size (bigint) — size in bytes
- mime_type (text)
- created_at (timestamptz)

## Modified tables

### submissions
- is_draft (boolean, default false)

### email_templates
- Check constraint extended to include 'project_assignment'

## Security
- RLS on project_files: admins see all, interns see only their own.
- Interns can INSERT/DELETE their own files.
*/

CREATE TABLE IF NOT EXISTS project_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  assignment_id uuid NOT NULL REFERENCES project_assignments(id) ON DELETE CASCADE,
  submission_id uuid REFERENCES submissions(id) ON DELETE SET NULL,
  intern_id uuid NOT NULL REFERENCES interns(id) ON DELETE CASCADE,
  storage_key text NOT NULL,
  file_name text NOT NULL,
  file_size bigint NOT NULL DEFAULT 0,
  mime_type text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE project_files ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, DELETE ON project_files TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON project_files TO service_role;

DROP POLICY IF EXISTS "admin_select_project_files" ON project_files;
CREATE POLICY "admin_select_project_files"
ON project_files FOR SELECT
TO authenticated USING (is_admin());

DROP POLICY IF EXISTS "intern_select_own_project_files" ON project_files;
CREATE POLICY "intern_select_own_project_files"
ON project_files FOR SELECT
TO authenticated
USING (
  intern_id IN (
    SELECT i.id FROM interns i
    WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
  )
);

DROP POLICY IF EXISTS "intern_insert_own_project_files" ON project_files;
CREATE POLICY "intern_insert_own_project_files"
ON project_files FOR INSERT
TO authenticated
WITH CHECK (
  intern_id IN (
    SELECT i.id FROM interns i
    WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
  )
);

DROP POLICY IF EXISTS "intern_delete_own_project_files" ON project_files;
CREATE POLICY "intern_delete_own_project_files"
ON project_files FOR DELETE
TO authenticated
USING (
  intern_id IN (
    SELECT i.id FROM interns i
    WHERE i.email = (SELECT email FROM auth.users WHERE id = auth.uid())
  )
);

DROP POLICY IF EXISTS "admin_delete_project_files_table" ON project_files;
CREATE POLICY "admin_delete_project_files_table"
ON project_files FOR DELETE
TO authenticated USING (is_admin());

CREATE INDEX IF NOT EXISTS idx_project_files_assignment ON project_files(assignment_id);
CREATE INDEX IF NOT EXISTS idx_project_files_submission ON project_files(submission_id);

-- Add is_draft column to submissions
ALTER TABLE submissions ADD COLUMN IF NOT EXISTS is_draft boolean NOT NULL DEFAULT false;

-- Extend email_templates check constraint to include 'project_assignment'
ALTER TABLE email_templates DROP CONSTRAINT IF EXISTS email_templates_template_type_check;
ALTER TABLE email_templates ADD CONSTRAINT email_templates_template_type_check
  CHECK (template_type = ANY (ARRAY[
    'welcome'::text, 'review_invite'::text, 'task_assignment'::text,
    'deadline_reminder'::text, 'submission_confirmation'::text,
    'review_feedback'::text, 'revision_request'::text, 'next_review'::text,
    'completion'::text, 'project_assignment'::text
  ]));

-- Insert missing email templates
INSERT INTO email_templates (name, subject, body, template_type)
SELECT 'Project Assignment', 'New Project Assigned: {{project_title}}',
'Hi {{intern_name}},

A new project has been assigned to you:

Project: {{project_title}}
Deadline: {{deadline}}
Difficulty: {{difficulty}}

Objectives:
{{objectives}}

Please log in to your internship portal to view the full project details, requirements, and deliverables. You can start working on it right away.

— Shop Fundlin Team',
'project_assignment'
WHERE NOT EXISTS (SELECT 1 FROM email_templates WHERE template_type = 'project_assignment');

INSERT INTO email_templates (name, subject, body, template_type)
SELECT 'Review Feedback', 'Your Project Has Been Reviewed: {{project_title}}',
'Hi {{intern_name}},

Your project submission has been reviewed:

Project: {{project_title}}
Decision: {{review_decision}}
Overall Score: {{review_score}}/10

Reviewer Feedback:
{{review_feedback}}

Please log in to your internship portal to view the full review details, category ratings, and any next steps.

— Shop Fundlin Team',
'review_feedback'
WHERE NOT EXISTS (SELECT 1 FROM email_templates WHERE template_type = 'review_feedback');

INSERT INTO email_templates (name, subject, body, template_type)
SELECT 'Revision Requested', 'Revisions Requested: {{project_title}}',
'Hi {{intern_name}},

Revisions have been requested on your project submission:

Project: {{project_title}}
Resubmission Deadline: {{deadline}}

Areas for improvement:
{{review_improvement}}

Please address the feedback and resubmit your project through the internship portal.

— Shop Fundlin Team',
'revision_request'
WHERE NOT EXISTS (SELECT 1 FROM email_templates WHERE template_type = 'revision_request');